// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/sprites.js
// Tous les personnages dessinés en Canvas 2D pur
// ═══════════════════════════════════════════════════════════

const Sprites = {

  // ── AELARA ──────────────────────────────────────────────
  drawAelara(ctx, x, y, frame, facing=1, state='idle', alpha=1) {
    ctx.save(); ctx.globalAlpha = alpha;
    ctx.translate(x, y);
    if (facing < 0) ctx.scale(-1, 1);
    const t = frame * 0.08;
    const b = Math.sin(t) * 1.8;
    const cw = Math.sin(t * 0.7) * 3;
    const isAtk = state==='attack', isWlk = state==='walk';
    const lg = isWlk ? Math.sin(t*3)*8 : 0;

    // Aura glow
    const aura = ctx.createRadialGradient(0,-6,4,0,-6,38);
    aura.addColorStop(0,'rgba(80,140,255,0.18)'); aura.addColorStop(1,'rgba(80,140,255,0)');
    ctx.fillStyle=aura; ctx.beginPath(); ctx.arc(0,-6,38,0,Math.PI*2); ctx.fill();

    // Cape
    ctx.fillStyle='#b0c4e0';
    ctx.beginPath();
    ctx.moveTo(-8,-10+b); ctx.quadraticCurveTo(-20+cw,4,-16+cw,22);
    ctx.quadraticCurveTo(-5,28,0,22); ctx.quadraticCurveTo(5,28,16-cw,22);
    ctx.quadraticCurveTo(20-cw,4,8,-10+b); ctx.fill();

    // Body armure
    ctx.fillStyle='#c8a840';
    ctx.beginPath(); ctx.roundRect(-8,-8+b,16,18,2); ctx.fill();
    ctx.fillStyle='#f0d870';
    ctx.beginPath(); ctx.moveTo(0,-6+b); ctx.lineTo(-5,-1+b); ctx.lineTo(0,4+b); ctx.lineTo(5,-1+b); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#a8e8ff'; ctx.beginPath(); ctx.arc(0,-1+b,2,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#d4b850';
    ctx.beginPath(); ctx.ellipse(-11,-6+b,5,4,0.3,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(11,-6+b,5,4,-0.3,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#806020'; ctx.fillRect(-8,8+b,16,3);

    // Jambes
    ctx.fillStyle='#6888b8';
    ctx.fillRect(-7,10+b+lg*0.3,6,12); ctx.fillRect(1,10+b-lg*0.3,6,12);
    ctx.fillStyle='#4a6898';
    ctx.fillRect(-8,20+b+lg*0.3,7,5); ctx.fillRect(1,20+b-lg*0.3,7,5);

    // Bras
    ctx.fillStyle='#c8a840';
    if (isAtk) {
      ctx.save(); ctx.translate(12,-4+b); ctx.rotate(-0.9+Math.sin(t*5)*0.8);
      ctx.fillRect(-3,0,6,14); ctx.restore();
      ctx.fillRect(-16,-4+b,6,14);
    } else {
      ctx.fillRect(-16,-4+b,6,14); ctx.fillRect(10,-4+b,6,14);
    }

    // Tête
    ctx.fillStyle='#f0d8c0'; ctx.beginPath(); ctx.ellipse(0,-16+b,8,9,0,0,Math.PI*2); ctx.fill();
    // Cheveux longs argent
    ctx.fillStyle='#e8f0ff'; ctx.beginPath(); ctx.ellipse(0,-22+b,8,5,0,0,Math.PI*2); ctx.fill();
    ctx.fillRect(-7,-22+b,14,8);
    ctx.fillStyle='#d0deff';
    for (let s=0;s<3;s++) {
      const sx=-8+s*4+cw*0.3;
      ctx.beginPath(); ctx.moveTo(sx,-18+b); ctx.quadraticCurveTo(sx-3+cw,0+b,sx-5+cw*0.8,16);
      ctx.quadraticCurveTo(sx-2,20,sx+1,16); ctx.quadraticCurveTo(sx+1,0+b,sx,-18+b); ctx.fill();
    }
    ctx.fillStyle='#d8e8ff';
    ctx.beginPath(); ctx.moveTo(8,-18+b); ctx.quadraticCurveTo(12-cw,-6+b,10-cw*0.8,10);
    ctx.quadraticCurveTo(6,14,5,10); ctx.quadraticCurveTo(4,-6+b,8,-18+b); ctx.fill();

    // Yeux bleus
    ctx.shadowColor='#60a0ff'; ctx.shadowBlur=5; ctx.fillStyle='#4a88ff';
    ctx.beginPath(); ctx.ellipse(-3,-16+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3,-16+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='#fff';
    ctx.beginPath(); ctx.arc(-2.2,-16.6+b,0.8,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(3.8,-16.6+b,0.8,0,Math.PI*2); ctx.fill();

    // Épée
    ctx.save(); ctx.translate(isAtk?16:18, isAtk?-8+b:-6+b);
    ctx.rotate(isAtk ? Math.sin(t*5)*0.9-0.5 : 0.15);
    ctx.shadowColor='#c0e0ff'; ctx.shadowBlur=10;
    const bg=ctx.createLinearGradient(-2,-22,2,0);
    bg.addColorStop(0,'#e0f4ff'); bg.addColorStop(0.5,'#a0d0ff'); bg.addColorStop(1,'#80b8e8');
    ctx.fillStyle=bg; ctx.fillRect(-1.5,-22,3,25);
    ctx.fillStyle='#d4b840'; ctx.fillRect(-5,-2,10,3);
    ctx.fillStyle='#8a6020'; ctx.fillRect(-2,0,4,8);
    ctx.shadowBlur=0;
    if (isAtk) {
      const st=(Math.sin(t*6)+1)/2;
      ctx.strokeStyle=`rgba(180,220,255,${0.7*st})`; ctx.lineWidth=3; ctx.lineCap='round';
      ctx.beginPath(); ctx.moveTo(-2,-22); ctx.lineTo(22,14); ctx.stroke();
      ctx.strokeStyle=`rgba(220,240,255,${0.4*st})`; ctx.lineWidth=6;
      ctx.beginPath(); ctx.moveTo(-4,-20); ctx.lineTo(24,16); ctx.stroke();
    }
    ctx.restore(); ctx.restore();
  },

  // ── KAEL ────────────────────────────────────────────────
  drawKael(ctx, x, y, frame, facing=1, state='idle', alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha;
    ctx.translate(x,y); if(facing<0) ctx.scale(-1,1);
    const t=frame*0.08;
    const b=Math.sin(t)*1, sm=Math.sin(t*1.1)*2;
    const isAtk=state==='attack', isWlk=state==='walk';
    const lg=isWlk?Math.sin(t*3)*7:0, dsh=isAtk?Math.sin(t*6)*5:0;

    // Fumée aura
    for(let i=0;i<4;i++){
      const sa=ctx.createRadialGradient(sm*(i+1)*0.4,b+i*2,1,sm*0.5,4,32-i*5);
      sa.addColorStop(0,`rgba(40,0,60,${0.1-i*0.02})`); sa.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=sa; ctx.beginPath(); ctx.ellipse(sm*0.3,8,28-i*4,18-i*2,0,0,Math.PI*2); ctx.fill();
    }

    // Manteau
    ctx.fillStyle='#18142a';
    ctx.beginPath(); ctx.moveTo(-9+dsh,-8+b);
    ctx.quadraticCurveTo(-14+sm,12,-12+sm*0.8,24);
    ctx.lineTo(12-sm*0.8,24); ctx.quadraticCurveTo(14-sm,12,9-dsh,-8+b); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#24203c'; ctx.fillRect(-10+dsh,-6+b,3,22); ctx.fillRect(7-dsh,-6+b,3,22);

    // Capuche
    ctx.fillStyle='#100e1e'; ctx.beginPath(); ctx.ellipse(0,-20+b,10,8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0a081a';
    ctx.beginPath(); ctx.moveTo(-10,-14+b); ctx.quadraticCurveTo(-13+sm,-4+b,-10,4+b); ctx.lineTo(-7,-4+b); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(10,-14+b); ctx.quadraticCurveTo(13-sm,-4+b,10,4+b); ctx.lineTo(7,-4+b); ctx.closePath(); ctx.fill();

    // Jambes
    ctx.fillStyle='#201830';
    ctx.fillRect(-7,10+b+lg*0.3,6,12); ctx.fillRect(1,10+b-lg*0.3,6,12);
    ctx.fillStyle='#2c2040';
    ctx.fillRect(-8,20+b+lg*0.3,7,4); ctx.fillRect(1,20+b-lg*0.3,7,4);

    // Visage
    ctx.fillStyle='#1e1828'; ctx.beginPath(); ctx.ellipse(0,-18+b,7,8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0c0a18'; ctx.beginPath(); ctx.ellipse(0,-24+b,8,5,0,0,Math.PI*2); ctx.fill();
    ctx.fillRect(-7,-25+b,14,7);
    [[-6,-28],[-2,-30],[3,-29],[6,-27]].forEach(([hx,hy])=>{
      ctx.beginPath(); ctx.moveTo(hx-2,-22+b); ctx.lineTo(hx,hy+b); ctx.lineTo(hx+2,-22+b); ctx.closePath(); ctx.fill();
    });

    // Yeux rouges
    ctx.shadowColor='#ff2040'; ctx.shadowBlur=8; ctx.fillStyle='#ff3050';
    ctx.beginPath(); ctx.ellipse(-3,-19+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3,-19+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='#ff8090';
    ctx.beginPath(); ctx.arc(-2.5,-19.5+b,0.7,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(3.5,-19.5+b,0.7,0,Math.PI*2); ctx.fill();

    // Dagues
    const dagger=(tx,ty,rot)=>{
      ctx.save(); ctx.translate(tx,ty); ctx.rotate(rot);
      const dg=ctx.createLinearGradient(-1.5,-16,1.5,2);
      dg.addColorStop(0,'#d0d8e0'); dg.addColorStop(0.6,'#8090a0'); dg.addColorStop(1,'#4a5860');
      ctx.fillStyle=dg; ctx.beginPath(); ctx.moveTo(0,-16); ctx.lineTo(-1.5,2); ctx.lineTo(1.5,2); ctx.closePath(); ctx.fill();
      ctx.fillStyle='#606870'; ctx.fillRect(-3.5,1,7,2.5);
      ctx.fillStyle='#2a2030'; ctx.fillRect(-1.5,3,3,7);
      ctx.fillStyle='#6070a0'; ctx.fillRect(-2,9,4,2);
      ctx.restore();
    };
    if (isAtk) {
      const sl=Math.sin(t*6);
      ctx.strokeStyle=`rgba(100,0,160,${0.5+sl*0.3})`; ctx.lineWidth=5; ctx.lineCap='round';
      ctx.beginPath(); ctx.moveTo(-16,-8+b); ctx.lineTo(20,8+b); ctx.stroke();
      dagger(-18+dsh,-6+b,-0.8+sl*0.6); dagger(14-dsh,-4+b,0.6-sl*0.5);
    } else {
      dagger(-15,-4+b,-0.35); dagger(15,-4+b,0.35);
    }
    ctx.restore();
  },

  // ── THÉO ────────────────────────────────────────────────
  drawTheo(ctx, x, y, frame, facing=1, state='idle', alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha;
    ctx.translate(x,y); if(facing<0) ctx.scale(-1,1);
    const t=frame*0.08;
    const b=Math.sin(t)*1.4;
    const isAtk=state==='attack', isWlk=state==='walk';
    const lg=isWlk?Math.sin(t*3)*7:0;

    // Fragments flottants
    for(let i=0;i<6;i++){
      const angle=t*0.4+i*(Math.PI*2/6);
      const r=26+Math.sin(t*0.8+i)*5;
      const fx=Math.cos(angle)*r, fy=Math.sin(angle)*r*0.45-8;
      const fa=0.25+Math.sin(t*1.2+i*0.8)*0.18;
      ctx.fillStyle=`rgba(${160+i*12},${200-i*10},${140+i*8},${fa})`;
      ctx.save(); ctx.translate(fx,fy); ctx.rotate(t*0.3+i);
      const fs=1.5+Math.sin(t+i)*0.8; ctx.fillRect(-fs,-fs,fs*2,fs*2); ctx.restore();
    }

    // Manteau voyageur
    ctx.fillStyle='#8a7060';
    ctx.beginPath(); ctx.moveTo(-8,-6+b); ctx.lineTo(-11,22); ctx.lineTo(11,22); ctx.lineTo(8,-6+b); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#6a5448';
    ctx.beginPath(); ctx.moveTo(-2,-4+b); ctx.lineTo(-7,6+b); ctx.lineTo(-4,6+b); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(2,-4+b); ctx.lineTo(7,6+b); ctx.lineTo(4,6+b); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#4a3828'; ctx.fillRect(-8,9+b,16,3);

    // Jambes
    ctx.fillStyle='#5a4840';
    ctx.fillRect(-7,12+b+lg*0.3,6,12); ctx.fillRect(1,12+b-lg*0.3,6,12);
    ctx.fillStyle='#3a2818';
    ctx.fillRect(-8,22+b+lg*0.3,7,4); ctx.fillRect(1,22+b-lg*0.3,7,4);

    // Bras + carte
    ctx.fillStyle='#8a7060'; ctx.fillRect(-16,-4+b,6,14);
    ctx.fillStyle='#d8c8a0'; ctx.fillRect(-18,-2+b,8,6);
    ctx.strokeStyle='#9a8860'; ctx.lineWidth=0.5;
    ctx.beginPath(); ctx.moveTo(-17,0+b); ctx.lineTo(-11,0+b); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-17,2+b); ctx.lineTo(-11,2+b); ctx.stroke();
    ctx.fillStyle='#8a7060'; ctx.fillRect(10,-4+b,6,14);

    // Tête
    ctx.fillStyle='#e0c8a8'; ctx.beginPath(); ctx.ellipse(0,-16+b,8,9,0,0,Math.PI*2); ctx.fill();
    // Cheveux bruns
    ctx.fillStyle='#6a4a28'; ctx.beginPath(); ctx.ellipse(0,-22+b,8,5,0,0,Math.PI*2); ctx.fill();
    ctx.fillRect(-7,-23+b,14,8);
    ctx.beginPath(); ctx.moveTo(-7,-20+b); ctx.quadraticCurveTo(-10,-12+b,-9,-6+b);
    ctx.quadraticCurveTo(-6,-3+b,-5,-6+b); ctx.quadraticCurveTo(-5,-14+b,-7,-20+b); ctx.fill();

    // Yeux gris-vert
    ctx.fillStyle='#8098a0';
    ctx.beginPath(); ctx.ellipse(-3,-16+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3,-16+b,2.2,1.6,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#5a7080';
    ctx.beginPath(); ctx.ellipse(-3,-16+b,1.2,1,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3,-16+b,1.2,1,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#fff';
    ctx.beginPath(); ctx.arc(-2.4,-16.5+b,0.6,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(3.6,-16.5+b,0.6,0,Math.PI*2); ctx.fill();

    // Onde d'énergie (attaque)
    if (isAtk) {
      const wt=(Math.sin(t*5)+1)/2;
      for(let r=1;r<=4;r++){
        ctx.strokeStyle=`rgba(120,200,140,${(1-r*0.2)*wt})`; ctx.lineWidth=3-r*0.5;
        ctx.beginPath(); ctx.arc(0,0,12*r+wt*8,0,Math.PI*2); ctx.stroke();
      }
      ctx.shadowColor='#80c080'; ctx.shadowBlur=18;
      ctx.fillStyle=`rgba(100,200,120,${0.2*wt})`;
      ctx.beginPath(); ctx.arc(0,0,20+wt*14,0,Math.PI*2); ctx.fill();
      ctx.shadowBlur=0;
    }
    ctx.restore();
  },

  // ── ENNEMIS ─────────────────────────────────────────────
  drawOmbreErrante(ctx, x, y, frame, alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha; ctx.translate(x,y);
    const t=frame*0.07;
    const wb=Math.sin(t)*3.5, wb2=Math.cos(t*1.4)*2.5;
    const fy=Math.sin(t*0.75)*5; ctx.translate(0,fy);
    for(let i=0;i<8;i++){
      const a=t*0.6+i*(Math.PI/4), br=15+wb2+Math.sin(t*2+i)*3;
      const bx=Math.cos(a)*br*0.8+wb*0.3, by=Math.sin(a)*br*0.5+2;
      ctx.fillStyle=`rgba(8,4,20,${0.3+Math.sin(t+i)*0.1})`;
      ctx.beginPath(); ctx.arc(bx,by,6+Math.sin(t+i)*2,0,Math.PI*2); ctx.fill();
    }
    ctx.fillStyle='#080418'; ctx.beginPath(); ctx.ellipse(wb*0.3,2,13+wb2*0.3,22,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0c0828';
    ctx.beginPath(); ctx.ellipse(-18+wb,-2,5,12,0.4,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(18-wb,-2,5,12,-0.4,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0c0a22'; ctx.beginPath(); ctx.ellipse(wb*0.2,-20,11,10,0,0,Math.PI*2); ctx.fill();
    ctx.shadowColor='#ff2040'; ctx.shadowBlur=12; ctx.fillStyle='#ff3050';
    ctx.beginPath(); ctx.ellipse(-3.5+wb*0.1,-21,3,2.2,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3.5+wb*0.1,-21,3,2.2,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0;
    ctx.fillStyle='#1a0008'; ctx.fillRect(-3.5+wb*0.1-0.4,-22.5,0.8,3); ctx.fillRect(3.5+wb*0.1-0.4,-22.5,0.8,3);
    ctx.restore();
  },

  drawGolem(ctx, x, y, frame, alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha; ctx.translate(x,y);
    const t=frame*0.055, sh=Math.sin(t*1.8)*1.5, sv=Math.abs(Math.sin(t*1.8))*1;
    ctx.translate(sh,sv);
    ctx.fillStyle='rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(0,28,22,6,0,0,Math.PI*2); ctx.fill();
    const sg=ctx.createLinearGradient(-20,-28,20,28);
    sg.addColorStop(0,'#7a6a58'); sg.addColorStop(0.5,'#5a4a38'); sg.addColorStop(1,'#3a2a1e');
    ctx.fillStyle=sg; ctx.beginPath(); ctx.roundRect(-20,-24,40,52,4); ctx.fill();
    ctx.fillStyle='#6a5a48'; ctx.fillRect(-18,-22,15,12); ctx.fillRect(2,-22,16,12);
    ctx.fillRect(-18,-8,12,14); ctx.fillRect(-4,-8,22,14); ctx.fillRect(-18,8,36,14);
    ctx.shadowColor='#ff7820'; ctx.shadowBlur=8;
    ctx.strokeStyle='#ff8830'; ctx.lineWidth=1.5; ctx.lineCap='round';
    [[ [-12,-20],[-7,-8],[-2,-12],[6,4] ], [ [10,-18],[14,0] ], [ [-4,6],[2,18],[-8,22] ], [ [8,10],[16,24] ]].forEach(pts=>{
      ctx.beginPath(); pts.forEach(([cx,cy],i)=>{ if(i===0) ctx.moveTo(cx,cy); else ctx.lineTo(cx,cy); }); ctx.stroke();
    });
    ctx.shadowBlur=0;
    const hg=ctx.createLinearGradient(-16,-48,16,-26);
    hg.addColorStop(0,'#8a7a68'); hg.addColorStop(1,'#5a4a38');
    ctx.fillStyle=hg; ctx.beginPath(); ctx.roundRect(-16,-52,32,24,3); ctx.fill();
    ctx.fillStyle='#6a5a48'; ctx.fillRect(-14,-50,12,6); ctx.fillRect(2,-50,12,6);
    ctx.shadowColor='#ff8020'; ctx.shadowBlur=14; ctx.fillStyle='#ff9030';
    ctx.fillRect(-10,-44,8,6); ctx.fillRect(2,-44,8,6);
    ctx.fillStyle='#ffb850'; ctx.fillRect(-8,-43,4,3); ctx.fillRect(4,-43,4,3);
    ctx.shadowBlur=0;
    ctx.fillStyle='#4a3a28'; ctx.beginPath(); ctx.roundRect(-36,-8,16,20,3); ctx.fill();
    ctx.beginPath(); ctx.roundRect(20,-8,16,20,3); ctx.fill();
    ctx.fillStyle='#3a2a18'; ctx.fillRect(-17,28,14,20); ctx.fillRect(3,28,14,20);
    ctx.fillStyle='#3a2a18'; ctx.fillRect(-18,44,16,6); ctx.fillRect(2,44,16,6);
    ctx.restore();
  },

  drawSirene(ctx, x, y, frame, alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha; ctx.translate(x,y);
    const t=frame*0.065, wv=Math.sin(t)*4, hf=Math.cos(t*0.6)*5;
    ctx.shadowColor='#2060a0'; ctx.shadowBlur=10;
    const tg=ctx.createLinearGradient(0,14,0,50);
    tg.addColorStop(0,'#2a5888'); tg.addColorStop(1,'#1a3460');
    ctx.fillStyle=tg;
    ctx.beginPath(); ctx.moveTo(-9,14); ctx.quadraticCurveTo(-14+wv*0.5,32,-16+wv*0.3,44);
    ctx.quadraticCurveTo(-4,52,0,50); ctx.quadraticCurveTo(4,52,16-wv*0.3,44);
    ctx.quadraticCurveTo(14-wv*0.5,32,9,14); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#3a78b8';
    ctx.beginPath(); ctx.moveTo(-16+wv*0.3,44); ctx.quadraticCurveTo(-24+wv,54,-14+wv*0.2,56);
    ctx.quadraticCurveTo(0,51,14-wv*0.2,56); ctx.quadraticCurveTo(24-wv,54,16-wv*0.3,44); ctx.fill();
    ctx.shadowBlur=0;
    ctx.strokeStyle='rgba(80,160,220,0.25)'; ctx.lineWidth=0.8;
    for(let sy=16;sy<44;sy+=5){ for(let sx=-8;sx<10;sx+=5){ ctx.beginPath(); ctx.arc(sx,sy,2.5,0,Math.PI); ctx.stroke(); } }
    const bg2=ctx.createLinearGradient(-10,-14,10,14);
    bg2.addColorStop(0,'#d0dce8'); bg2.addColorStop(1,'#b8ccd8');
    ctx.fillStyle=bg2; ctx.fillRect(-9,-14,18,30);
    ctx.fillStyle='#a0b8c8'; ctx.beginPath(); ctx.ellipse(0,-4,8,6,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#d8e8f0'; ctx.beginPath(); ctx.ellipse(0,-22,10,11,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#88b8d0';
    for(let h=0;h<4;h++){
      const sx=-8+h*5, hd=h<2?-1:1;
      ctx.beginPath(); ctx.moveTo(sx,-26); ctx.quadraticCurveTo(sx+hd*(8+hf*0.5),-14,sx+hd*(6+hf*0.4),4);
      ctx.quadraticCurveTo(sx+hd*3,8,sx+hd*2,4); ctx.quadraticCurveTo(sx+hd*4,-10,sx,-26); ctx.fill();
    }
    ctx.fillStyle='#e06080';
    [[-6,-30],[-2,-32],[3,-31],[7,-29]].forEach(([cx,cy])=>{
      ctx.beginPath(); ctx.moveTo(cx,cy+4); ctx.lineTo(cx-1.5,cy-3); ctx.lineTo(cx+1.5,cy-3); ctx.closePath(); ctx.fill();
    });
    ctx.shadowColor='#60b0e0'; ctx.shadowBlur=8; ctx.fillStyle='#70c0e8';
    ctx.beginPath(); ctx.ellipse(-3.5,-23,3,2,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3.5,-23,3,2,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='#400020';
    ctx.fillRect(-3.5-0.4,-24.2,0.8,2.8); ctx.fillRect(3.5-0.4,-24.2,0.8,2.8);
    ctx.restore();
  },

  drawVaeltharion(ctx, x, y, frame, alpha=1) {
    ctx.save(); ctx.globalAlpha=alpha; ctx.translate(x,y);
    const t=frame*0.05, fy=Math.sin(t*0.75)*7, p=0.75+Math.sin(t*1.1)*0.25;
    ctx.translate(0,fy);
    const og=ctx.createRadialGradient(0,0,10,0,0,85);
    og.addColorStop(0,`rgba(127,255,238,${0.2*p})`); og.addColorStop(0.4,`rgba(80,60,180,${0.12*p})`); og.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=og; ctx.beginPath(); ctx.arc(0,0,85,0,Math.PI*2); ctx.fill();
    for(let i=0;i<6;i++){
      const a=t*0.3+i*(Math.PI/3), len=55+Math.sin(t*1.5+i)*12;
      const tx=Math.cos(a)*len, ty=Math.sin(a)*len*0.6+20;
      ctx.strokeStyle=`rgba(127,255,238,${(0.15+Math.sin(t+i)*0.08)*p})`; ctx.lineWidth=2;
      ctx.beginPath(); ctx.moveTo(Math.cos(a)*20,Math.sin(a)*12); ctx.quadraticCurveTo(tx*0.6+Math.sin(t+i)*8,ty*0.7,tx,ty); ctx.stroke();
    }
    ctx.fillStyle='#0e0820';
    ctx.beginPath(); ctx.moveTo(-26,-22); ctx.quadraticCurveTo(-36,22,-30,58);
    ctx.quadraticCurveTo(-12,68,0,66); ctx.quadraticCurveTo(12,68,30,58);
    ctx.quadraticCurveTo(36,22,26,-22); ctx.closePath(); ctx.fill();
    const cl2=ctx.createLinearGradient(-20,-18,20,60);
    cl2.addColorStop(0,'rgba(50,20,100,0.8)'); cl2.addColorStop(1,'rgba(5,0,20,1)');
    ctx.fillStyle=cl2;
    ctx.beginPath(); ctx.moveTo(-18,-18); ctx.quadraticCurveTo(-20,16,-14,52);
    ctx.quadraticCurveTo(-4,60,0,58); ctx.quadraticCurveTo(4,60,14,52);
    ctx.quadraticCurveTo(20,16,18,-18); ctx.closePath(); ctx.fill();
    ctx.strokeStyle=`rgba(127,255,238,${0.25*p})`; ctx.lineWidth=1;
    for(let r=0;r<3;r++){
      ctx.save(); ctx.rotate(t*0.2*(r%2===0?1:-1));
      ctx.beginPath(); ctx.arc(0,10+r*16,10+r*3,0,Math.PI*2); ctx.stroke();
      for(let rm=0;rm<4;rm++){
        const ra=(Math.PI/2)*rm, rr=10+r*3;
        ctx.fillStyle=`rgba(127,255,238,${0.3*p})`;
        ctx.beginPath(); ctx.arc(Math.cos(ra)*rr,10+r*16+Math.sin(ra)*rr,1.5,0,Math.PI*2); ctx.fill();
      }
      ctx.restore();
    }
    const dh=(s)=>{
      ctx.save(); ctx.translate(s*16,-34); ctx.rotate(s*0.45);
      ctx.shadowColor='#7fffee'; ctx.shadowBlur=10;
      const hg=ctx.createLinearGradient(0,0,0,-28);
      hg.addColorStop(0,`rgba(60,180,160,${0.9*p})`); hg.addColorStop(1,`rgba(200,255,250,${p})`);
      ctx.fillStyle=hg; ctx.beginPath(); ctx.moveTo(-4,0); ctx.lineTo(-2,-28); ctx.lineTo(2,-28); ctx.lineTo(4,0); ctx.closePath(); ctx.fill();
      ctx.shadowBlur=0; ctx.restore();
    };
    dh(-1); dh(1);
    const hhg=ctx.createLinearGradient(-14,-46,14,-28);
    hhg.addColorStop(0,'#c0fff5'); hhg.addColorStop(0.45,'#7fffee'); hhg.addColorStop(0.55,'#301850'); hhg.addColorStop(1,'#08041a');
    ctx.fillStyle=hhg; ctx.beginPath(); ctx.ellipse(0,-38,15,12,0,0,Math.PI*2); ctx.fill();
    ctx.shadowColor='#7fffee'; ctx.shadowBlur=18; ctx.fillStyle='#7fffee';
    ctx.beginPath(); ctx.ellipse(-5,-40,4,2.8,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(5,-40,4,2.8,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='#003020';
    ctx.beginPath(); ctx.ellipse(-5,-40,2,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(5,-40,2,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#80ffee';
    ctx.beginPath(); ctx.arc(-4.2,-40.7,1,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(5.8,-40.7,1,0,Math.PI*2); ctx.fill();
    ctx.restore();
  },

  // ── PORTRAITS PNJ ────────────────────────────────────────
  portraitElias(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    ctx.fillStyle='#b89840'; ctx.beginPath(); ctx.ellipse(0,-22+0,13,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#c8a050'; [[-7,-24],[-2,-27],[4,-26]].forEach(([hx,hy])=>{ ctx.beginPath(); ctx.moveTo(hx-2,-20); ctx.lineTo(hx,hy); ctx.lineTo(hx+2,-20); ctx.closePath(); ctx.fill(); });
    ctx.fillStyle='#e8d8b0'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#6a5030'; ctx.beginPath(); ctx.ellipse(-3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#6a4820'; ctx.fillRect(-9,0,18,22);
    ctx.strokeStyle='#e8c96a'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(0,-24); ctx.lineTo(0,-40); ctx.stroke();
    ctx.fillStyle='#e8c96a'; ctx.beginPath(); ctx.arc(0,-41,3,0,Math.PI*2); ctx.fill();
    ctx.restore();
  },

  portraitValeriane(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    const t2=Date.now()*0.002;
    ctx.fillStyle='#2a5030'; ctx.beginPath(); ctx.ellipse(0,-22,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#4a8060';
    ctx.beginPath(); ctx.moveTo(-10,-22); ctx.quadraticCurveTo(-14+Math.sin(t2)*2,-8,-12+Math.sin(t2)*2,6); ctx.quadraticCurveTo(-7,10,-5,6); ctx.quadraticCurveTo(-3,-6,-10,-22); ctx.fill();
    ctx.fillStyle='#d8c8a0'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#5a4030'; ctx.beginPath(); ctx.ellipse(-3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#80c890'; ctx.strokeStyle='#80c890'; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(10,-4); ctx.lineTo(18,-14); ctx.stroke();
    ctx.beginPath(); ctx.arc(18,-16,3,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#4a6040'; ctx.fillRect(-9,-2,18,24);
    ctx.restore();
  },

  portraitTheo(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    ctx.fillStyle='#6a4a28'; ctx.beginPath(); ctx.ellipse(0,-22,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#e0c8a8'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#8098a0'; ctx.beginPath(); ctx.ellipse(-3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#8a7060'; ctx.fillRect(-9,-2,18,24);
    ctx.fillStyle='#d8c8a0'; ctx.fillRect(-7,-1,14,10);
    ctx.strokeStyle='#9a8860'; ctx.lineWidth=0.5;
    for(let sl=0;sl<3;sl++){ ctx.beginPath(); ctx.moveTo(-6,1+sl*3); ctx.lineTo(6,1+sl*3); ctx.stroke(); }
    for(let i=0;i<4;i++){
      const a=Date.now()*0.002+i*1.57, r=22;
      ctx.fillStyle=`rgba(58,207,170,${0.25+Math.sin(Date.now()*0.003+i)*0.15})`;
      ctx.beginPath(); ctx.arc(Math.cos(a)*r,Math.sin(a)*r*0.5-8,2,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  },

  portraitAldric(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    ctx.fillStyle='#404850'; ctx.beginPath(); ctx.ellipse(0,-22,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#b0b8c0'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#506070'; ctx.beginPath(); ctx.ellipse(-3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#304050'; ctx.fillRect(-9,-2,18,24);
    ctx.fillStyle='#485860'; ctx.fillRect(-8,-4,16,5);
    ctx.strokeStyle='#6080a0'; ctx.lineWidth=0.8;
    ctx.beginPath(); ctx.moveTo(-8,-4); ctx.lineTo(-8,20); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(8,-4); ctx.lineTo(8,20); ctx.stroke();
    ctx.restore();
  },

  portraitMordred(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    const t2=Date.now()*0.002;
    for(let s=0;s<3;s++){
      ctx.fillStyle=`rgba(30,10,60,${0.06-s*0.015})`;
      ctx.beginPath(); ctx.ellipse(Math.sin(t2+s)*3,s*4,20-s*3,14-s*2,0,0,Math.PI*2); ctx.fill();
    }
    ctx.fillStyle='#10081e'; ctx.beginPath(); ctx.ellipse(0,-14,12,14,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0a0618'; ctx.beginPath(); ctx.ellipse(0,-24,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-26,22,8);
    ctx.shadowColor='#c04030'; ctx.shadowBlur=10; ctx.fillStyle='#c04030';
    ctx.beginPath(); ctx.ellipse(-3.5,-16,3,2,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3.5,-16,3,2,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='#08040e'; ctx.fillRect(-12,-2,24,24);
    ctx.restore();
  },

  portraitVaeltharion(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    const t2=Date.now()*0.002, p=0.75+Math.sin(t2)*0.25;
    const og=ctx.createRadialGradient(0,0,5,0,0,40);
    og.addColorStop(0,`rgba(127,255,238,${0.3*p})`); og.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=og; ctx.beginPath(); ctx.arc(0,-5,40,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#0e0820'; ctx.beginPath(); ctx.ellipse(0,4,14,22,0,0,Math.PI*2); ctx.fill();
    const hg=ctx.createLinearGradient(-12,-30,12,-18);
    hg.addColorStop(0,'#c0fff5'); hg.addColorStop(0.5,'#7fffee'); hg.addColorStop(1,'#08041a');
    ctx.fillStyle=hg; ctx.beginPath(); ctx.ellipse(0,-22,12,11,0,0,Math.PI*2); ctx.fill();
    ctx.shadowColor='#7fffee'; ctx.shadowBlur=14; ctx.fillStyle='#7fffee';
    ctx.beginPath(); ctx.ellipse(-4,-24,3.5,2.5,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(4,-24,3.5,2.5,0,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0;
    ctx.restore();
  },

  portraitRust(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    ctx.fillStyle='#904020'; ctx.beginPath(); ctx.ellipse(0,-22,13,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-12,-24,24,8);
    ctx.fillStyle='#c08030'; ctx.beginPath(); ctx.moveTo(-7,-22); ctx.lineTo(-14,-14); ctx.lineTo(-11,-22); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(7,-22); ctx.lineTo(14,-14); ctx.lineTo(11,-22); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#e0c898'; ctx.beginPath(); ctx.ellipse(0,-12,12,14,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#501808'; ctx.beginPath(); ctx.ellipse(-3.5,-13,3,2.2,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,3,2.2,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#5a3020'; ctx.fillRect(-10,-2,20,24);
    ctx.fillStyle='#8a5030'; ctx.fillRect(-7,-4,14,4);
    ctx.fillStyle='#c0c8d0'; ctx.fillRect(10,-2,20,4); ctx.beginPath(); ctx.ellipse(30,-2,4,2,0,0,Math.PI*2); ctx.fill();
    ctx.restore();
  },

  portraitLuma(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    const t2=Date.now()*0.002;
    ctx.fillStyle='#c090ff'; ctx.beginPath(); ctx.ellipse(0,-22,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#c090ff';
    ctx.beginPath(); ctx.moveTo(-10,-18); ctx.quadraticCurveTo(-16+Math.sin(t2)*2,-6,-14+Math.sin(t2)*2,10); ctx.quadraticCurveTo(-8,14,-6,10); ctx.quadraticCurveTo(-4,-4,-10,-18); ctx.fill();
    ctx.fillStyle='#e0c0ff'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#8040c0'; ctx.beginPath(); ctx.ellipse(-3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3.5,-13,2.5,1.8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#50208a'; ctx.fillRect(-9,-2,18,24);
    ctx.fillStyle='#9060d0'; ctx.fillRect(-6,-4,12,4);
    ctx.fillStyle='#d0c0f8'; ctx.fillRect(-4,0,8,14);
    ctx.strokeStyle='#9060d0'; ctx.lineWidth=0.5;
    for(let sl=0;sl<4;sl++){ ctx.beginPath(); ctx.moveTo(-3,2+sl*3); ctx.lineTo(3,2+sl*3); ctx.stroke(); }
    ctx.restore();
  },

  portraitVieilHomme(ctx, x, y) {
    ctx.save(); ctx.translate(x,y);
    ctx.fillStyle='#8a7850'; ctx.beginPath(); ctx.ellipse(0,-22,12,7,0,0,Math.PI*2); ctx.fill(); ctx.fillRect(-11,-24,22,8);
    ctx.fillStyle='#c0b090';
    ctx.beginPath(); ctx.moveTo(-10,-22); ctx.quadraticCurveTo(-15,-10,-13,4); ctx.quadraticCurveTo(-8,8,-6,4); ctx.quadraticCurveTo(-4,-8,-10,-22); ctx.fill();
    ctx.beginPath(); ctx.moveTo(10,-22); ctx.quadraticCurveTo(15,-10,13,4); ctx.quadraticCurveTo(8,8,6,4); ctx.quadraticCurveTo(4,-8,10,-22); ctx.fill();
    ctx.fillStyle='#d8c8a0'; ctx.beginPath(); ctx.ellipse(0,-12,11,13,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#6a5030'; ctx.beginPath(); ctx.ellipse(-3,-13,2,1.5,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(3,-13,2,1.5,0,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle='#a89070'; ctx.lineWidth=0.5;
    ctx.beginPath(); ctx.moveTo(-4,-6); ctx.lineTo(4,-6); ctx.stroke();
    ctx.fillStyle='#6a5040'; ctx.fillRect(-9,-2,18,24);
    ctx.fillStyle='#7a6050'; ctx.fillRect(-8,-3,16,4);
    ctx.restore();
  },
};
