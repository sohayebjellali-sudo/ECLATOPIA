// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/dialogue.js
// Moteur de dialogue complet
// ═══════════════════════════════════════════════════════════

const Dialogue = {
  _state: null,
  _typingInt: null,
  _gs: null,
  _onClose: null,
  _portraitAnim: null,

  // ── OUVRIR DIALOGUE PNJ ───────────────────────────────────
  open(pnjKey, gs, onClose) {
    const pnjData = this._getPnjData(pnjKey);
    if (!pnjData) return;
    this._gs = gs;
    this._onClose = onClose;
    this._state = { pnjKey, pnjData, nodeId: 'start' };
    gs.inputLock = true; gs.dialogueOpen = true;

    // Portrait animé
    this._startPortraitAnim(pnjData);
    this._showNode('start');
    document.getElementById('dlg-box').classList.remove('hidden');
  },

  _getPnjData(key) {
    const map = {
      elias: typeof DLG_ELIAS !== 'undefined' ? DLG_ELIAS : null,
      valeriane: typeof DLG_VALERIANE !== 'undefined' ? DLG_VALERIANE : null,
      theo: typeof DLG_THEO !== 'undefined' ? DLG_THEO : null,
      aldric: typeof DLG_ALDRIC !== 'undefined' ? DLG_ALDRIC : null,
      mordred: typeof DLG_MORDRED !== 'undefined' ? DLG_MORDRED : null,
      vaeltharion: typeof DLG_VAELTHARION !== 'undefined' ? DLG_VAELTHARION : null,
      rust: typeof DLG_RUST !== 'undefined' ? DLG_RUST : null,
      luma: typeof DLG_LUMA !== 'undefined' ? DLG_LUMA : null,
      vieux_gardien: typeof DLG_VIEUX_GARDIEN !== 'undefined' ? DLG_VIEUX_GARDIEN : null,
    };
    return map[key] || null;
  },

  _startPortraitAnim(pnjData) {
    const pc = document.getElementById('dlg-canvas');
    const pctx = pc.getContext('2d');
    const fn = pnjData.portraitFn;
    if (this._portraitAnim) clearInterval(this._portraitAnim);
    this._portraitAnim = setInterval(() => {
      pctx.clearRect(0, 0, 110, 140);
      if (Sprites[fn]) Sprites[fn](pctx, 55, 100, 1);
    }, 80);

    document.getElementById('dlg-name').textContent  = pnjData.name;
    document.getElementById('dlg-name').style.color  = pnjData.color;
    document.getElementById('dlg-title').textContent = pnjData.title;
  },

  _showNode(nodeId) {
    const st = this._state; if (!st) return;
    const node = st.pnjData.nodes[nodeId];
    if (!node) { this.close(); return; }
    st.nodeId = nodeId;

    document.getElementById('dlg-choices').innerHTML = '';
    const textEl = document.getElementById('dlg-text');
    textEl.textContent = '';

    if (this._typingInt) clearInterval(this._typingInt);
    let idx = 0;
    const text = node.text || '';

    this._typingInt = setInterval(() => {
      if (idx < text.length) {
        textEl.textContent += text[idx++];
      } else {
        clearInterval(this._typingInt);
        textEl.onclick = null;
        this._showChoices(node);
      }
    }, 15);

    textEl.onclick = () => {
      if (idx < text.length) {
        clearInterval(this._typingInt);
        textEl.textContent = text;
        textEl.onclick = null;
        this._showChoices(node);
      }
    };
  },

  _showChoices(node) {
    const gs = this._gs;
    const choicesEl = document.getElementById('dlg-choices');
    choicesEl.innerHTML = '';
    if (!node.choices) return;

    node.choices.forEach(choice => {
      const btn = document.createElement('button');
      btn.className = 'dlg-btn';
      btn.textContent = choice.text;

      // Vérif items requis
      const needs = choice.needs;
      let locked = false;
      if (needs) {
        const arr = Array.isArray(needs) ? needs : [needs];
        locked = !arr.every(n => gs.player.inventory.includes(n));
        if (locked) { btn.classList.add('locked'); btn.title = `Nécessite : ${arr.join(', ')}`; }
      }

      btn.onclick = () => {
        if (locked) { UI.addMsg(`⚠ Il te faut : ${needs}`, '#e04060'); return; }
        this._applyEffects(choice.effects, gs);
        if (choice.close || choice.next === null) { this.close(); return; }
        if (choice.next) { this._showNode(choice.next); }
        else { this.close(); }
      };
      choicesEl.appendChild(btn);
    });
  },

  _applyEffects(fx, gs) {
    if (!fx) return;
    const p = gs.player;
    if (fx.morale !== undefined) gs.morale = Math.max(-100, Math.min(100, gs.morale + fx.morale));
    if (fx.item) {
      const id = fx.item;
      if (!p.inventory.includes(id)) {
        p.inventory.push(id);
        UI.addMsg(`✓ ${ITEMS[id]?.name || id} obtenu !`, '#e8c96a');
      }
    }
    if (fx.quest) {
      if (!p.quests.includes(fx.quest)) {
        p.quests.push(fx.quest);
        UI.addMsg(`📋 Quête : "${QUESTS[fx.quest]?.name || fx.quest}" démarrée !`, '#e8c96a');
        UI.updateQuestTracker(fx.quest, gs);
      }
    }
    if (fx.flag) gs.player.flags[fx.flag] = true;
    if (fx.buy) this._processBuy(fx.buy, gs);
    if (fx.heal) { p.curHp = Math.min(p.hp, p.curHp + fx.heal); }
  },

  _processBuy(buyDef, gs) {
    const p = gs.player;
    const item = ITEMS[buyDef.item];
    if (!item) { UI.addMsg('⚠ Objet introuvable.', '#e04060'); return; }
    if (p.gold < buyDef.cost) { UI.addMsg('⚠ Or insuffisant.', '#e04060'); return; }
    p.gold -= buyDef.cost;
    if (item.type === 'consumable') {
      p.inventory.push(buyDef.item);
      UI.addMsg(`✓ ${item.name} acheté.`, '#e8c96a');
    } else if (item.type === 'weapon') {
      if (p.equippedWeapon) { const old = ITEMS[p.equippedWeapon]; if(old?.atk) p.atk-=old.atk; if(old?.cursed) p.cursed=false; }
      p.equippedWeapon = buyDef.item; p.atk += item.atk||0;
      if (item.cursed) p.cursed = true;
      UI.addMsg(`⚔ ${item.name} équipé !`, '#e8c96a');
    } else if (item.type === 'armor') {
      if (p.equippedArmor) { const old = ITEMS[p.equippedArmor]; if(old?.def) p.def-=old.def; }
      p.equippedArmor = buyDef.item; p.def += item.def||0;
      UI.addMsg(`🛡 ${item.name} équipé !`, '#e8c96a');
    }
  },

  close() {
    if (this._typingInt) clearInterval(this._typingInt);
    if (this._portraitAnim) clearInterval(this._portraitAnim);
    document.getElementById('dlg-box').classList.add('hidden');
    if (this._gs) { this._gs.inputLock = false; this._gs.dialogueOpen = false; }
    const cb = this._onClose; this._state=null; this._gs=null; this._onClose=null;
    if (cb) cb();
  },

  // ── DIALOGUE BOSS PRE/POST ────────────────────────────────
  showBossPreDialogue(bossKey, gs, onDone) {
    const def = BOSS_TYPES[bossKey]; if (!def?.preDialogue) { onDone(); return; }
    gs.inputLock = true; gs.dialogueOpen = true;
    const box = document.getElementById('dlg-box');
    box.classList.remove('hidden');

    const pc = document.getElementById('dlg-canvas');
    const pctx = pc.getContext('2d');
    if (def.drawFn && Sprites[def.drawFn]) Sprites[def.drawFn](pctx, 55, 60, 0);
    document.getElementById('dlg-name').textContent  = def.name;
    document.getElementById('dlg-name').style.color  = def.col;
    document.getElementById('dlg-title').textContent = def.sub;

    let lineIdx = 0;
    const showLine = () => {
      if (lineIdx >= def.preDialogue.length) {
        this.close();
        gs.inputLock = false; gs.dialogueOpen = false;
        onDone(); return;
      }
      const line = def.preDialogue[lineIdx++];
      document.getElementById('dlg-text').textContent = line.text;
      document.getElementById('dlg-choices').innerHTML = '';
      const btn = document.createElement('button');
      btn.className = 'dlg-btn';
      btn.textContent = lineIdx < def.preDialogue.length ? 'Suite →' : '⚔ Combattre !';
      btn.onclick = showLine;
      document.getElementById('dlg-choices').appendChild(btn);
    };
    showLine();
  },

  // ── CHOIX BOSS POST-COMBAT ────────────────────────────────
  showBossChoices(bossKey, gs, onChoice) {
    const def  = BOSS_TYPES[bossKey]; if (!def) { onChoice(null); return; }
    const choices = def.choices || [];
    gs.inputLock = true; gs.dialogueOpen = true;

    const box = document.getElementById('dlg-box');
    box.classList.remove('hidden');

    const pc = document.getElementById('dlg-canvas');
    const pctx = pc.getContext('2d');
    if (def.drawFn && Sprites[def.drawFn]) Sprites[def.drawFn](pctx, 55, 60, 0);
    document.getElementById('dlg-name').textContent  = `Après la bataille — ${def.name}`;
    document.getElementById('dlg-name').style.color  = def.col;
    document.getElementById('dlg-title').textContent = def.sub;

    // Post dialogue d'abord
    const postLines = def.postDialogue || [];
    let lineIdx = 0;
    const showPost = () => {
      if (lineIdx < postLines.length) {
        const line = postLines[lineIdx++];
        document.getElementById('dlg-text').textContent = line.text;
        document.getElementById('dlg-choices').innerHTML = '';
        const btn = document.createElement('button');
        btn.className = 'dlg-btn';
        btn.textContent = lineIdx < postLines.length ? 'Suite →' : 'Que faire ?';
        btn.onclick = showPost;
        document.getElementById('dlg-choices').appendChild(btn);
      } else {
        // Afficher les choix
        document.getElementById('dlg-text').textContent = 'Que faites-vous ?';
        const choicesEl = document.getElementById('dlg-choices');
        choicesEl.innerHTML = '';
        choices.forEach(c => {
          const btn = document.createElement('button');
          btn.className = 'dlg-btn';
          btn.textContent = c.text;

          const needs = c.needs;
          let locked = false;
          if (needs) {
            const arr = Array.isArray(needs) ? needs : [needs];
            locked = !arr.every(n => gs.player.inventory.includes(n));
            if (locked) { btn.classList.add('locked'); btn.title=`Nécessite : ${arr.join(', ')}`; }
          }

          btn.onclick = () => {
            if (locked) { UI.addMsg(`⚠ Conditions non remplies.`, '#e04060'); return; }
            if (c.morale !== undefined) gs.morale = Math.max(-100, Math.min(100, gs.morale + c.morale));
            if (c.vide   !== undefined) gs.vide   = Math.max(0, Math.min(100, gs.vide + c.vide));
            if (c.item) { gs.player.inventory.push(c.item); UI.addMsg(`✓ ${ITEMS[c.item]?.name||c.item} obtenu !`, '#e8c96a'); }
            if (c.flag) gs.player.flags[c.flag] = true;
            box.classList.add('hidden');
            gs.inputLock = false; gs.dialogueOpen = false;
            onChoice(c.end || null);
          };
          choicesEl.appendChild(btn);
        });
      }
    };
    showPost();
  },

  // ── SCÈNE CINÉMATIQUE (Mines) ──────────────────────────────
  showCinemaScene(lines, choices, gs, onChoice) {
    gs.inputLock = true; gs.dialogueOpen = true;
    const box = document.getElementById('dlg-box');
    box.classList.remove('hidden');

    // Portrait vide / héros
    const pc = document.getElementById('dlg-canvas');
    const pctx = pc.getContext('2d');
    pctx.clearRect(0,0,110,140);
    const p = gs.player;
    if (CHARACTERS[p.id]?.drawFn && Sprites[CHARACTERS[p.id].drawFn]) {
      Sprites[CHARACTERS[p.id].drawFn](pctx, 55, 90, 0, 1, 'idle');
    }
    document.getElementById('dlg-name').style.color = '#b8c0d4';

    let lineIdx = 0;
    const showLine = () => {
      if (lineIdx < lines.length) {
        const line = lines[lineIdx++];
        document.getElementById('dlg-name').textContent = line.speaker;
        document.getElementById('dlg-name').style.color = line.color || '#b8c0d4';
        document.getElementById('dlg-text').textContent = line.text;
        document.getElementById('dlg-choices').innerHTML = '';
        const btn = document.createElement('button');
        btn.className = 'dlg-btn';
        btn.textContent = lineIdx < lines.length ? 'Suite →' : 'Que faire ?';
        btn.onclick = showLine;
        document.getElementById('dlg-choices').appendChild(btn);
      } else {
        // Afficher choix
        document.getElementById('dlg-text').textContent = 'Que faites-vous ?';
        const choicesEl = document.getElementById('dlg-choices');
        choicesEl.innerHTML = '';
        choices.forEach(c => {
          const btn = document.createElement('button');
          btn.className = 'dlg-btn';
          btn.textContent = c.text;
          const needs = c.needs;
          let locked = needs && !gs.player.inventory.includes(needs);
          if (locked) { btn.classList.add('locked'); btn.title = `Nécessite : ${needs}`; }
          btn.onclick = () => {
            if (locked) { UI.addMsg(`⚠ Il te faut : ${needs}`, '#e04060'); return; }
            if (c.effects?.morale) gs.morale=Math.max(-100,Math.min(100,gs.morale+c.effects.morale));
            if (c.effects?.vide)   gs.vide=Math.max(0,Math.min(100,gs.vide+c.effects.vide));
            if (c.effects?.flag)   gs.player.flags[c.effects.flag]=true;
            if (c.effects?.item) { gs.player.inventory.push(c.effects.item); UI.addMsg(`✓ ${ITEMS[c.effects.item]?.name||c.effects.item} obtenu !`,'#e8c96a'); }
            box.classList.add('hidden');
            gs.inputLock=false; gs.dialogueOpen=false;
            onChoice(c);
          };
          choicesEl.appendChild(btn);
        });
      }
    };
    showLine();
  },
};
