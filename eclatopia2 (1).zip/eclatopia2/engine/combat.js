// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/combat.js
// Logique de combat : attaque, pouvoir, bouclier, boss
// ═══════════════════════════════════════════════════════════

const Combat = {

  // ── ATTAQUE MELEE ────────────────────────────────────────
  playerMelee(gs) {
    const p = gs.player;
    if (p.atkTimer > 0 || gs.inputLock) return;
    p.atkTimer = p.atkCd;
    p.state = 'attack';

    const col = CHARACTERS[p.id]?.color || '#fff';
    Particles.spawnSlash(p.x + p.facing*40, p.y-10, p.facing, col);
    Particles.spawn(p.x + p.facing*40, p.y-10, col, 8, 4);

    // Kael génère aussi un projectile
    if (p.id === 'kael') {
      gs.playerProjs.push({
        x: p.x, y: p.y-5,
        vx: p.facing * 9, vy: 0,
        atk: Math.floor(p.atk * 0.55),
        col: '#80c0ff', life: 1000, maxLife: 1000, sz: 8,
      });
    }

    // Toucher ennemis
    gs.enemies.forEach(en => {
      if (en.curHp <= 0) return;
      if (Math.hypot(en.x-p.x, en.y-p.y) > p.atkRange) return;
      const dmg = this._calcDmg(p, en);
      this._applyDmgToEnemy(en, dmg, col, gs);
    });

    // Toucher boss
    if (gs.boss && !gs.boss.defeated) {
      if (Math.hypot(gs.boss.x-p.x, gs.boss.y-p.y) < p.atkRange + gs.boss.sz/2) {
        const dmg = this._calcDmg(p, gs.boss);
        this._applyDmgToBoss(gs.boss, dmg, col, gs);
      }
    }

    // Malus Lame des Condamnés
    if (p.cursed) {
      gs.morale = Math.max(-100, gs.morale - 5);
    }
  },

  // ── ATTAQUE DISTANCE ─────────────────────────────────────
  playerRanged(gs, dirX) {
    const p = gs.player;
    if (p.atkTimer > 0 || gs.inputLock) return;
    p.atkTimer = p.atkCd * 0.7;
    const col = CHARACTERS[p.id]?.color || '#fff';
    gs.playerProjs.push({
      x: p.x, y: p.y-5,
      vx: dirX * 8, vy: 0,
      atk: Math.floor(p.atk * 0.6),
      col, life: 1200, maxLife: 1200, sz: 9,
    });
    Particles.spawn(p.x, p.y, col, 5, 3);
  },

  // ── POUVOIR ──────────────────────────────────────────────
  playerPower(gs) {
    const p = gs.player;
    if (p.powerTimer > 0 || gs.inputLock) return;
    if (p.curMp < (CHARACTERS[p.id]?.powerMpCost||20)) {
      UI.addMsg('⚡ Énergie insuffisante !', '#4080e0'); return;
    }
    p.powerTimer = CHARACTERS[p.id]?.powerCd || 6000;
    p.curMp -= CHARACTERS[p.id]?.powerMpCost || 20;

    if (p.id === 'aelara') {
      p.shieldActive = true; p.shieldHits = 2; p.shieldTimer = 4000;
      Particles.spawn(p.x, p.y, '#a0c8ff', 20, 5);
      Particles.spawnRing(p.x, p.y, '#a0c8ff', 60);
      UI.addMsg('☀ Bouclier de Lumière ! (2 coups)', '#e8c96a');

    } else if (p.id === 'kael') {
      const teleX = p.x + p.facing * 160;
      Particles.spawn(p.x, p.y, 'rgba(60,0,120,0.9)', 15, 6);
      p.x = Math.max(-950, Math.min(950, teleX));
      Particles.spawn(p.x, p.y, '#4aacdf', 15, 6);
      Particles.spawnRing(p.x, p.y, '#4aacdf', 50);
      UI.addMsg('🗡 Téléportation !', '#4aacdf');

    } else if (p.id === 'theo') {
      gs.enemies.forEach(en => { en.revealed = true; });
      for (let r=1; r<=5; r++) {
        setTimeout(()=>Particles.spawnRing(p.x, p.y, '#3acfaa', r*28), r*60);
      }
      Particles.spawn(p.x, p.y, '#3acfaa', 20, 6);
      UI.addMsg('🗺 Révélation — Ennemis visibles !', '#3acfaa');
    }
  },

  // ── BOUCLIER ─────────────────────────────────────────────
  playerShield(gs) {
    const p = gs.player;
    if (p.shieldActive || p.shieldTimer > 0) return;
    p.shieldActive = true; p.shieldHits = 1; p.shieldTimer = 1800;
    Particles.spawn(p.x, p.y, '#40c080', 10, 3);
    UI.addMsg('🛡 Bouclier activé (1 coup)', '#40c080');
  },

  // ── SPRINT ───────────────────────────────────────────────
  getSpeed(p, running) {
    return running ? p.spd * 1.85 : p.spd;
  },

  // ── PROJECTILES JOUEUR ───────────────────────────────────
  updatePlayerProjs(gs, dt) {
    gs.playerProjs = gs.playerProjs.filter(pj => {
      pj.x += pj.vx*(dt/16.67); pj.y += pj.vy*(dt/16.67); pj.life -= dt;
      if (pj.life<=0 || Math.abs(pj.x-gs.player.x)>950) return false;
      let hit = false;
      gs.enemies.forEach(en => {
        if (hit||en.curHp<=0) return;
        if (Math.hypot(en.x-pj.x, en.y-pj.y) < en.sz/2+6) {
          hit=true;
          const dmg = Math.max(1, pj.atk - en.def + rnd(-2,2));
          this._applyDmgToEnemy(en, dmg, pj.col, gs);
          Particles.spawn(pj.x, pj.y, pj.col, 5, 3);
        }
      });
      if (!hit && gs.boss && !gs.boss.defeated) {
        if (Math.hypot(gs.boss.x-pj.x, gs.boss.y-pj.y) < gs.boss.sz/2+8) {
          hit=true;
          const dmg = Math.max(1, pj.atk - gs.boss.def + rnd(-3,3));
          this._applyDmgToBoss(gs.boss, dmg, pj.col, gs);
          Particles.spawn(pj.x, pj.y, pj.col, 5, 3);
        }
      }
      return !hit;
    });
  },

  // ── PROJECTILES BOSS ─────────────────────────────────────
  updateBossProjs(gs, dt) {
    const p = gs.player;
    gs.bossProjs = gs.bossProjs.filter(pj => {
      pj.x += pj.vx*(dt/16.67); pj.y += pj.vy*(dt/16.67); pj.life -= dt;
      if (pj.life<=0) return false;
      if (!p.invincible && Math.hypot(p.x-pj.x, p.y-pj.y) < 18) {
        let dmg = Math.max(1, Math.floor(pj.atk) - p.def + rnd(-2,2));
        if (p.shieldActive && p.shieldHits>0) {
          p.shieldHits--;
          if (p.shieldHits<=0) { p.shieldActive=false; p.shieldTimer=0; }
          dmg=0; Particles.spawn(p.x, p.y, '#40c080', 6, 3);
          UI.addMsg('🛡 Bloqué !', '#40c080');
        }
        if (dmg>0) {
          p.curHp -= dmg; p.invincible=true; p.invincibleTimer=600;
          DmgNums.add(p.x, p.y-40, `-${dmg}`, '#e04060', true);
          Particles.spawn(p.x, p.y, '#e04060', 6, 3);
          if (p.curHp<=0) { p.curHp=0; gs.screen='gameover'; }
        }
        return false;
      }
      return true;
    });
  },

  // ── CALCUL DÉGÂTS ────────────────────────────────────────
  _calcDmg(attacker, target) {
    const baseAtk = attacker.atk;
    const lameBonus = (attacker.equippedWeapon?.vsEveille && target.key==='eveille') ? attacker.equippedWeapon.vsEveille : 1;
    const dmg = Math.max(1, Math.floor(baseAtk * lameBonus) - target.def + rnd(-3,3));
    return dmg;
  },

  _applyDmgToEnemy(en, dmg, col, gs) {
    en.curHp -= dmg; en.hurtTimer = 220;
    DmgNums.add(en.x, en.y - en.sz/2-10, `-${dmg}`, '#fff');
    Particles.spawn(en.x, en.y, en.col, 6, 3.5);
    if (en.curHp <= 0) this._onEnemyDeath(en, gs);
  },

  _applyDmgToBoss(boss, dmg, col, gs) {
    boss.curHp = Math.max(0, boss.curHp - dmg);
    boss.hurtTimer = 200;
    DmgNums.add(boss.x, boss.y-boss.sz/2-14, `-${dmg}`, '#fff');
    Particles.spawn(boss.x, boss.y, boss.col, 8, 5);
    if (boss.curHp <= 0 && !boss.defeated) this._onBossDefeated(boss, gs);
  },

  _onEnemyDeath(en, gs) {
    const p = gs.player;
    const xp = en.xp||20, gold = rnd(...(en.gold||[5,15]));
    p.xp += xp; p.gold += gold;
    gs.morale = Math.max(-100, gs.morale + (en.moraleDrain||0));
    gs.vide = Math.min(100, gs.vide + (en.vidGain||0.4));
    Particles.spawnBurst(en.x, en.y, '#e8c96a');
    DmgNums.add(en.x, en.y-en.sz/2-24, `+${xp}XP`, '#e8c96a', true);
    this._checkLevelUp(p, gs);
  },

  _onBossDefeated(boss, gs) {
    boss.defeated = true;
    const p = gs.player;
    p.xp += boss.xp||300; p.gold += rnd(...(boss.gold||[80,150]));
    Particles.spawnBurst(boss.x, boss.y, boss.col);
    Particles.spawnBurst(boss.x, boss.y, '#e8c96a');
    UI.addMsg(`✓ ${boss.name} vaincu !`, boss.col);
    this._checkLevelUp(p, gs);

    // Débloquer zone suivante
    const nextZone = getNextZone(gs.currentZone);
    if (nextZone) {
      gs.unlockedZones.push(nextZone);
      UI.addMsg(`🗺 ${ZONE_DATA[nextZone]?.name} déverrouillée !`, ZONE_DATA[nextZone]?.accent||'#fff');
      gs.portalVisible = true;
    }
    Camera.shake(350);

    // Afficher choix post-combat
    setTimeout(() => {
      if (!boss.resolvedDialogue) {
        boss.resolvedDialogue = true;
        Dialogue.showBossChoices(boss.key, gs, (endId) => {
          if (endId) { gs.endingId = endId; gs.screen = 'ending'; }
        });
      }
    }, 700);
  },

  _checkLevelUp(p, gs) {
    while (p.xp >= p.xpToNext) {
      p.level++;
      p.xpToNext = Math.floor(p.xpToNext * 1.55);
      p.hp += 12; p.curHp = Math.min(p.curHp + 20, p.hp);
      p.mp += 8; p.curMp = Math.min(p.curMp + 12, p.mp);
      p.atk += 2; p.def += 1;
      UI.addMsg(`⬆ Niveau ${p.level} ! ATK+2 DEF+1 PV+12`, '#e8c96a');
      Particles.spawnBurst(p.x, p.y-20, '#e8c96a');
    }
  },
};

// ── AI ENNEMIS ────────────────────────────────────────────
const AI = {
  update(gs, dt) {
    const p = gs.player;
    gs.enemies = gs.enemies.filter(en => en.curHp > 0 || en.deathTimer > 0);

    gs.enemies.forEach(en => {
      if (en.curHp <= 0) {
        en.deathTimer = (en.deathTimer||400) - dt; return;
      }
      en.hurtTimer = Math.max(0, en.hurtTimer-dt);
      en.atkTimer  = Math.max(0, en.atkTimer-dt);
      en.frame = (en.frame||0)+1;

      const dx = p.x - en.x, dy = p.y - en.y;
      const dist = Math.hypot(dx,dy)||1;

      if (dist < 220) {
        if (dist > en.atkRange+4) {
          en.x += (dx/dist)*en.spd*(dt/16.67);
          en.y += (dy/dist)*en.spd*(dt/16.67);
        }
        en.facing = dx>0?1:-1;

        if (dist < en.atkRange && en.atkTimer<=0 && !p.invincible) {
          en.atkTimer = en.atkCd||1400;
          let dmg = Math.max(1, en.atk - p.def + rnd(-2,2));
          if (p.shieldActive && p.shieldHits>0) {
            p.shieldHits--; if(p.shieldHits<=0){p.shieldActive=false;p.shieldTimer=0;}
            dmg=0; Particles.spawn(p.x, p.y, '#40c080', 6, 3);
            UI.addMsg('🛡 Coup bloqué !', '#40c080');
          }
          if (dmg>0) {
            p.curHp-=dmg; p.invincible=true; p.invincibleTimer=700;
            DmgNums.add(p.x, p.y-40, `-${dmg}`, '#e04060', true);
            Particles.spawn(p.x, p.y, '#e04060', 5, 3);
            if (p.curHp<=0) { p.curHp=0; gs.screen='gameover'; }
          }
        }
      } else {
        en.x += (Math.random()-0.5)*0.4;
      }
      en.y = Math.max(-65, Math.min(65, en.y));
      en.x = Math.max(-980, Math.min(980, en.x));
    });
  },
};

// ── BOSS AI ───────────────────────────────────────────────
const BossAI = {
  update(boss, playerX, playerY, dt, gs) {
    if (!boss || boss.defeated) return;
    const def = BOSS_TYPES[boss.key]; if (!def) return;
    boss.frame = (boss.frame||0)+1;
    boss.patTimer = (boss.patTimer||0)+dt;
    boss.hurtTimer = Math.max(0, (boss.hurtTimer||0)-dt);

    // Phase check
    const ratio = boss.curHp/boss.hp;
    for (let i=def.phases.length-1; i>=0; i--) {
      if (ratio <= def.phases[i].threshold) {
        if (i > (boss.phase||0)) {
          boss.phase = i;
          UI.showPhaseFlash(def.phases[i].msg, boss.col);
          Camera.shake(400);
        }
        break;
      }
    }

    const ph  = def.phases[boss.phase||0];
    const am  = ph.atkMult||1;
    const dx  = playerX - boss.x, dy = playerY - boss.y;
    const dn  = Math.hypot(dx,dy)||1;
    const t   = boss.frame*0.05;

    const mkP = (vx,vy,mult=0.45) => ({
      x:boss.x, y:boss.y, vx, vy,
      atk: def.atk*am*mult, col: boss.col,
      life:3200, maxLife:3200, sz: 10,
    });

    switch (ph.pattern) {
      case 'orbit':
        boss.orbitAngle=(boss.orbitAngle||0)+dt*0.0012;
        boss.x=playerX+Math.cos(boss.orbitAngle)*200; boss.y=playerY+Math.sin(boss.orbitAngle)*80;
        if(boss.patTimer>1800){boss.patTimer=0; for(let a=0;a<4;a++){const ag=(Math.PI*2*a)/4+boss.orbitAngle; gs.bossProjs.push(mkP(Math.cos(ag)*3.5,Math.sin(ag)*3.5));}}
        break;
      case 'burst':
        boss.x+=(dx/dn)*0.7; boss.y+=(dy/dn)*0.7;
        if(boss.patTimer>900){boss.patTimer=0; const c=7+boss.phase; for(let a=0;a<c;a++){const ag=(Math.PI*2*a)/c; gs.bossProjs.push(mkP(Math.cos(ag)*4.8,Math.sin(ag)*4.8));}}
        break;
      case 'charge':
        if(boss.patTimer>1400){boss.patTimer=0; boss.vx=dx/dn*6; boss.vy=dy/dn*6;}
        boss.x+=boss.vx||0; boss.y+=boss.vy||0; boss.vx=(boss.vx||0)*0.91; boss.vy=(boss.vy||0)*0.91;
        if(boss.patTimer>700){gs.bossProjs.push(mkP(dx/dn*4.5,dy/dn*4.5,0.55)); boss.patTimer=0;}
        break;
      case 'stomp':
        boss.x+=(dx/dn)*0.5; boss.y+=(dy/dn)*0.5;
        if(boss.patTimer>2400){boss.patTimer=0; for(let a=0;a<8;a++){const ag=(Math.PI*2*a)/8; gs.bossProjs.push(mkP(Math.cos(ag)*5,Math.sin(ag)*5,0.6));}}
        break;
      case 'slam':
        if(boss.patTimer>1200){boss.patTimer=0; boss.vx=dx/dn*8; boss.vy=dy/dn*8;}
        boss.x+=boss.vx||0; boss.y+=boss.vy||0; boss.vx=(boss.vx||0)*0.88; boss.vy=(boss.vy||0)*0.88;
        break;
      case 'shatter':
        boss.x+=(dx/dn)*1.4; boss.y+=(dy/dn)*1.4;
        if(boss.patTimer>550){boss.patTimer=0; for(let i=0;i<4;i++){const ag=Math.atan2(dy,dx)+(i-1.5)*0.45; gs.bossProjs.push(mkP(Math.cos(ag)*6,Math.sin(ag)*6,0.8));}}
        break;
      case 'charm':
        boss.x=playerX+Math.cos(t*0.8)*160; boss.y=playerY+Math.sin(t*0.8)*50;
        if(boss.patTimer>1700){boss.patTimer=0; gs.bossProjs.push(mkP(dx/dn*3.5,dy/dn*3.5,0.5));}
        break;
      case 'wave':
        boss.x+=(dx/dn)*0.95; boss.y+=(dy/dn)*0.95;
        if(boss.patTimer>850){boss.patTimer=0; for(let i=-2;i<=2;i++){const ag=Math.atan2(dy,dx)+i*0.28; gs.bossProjs.push(mkP(Math.cos(ag)*5.2,Math.sin(ag)*5.2,0.48));}}
        break;
      case 'vortex':
        boss.orbitAngle=(boss.orbitAngle||0)+dt*0.0035;
        if(boss.patTimer>380){boss.patTimer=0; for(let a=0;a<10;a++){const ag=boss.orbitAngle+(Math.PI*2*a)/10; gs.bossProjs.push(mkP(Math.cos(ag)*6.5,Math.sin(ag)*6.5,0.4));}}
        break;
      case 'pulse':
        boss.x=playerX+Math.sin(t*0.7)*80; boss.y=playerY+Math.cos(t*0.9)*50;
        if(boss.patTimer>1900){boss.patTimer=0; for(let a=0;a<6;a++){const ag=(Math.PI*2*a)/6; gs.bossProjs.push(mkP(Math.cos(ag)*3.8,Math.sin(ag)*3.8,0.5));}}
        break;
      case 'spiral':
        boss.x+=(dx/dn)*1.15; boss.y+=(dy/dn)*1.15;
        if(boss.patTimer>650){boss.patTimer=0; boss.orbitAngle=(boss.orbitAngle||0)+0.2; for(let a=0;a<8;a++){const ag=(Math.PI*2*a)/8+boss.orbitAngle; gs.bossProjs.push(mkP(Math.cos(ag)*5.5,Math.sin(ag)*5.5,0.45));}}
        break;
      case 'darkness':
        boss.x+=(dx/dn)*2; boss.y+=(dy/dn)*2;
        if(boss.patTimer>480){boss.patTimer=0;
          gs.bossProjs.push(mkP(dx/dn*8,dy/dn*8,0.75));
          const p2={x:-dy/dn,y:dx/dn};
          gs.bossProjs.push(mkP(p2.x*4,p2.y*4,0.5)); gs.bossProjs.push(mkP(-p2.x*4,-p2.y*4,0.5));
        }
        break;
      case 'void':
        boss.x=playerX; boss.y=playerY;
        if(boss.patTimer>280){boss.patTimer=0; boss.orbitAngle=(boss.orbitAngle||0)+0.15; for(let a=0;a<14;a++){const ag=(Math.PI*2*a)/14+boss.orbitAngle; gs.bossProjs.push(mkP(Math.cos(ag)*7,Math.sin(ag)*7,0.55));}}
        break;
    }

    boss.x = Math.max(-900, Math.min(900, boss.x));
    boss.y = Math.max(-60, Math.min(60, boss.y));
    boss.facing = boss.x > playerX ? -1 : 1;
  },
};

function rnd(a,b) { return Math.floor(a+Math.random()*(b-a+1)); }
