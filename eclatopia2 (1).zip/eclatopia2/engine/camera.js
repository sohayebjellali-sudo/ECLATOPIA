// ÉCLATOPIA 2 — engine/camera.js (séparé de particles.js)
// Camera est défini dans particles.js - ce fichier est un placeholder
// pour la compatibilité avec index.html
// Camera, Particles, DmgNums sont tous dans engine/particles.js
