// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/particles.js + camera.js
// ═══════════════════════════════════════════════════════════

// ── PARTICLES ─────────────────────────────────────────────
const Particles = {
  list: [],

  spawn(x, y, col, n=8, spd=3, big=false) {
    for (let i=0; i<n; i++) {
      const a = Math.random()*Math.PI*2;
      const s = spd*(0.5+Math.random());
      this.list.push({
        x, y, col,
        vx: Math.cos(a)*s, vy: Math.sin(a)*s,
        life: 600+Math.random()*400, maxLife: 1000,
        sz: big ? 4+Math.random()*4 : 2+Math.random()*3,
        isSlash: false, isRing: false,
      });
    }
  },

  spawnSlash(x, y, dir, col) {
    for (let i=0; i<3; i++) {
      this.list.push({
        x, y, col, vx: dir*(3+i*2), vy:(i-1)*1.5,
        life:280, maxLife:280, sz:0,
        isSlash:true, w:36+i*10, h:4-i, rot:(i-1)*0.25,
      });
    }
  },

  spawnRing(x, y, col, radius) {
    this.list.push({ x, y, col, vx:0, vy:0, isRing:true, r:radius, life:500, maxLife:500 });
  },

  spawnBurst(x, y, col, n=12) {
    for (let i=0; i<n; i++) {
      const a=(Math.PI*2*i)/n;
      this.list.push({
        x, y, col,
        vx: Math.cos(a)*5, vy: Math.sin(a)*5,
        life:800, maxLife:800, sz:3+Math.random()*3,
        isSlash:false, isRing:false,
      });
    }
  },

  update(dt) {
    this.list = this.list.filter(pt => {
      pt.x += (pt.vx||0)*(dt/16.67);
      pt.y += (pt.vy||0)*(dt/16.67);
      pt.vx = (pt.vx||0)*0.93;
      pt.vy = (pt.vy||0)*0.93;
      pt.life -= dt;
      return pt.life > 0;
    });
  },

  draw(ctx) {
    this.list.forEach(pt => {
      const alpha = pt.life/pt.maxLife;
      ctx.save(); ctx.globalAlpha = alpha;
      if (pt.isSlash) {
        ctx.translate(pt.x, pt.y); ctx.rotate(pt.rot||0);
        ctx.fillStyle = pt.col; ctx.fillRect(0, -(pt.h/2), pt.w, pt.h);
      } else if (pt.isRing) {
        const growR = pt.r*(1-alpha*0.4);
        ctx.strokeStyle = pt.col; ctx.lineWidth=2.5;
        ctx.beginPath(); ctx.arc(pt.x, pt.y, growR, 0, Math.PI*2); ctx.stroke();
      } else {
        ctx.fillStyle = pt.col;
        ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.sz/2, 0, Math.PI*2); ctx.fill();
      }
      ctx.restore();
    });
  },

  clear() { this.list = []; },
};

// ── DAMAGE NUMBERS ────────────────────────────────────────
const DmgNums = {
  list: [],

  add(x, y, text, col, big=false) {
    this.list.push({ x, y, text, col, big, life:950, maxLife:950 });
  },

  update(dt) {
    this.list = this.list.filter(dn => {
      dn.y -= 0.45*(dt/16.67);
      dn.life -= dt;
      return dn.life > 0;
    });
  },

  draw(ctx) {
    this.list.forEach(dn => {
      ctx.save();
      ctx.globalAlpha = dn.life/dn.maxLife;
      ctx.fillStyle = dn.col;
      ctx.font = `bold ${dn.big?16:12}px monospace`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(dn.text, dn.x, dn.y);
      ctx.restore();
    });
  },

  clear() { this.list = []; },
};

// ── CAMERA ────────────────────────────────────────────────
const Camera = {
  x: 0, y: 0,
  shakeTimer: 0,
  shakeX: 0, shakeY: 0,

  follow(targetX, targetY, speed=0.09) {
    this.x += (targetX - this.x) * speed;
    this.y += (targetY - this.y) * speed;
  },

  shake(duration=300) {
    this.shakeTimer = duration;
  },

  update(dt) {
    this.shakeTimer = Math.max(0, this.shakeTimer - dt);
    if (this.shakeTimer > 0) {
      const intensity = (this.shakeTimer/300)*6;
      this.shakeX = (Math.random()-0.5)*intensity;
      this.shakeY = (Math.random()-0.5)*intensity*0.6;
    } else {
      this.shakeX = 0; this.shakeY = 0;
    }
  },

  applyTransform(ctx, W, H, groundY) {
    ctx.translate(
      W/2 - this.x + this.shakeX,
      groundY - this.y*0.15 + this.shakeY
    );
  },

  worldToScreen(wx, wy, W, H, groundY) {
    return {
      x: wx - this.x + W/2,
      y: wy + groundY,
    };
  },

  reset() {
    this.x=0; this.y=0; this.shakeTimer=0; this.shakeX=0; this.shakeY=0;
  },
};
