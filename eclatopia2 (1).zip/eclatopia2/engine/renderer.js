// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/renderer.js
// Rendu complet du monde
// ═══════════════════════════════════════════════════════════

const Renderer = {

  draw(ctx, gs, W, H) {
    const zone = ZONE_DATA[gs.currentZone] || ZONE_DATA.foret;
    const gY   = H * zone.groundY;
    const t    = Date.now();

    ctx.clearRect(0, 0, W, H);

    // Filtre gris si Lame des Condamnés équipée
    if (gs.player?.cursed) {
      const s = Math.max(0.05, 1-(gs.vide/100)*0.95);
      ctx.filter = `saturate(${s})`;
    }

    // ── FOND DE ZONE ──────────────────────────────────────
    this._drawZoneBg(ctx, gs.currentZone, W, H, gY, t);

    // ── TRANSFORM MONDE ───────────────────────────────────
    ctx.save();
    Camera.applyTransform(ctx, W, H, gY);

    // ── STÈLES ────────────────────────────────────────────
    if (gs.currentZone === 'foret' && gs.steles) {
      gs.steles.forEach((st, i) => {
        const found = gs.steleFound?.includes(i);
        const near  = Math.abs((gs.player?.x||0) - st.x) < 65;
        this._drawStele(ctx, st.x, 0, found, near, t);
      });
    }

    // ── OBJETS CACHÉS ─────────────────────────────────────
    (gs.hiddenItems||[]).forEach(hi => {
      if (hi.collected) return;
      const near = Math.abs((gs.player?.x||0) - hi.x) < 60;
      if (near) {
        ctx.shadowColor = zone.accent; ctx.shadowBlur = 12;
        ctx.fillStyle = zone.accent;
        ctx.font = '11px monospace'; ctx.textAlign = 'center';
        ctx.fillText(hi.label||'?', hi.x, -50);
        ctx.shadowBlur = 0;
      }
      this._drawPickup(ctx, hi.x, 0, zone.accent, t);
    });

    // ── PORTAIL ───────────────────────────────────────────
    if (gs.portalVisible) {
      const nz = getNextZone(gs.currentZone);
      if (nz) this._drawPortal(ctx, 900, 0, nz, t);
    }

    // ── PNJ ───────────────────────────────────────────────
    const zonePnjs = zone.pnjs || [];
    zonePnjs.forEach(pnjDef => {
      const data = this._getPnjData(pnjDef.key);
      if (!data) return;
      const near = Math.abs((gs.player?.x||0) - pnjDef.x) < 80;
      ctx.save(); ctx.translate(pnjDef.x, 0);
      if (Sprites[data.portraitFn]) Sprites[data.portraitFn](ctx, 0, 0);
      ctx.fillStyle = data.color; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center';
      ctx.fillText(data.name, 0, -60);
      ctx.fillStyle = `${data.color}80`; ctx.font = '8px monospace';
      ctx.fillText(data.title || pnjDef.label || '', 0, -50);
      if (near) {
        ctx.shadowColor = data.color; ctx.shadowBlur = 14;
        ctx.strokeStyle = data.color; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(0, -20, 40, 0, Math.PI*2); ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#ffffffcc'; ctx.font = 'bold 9px monospace';
        ctx.fillText('[F] Parler', 0, -78);
      }
      ctx.restore();
    });

    // ── ENNEMIS ───────────────────────────────────────────
    gs.enemies.forEach(en => {
      if (en.curHp<=0 && !en.deathTimer) return;
      const fadeA = en.curHp<=0 ? Math.max(0,(en.deathTimer||0)/400) : 1;
      ctx.save();
      if (en.hurtTimer>0) ctx.filter = 'brightness(3)';
      ctx.globalAlpha = fadeA;
      const drawFn = ENEMY_TYPES[en.type]?.drawFn;
      if (drawFn && Sprites[drawFn]) Sprites[drawFn](ctx, en.x, en.y, en.frame||0);
      ctx.filter='none'; ctx.globalAlpha=1;
      if (en.curHp>0) {
        const bw = en.sz+8, hp = en.curHp/en.hp;
        ctx.fillStyle='#22222288'; ctx.fillRect(en.x-bw/2, en.y-en.sz/2-14, bw, 6);
        ctx.fillStyle = hp>.5?'#40c040':hp>.25?'#e08040':'#e04060';
        ctx.fillRect(en.x-bw/2, en.y-en.sz/2-14, bw*hp, 6);
        ctx.fillStyle='#ccc'; ctx.font='8px monospace'; ctx.textAlign='center';
        ctx.fillText(en.name, en.x, en.y-en.sz/2-18);
      }
      ctx.restore();
    });

    // ── BOSS ──────────────────────────────────────────────
    if (gs.boss && !gs.boss.defeated) {
      ctx.save();
      if (gs.boss.hurtTimer>0) ctx.filter='brightness(2.5)';
      const bDrawFn = BOSS_TYPES[gs.boss.key]?.drawFn;
      if (bDrawFn && Sprites[bDrawFn]) Sprites[bDrawFn](ctx, gs.boss.x, gs.boss.y, gs.boss.frame||0);
      ctx.filter='none';
      const bphase = BOSS_TYPES[gs.boss.key]?.phases?.[gs.boss.phase||0];
      if (bphase?.msg) {
        const a=0.5+Math.sin(t*0.003)*0.35;
        ctx.fillStyle=`rgba(${gs.boss.col==='#7fffee'?'127,255,238':'224,64,96'},${a})`;
        ctx.font='9px monospace'; ctx.textAlign='center';
        ctx.fillText(bphase.msg, gs.boss.x, gs.boss.y-gs.boss.sz/2-30);
      }
      ctx.restore();
    }

    // ── PROJECTILES BOSS ──────────────────────────────────
    gs.bossProjs.forEach(pj => {
      ctx.save(); ctx.globalAlpha=pj.life/pj.maxLife;
      ctx.shadowColor=pj.col; ctx.shadowBlur=8; ctx.fillStyle=pj.col;
      ctx.beginPath(); ctx.arc(pj.x, pj.y, pj.sz/2, 0, Math.PI*2); ctx.fill();
      ctx.shadowBlur=0; ctx.restore();
    });

    // ── PROJECTILES JOUEUR ────────────────────────────────
    gs.playerProjs.forEach(pj => {
      ctx.save(); ctx.globalAlpha=pj.life/pj.maxLife;
      ctx.shadowColor=pj.col; ctx.shadowBlur=7; ctx.fillStyle=pj.col;
      ctx.beginPath(); ctx.arc(pj.x, pj.y, pj.sz/2, 0, Math.PI*2); ctx.fill();
      ctx.shadowBlur=0; ctx.restore();
    });

    // ── PARTICULES ────────────────────────────────────────
    Particles.draw(ctx);

    // ── JOUEUR ────────────────────────────────────────────
    const p = gs.player;
    if (p) {
      ctx.save();
      if (p.invincible && Math.floor(t/70)%2===0) ctx.globalAlpha=0.35;
      if (p.shieldActive) { ctx.shadowColor='#40c080'; ctx.shadowBlur=18; }
      const pDrawFn = CHARACTERS[p.id]?.drawFn;
      if (pDrawFn && Sprites[pDrawFn]) Sprites[pDrawFn](ctx, p.x, p.y, gs.frame, p.facing, p.state);
      ctx.shadowBlur=0; ctx.globalAlpha=1;
      if (p.shieldActive) {
        const pr=28+Math.sin(t*0.006)*4;
        ctx.strokeStyle=`rgba(64,192,128,${0.5+Math.sin(t*0.006)*0.2})`; ctx.lineWidth=2.5;
        ctx.beginPath(); ctx.arc(p.x, p.y, pr, 0, Math.PI*2); ctx.stroke();
      }
      ctx.restore();
    }

    // ── DAMAGE NUMBERS ────────────────────────────────────
    DmgNums.draw(ctx);

    ctx.restore(); // fin transform monde
    ctx.filter='none';

    // ── OVERLAYS POST-TRANSFORM ───────────────────────────
    // Danger Vide
    if (gs.vide > 70) {
      const v=(gs.vide-70)/30;
      ctx.strokeStyle=`rgba(200,30,60,${v*0.6+Math.sin(t*0.005)*0.1})`; ctx.lineWidth=6;
      ctx.strokeRect(0,0,W,H);
      if (gs.vide>85) {
        ctx.fillStyle=`rgba(200,30,60,${(gs.vide-85)/100*0.08})`; ctx.fillRect(0,0,W,H);
        ctx.fillStyle=`rgba(255,60,80,${0.5+Math.sin(t*0.005)*0.3})`;
        ctx.font=`${Math.min(W*0.025,12)}px monospace`; ctx.textAlign='center';
        ctx.fillText(`⚠ VIDE CRITIQUE — ${Math.round(gs.vide)}% — [B] Briser le Lien`, W/2, 30);
      }
    }

    // Monde gris si cursed
    if (p?.cursed) {
      ctx.filter='none';
    }
  },

  // ── FOND ZONE ─────────────────────────────────────────────
  _drawZoneBg(ctx, zoneId, W, H, gY, t) {
    const z = ZONE_DATA[zoneId] || ZONE_DATA.foret;

    // Ciel
    const sky = ctx.createLinearGradient(0,0,0,H*gY);
    sky.addColorStop(0, z.bgTop); sky.addColorStop(1, z.bgBot);
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H*gY);

    if      (zoneId==='foret')    this._drawForetBg(ctx,W,H,gY,t);
    else if (zoneId==='montagne') this._drawMontagneBg(ctx,W,H,gY,t);
    else if (zoneId==='cite')     this._drawCiteBg(ctx,W,H,gY,t);
    else if (zoneId==='abysse')   this._drawAbysseBg(ctx,W,H,gY,t);

    // Sol
    ctx.fillStyle=z.groundColor; ctx.fillRect(0,H*gY,W,H*(1-gY));
    ctx.fillStyle=z.groundLine;  ctx.fillRect(0,H*gY-2,W,10);

    // Brouillard
    ctx.fillStyle=z.fogColor; ctx.fillRect(0,H*gY-40,W,80);

    // Vignette
    const vig=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*0.3,W/2,H/2,Math.max(W,H)*0.8);
    vig.addColorStop(0,'rgba(0,0,0,0)'); vig.addColorStop(1,'rgba(0,0,0,0.5)');
    ctx.fillStyle=vig; ctx.fillRect(0,0,W,H);
  },

  _drawForetBg(ctx,W,H,gY,t) {
    for (let tx=-1600;tx<2000;tx+=120) {
      const sx=tx-Camera.x*0.85+W/2;
      if(sx<-120||sx>W+120) continue;
      const sway=Math.sin(t*0.0005+tx*0.007)*2.5, h=70+Math.abs(tx%40);
      ctx.fillStyle='#2a1e10'; ctx.fillRect(sx-5,H*gY-h*0.4,10,h*0.4+2);
      [[0,'#0d1e0a',28],[1,'#112212',22],[2,'#162a14',16]].forEach(([layer,col,w])=>{
        ctx.fillStyle=col; ctx.beginPath();
        ctx.moveTo(sx+sway*(0.3+layer*0.2),H*gY-h*0.38-layer*22);
        ctx.lineTo(sx-w+sway*0.5,H*gY-h*0.38-layer*22+24);
        ctx.lineTo(sx+w+sway*0.5,H*gY-h*0.38-layer*22+24); ctx.closePath(); ctx.fill();
      });
    }
    // Lune
    const mx=W*0.8-Camera.x*0.05;
    const mg=ctx.createRadialGradient(mx,H*0.1,5,mx,H*0.1,60);
    mg.addColorStop(0,'rgba(200,220,180,0.15)'); mg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=mg; ctx.beginPath(); ctx.arc(mx,H*0.1,60,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#d8e8c0'; ctx.beginPath(); ctx.arc(mx,H*0.1,16,0,Math.PI*2); ctx.fill();
    // Lucioles
    for(let f=0;f<8;f++){
      const fa=Math.sin(t*0.0007+f*1.3), fx=((-Camera.x*0.6+f*300+Math.sin(t*0.0004+f)*60)%(W+200))-100;
      const fy=H*(gY-0.2)+Math.sin(t*0.001+f*0.9)*30, falpha=0.4+fa*0.35;
      if(falpha>0){ctx.shadowColor='#a0e080';ctx.shadowBlur=8;ctx.fillStyle=`rgba(160,220,120,${falpha})`;ctx.beginPath();ctx.arc(fx,fy,2,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;}
    }
  },

  _drawMontagneBg(ctx,W,H,gY,t){
    [[0.2,0.6,0.25],[0.5,0.7,0.35],[0.8,0.5,0.5]].forEach(([rx,rh,dk],mi)=>{
      const bx=rx*3000-Camera.x*(0.2+mi*0.15)+W/2, sz=280+mi*40;
      ctx.fillStyle=`rgba(${Math.floor(40*dk)},${Math.floor(30*dk)},${Math.floor(18*dk)},0.92)`;
      for(let mx=bx-sz*2;mx<bx+sz*3;mx+=sz*1.8){
        ctx.beginPath(); ctx.moveTo(mx-sz*0.8,H*gY); ctx.lineTo(mx,H*rh); ctx.lineTo(mx+sz*0.8,H*gY); ctx.closePath(); ctx.fill();
      }
    });
    // Étoiles
    for(let s=0;s<20;s++){
      const sx=(s*173+50)%W, sy=H*0.05+(s*97)%(H*0.45), sa=0.3+Math.sin(t*0.0008+s)*0.2;
      ctx.fillStyle=`rgba(200,210,200,${sa})`; ctx.beginPath(); ctx.arc(sx,sy,0.8,0,Math.PI*2); ctx.fill();
    }
  },

  _drawCiteBg(ctx,W,H,gY,t){
    for(let r=0;r<5;r++){
      const rx=W*(0.1+r*0.2)+Math.sin(t*0.0002+r)*20;
      ctx.strokeStyle=`rgba(60,140,200,${0.04+Math.sin(t*0.0005+r)*0.02})`; ctx.lineWidth=12+r*4;
      ctx.beginPath(); ctx.moveTo(rx,0); ctx.lineTo(rx+20,H*gY); ctx.stroke();
    }
    for(let px=-1200;px<1600;px+=180){
      const sx=px-Camera.x*0.75+W/2; if(sx<-100||sx>W+100) continue;
      const ph=80+Math.abs(px%60);
      ctx.fillStyle='#101e30'; ctx.fillRect(sx-12,H*gY-ph,24,ph);
      ctx.fillStyle='#1a2a40'; ctx.fillRect(sx-16,H*gY-ph-6,32,8);
    }
    for(let b=0;b<12;b++){
      const bx=((-Camera.x*0.5+b*160)%(W+100))-50, by=H*gY-((t*0.02+b*50)%(H*gY));
      ctx.strokeStyle=`rgba(80,160,220,${0.15+(b%3)*0.05})`; ctx.lineWidth=1;
      ctx.beginPath(); ctx.arc(bx,by,3+b%4,0,Math.PI*2); ctx.stroke();
    }
  },

  _drawAbysseBg(ctx,W,H,gY,t){
    ctx.fillStyle='#030208'; ctx.fillRect(0,0,W,H);
    ctx.shadowColor='#e04060'; ctx.shadowBlur=8;
    for(let i=0;i<10;i++){
      const cx=(i*237-Camera.x*0.3+W/2)%(W+200)-100, alpha=0.08+Math.sin(t*0.0004+i)*0.04;
      ctx.strokeStyle=`rgba(200,60,80,${alpha})`; ctx.lineWidth=1+i%3*0.5;
      ctx.beginPath(); ctx.moveTo(cx,H*0.2+i*15); ctx.lineTo(cx+35+i*5,H*0.48+i*10); ctx.lineTo(cx-20,H*gY-10+i*8); ctx.stroke();
    }
    ctx.shadowBlur=0;
    const bg=ctx.createRadialGradient(W,H*0.5,10,W,H*0.5,200);
    bg.addColorStop(0,'rgba(200,30,60,0.12)'); bg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=bg; ctx.fillRect(0,0,W,H);
  },

  _drawStele(ctx, x, y, found, near, t) {
    ctx.save(); ctx.translate(x, y);
    ctx.fillStyle='#2a2218'; ctx.fillRect(-8,-55,16,55); ctx.fillRect(-12,-58,24,8);
    ctx.fillStyle='#3a3228'; ctx.fillRect(-6,-50,12,40);
    if (found) {
      ctx.shadowColor='#e8c96a'; ctx.shadowBlur=8;
      ctx.strokeStyle='#c8a850'; ctx.lineWidth=0.8;
      for(let sl=0;sl<5;sl++){ ctx.beginPath(); ctx.moveTo(-4,-44+sl*8); ctx.lineTo(4,-44+sl*8); ctx.stroke(); }
      ctx.shadowBlur=0;
    } else {
      const g=0.3+Math.sin(t*0.002)*0.15;
      ctx.fillStyle=`rgba(232,201,106,${g})`; ctx.font='8px monospace'; ctx.textAlign='center';
      ctx.fillText('?',0,-30);
    }
    if (near) {
      ctx.fillStyle='rgba(232,201,106,0.7)'; ctx.font='9px monospace'; ctx.textAlign='center';
      ctx.fillText('[F] Lire',0,-66);
    }
    ctx.restore();
  },

  _drawPickup(ctx, x, y, col, t) {
    const pulse=0.7+Math.sin(t*0.003)*0.3;
    ctx.save(); ctx.translate(x, y);
    ctx.shadowColor=col; ctx.shadowBlur=8*pulse; ctx.strokeStyle=col; ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.arc(0,-20,10+pulse*3,0,Math.PI*2); ctx.stroke();
    ctx.shadowBlur=0; ctx.restore();
  },

  _drawPortal(ctx, x, y, nz, t) {
    const z=ZONE_DATA[nz]; const acc=z?.accent||'#e8c96a';
    const pulse=0.7+Math.sin(t*0.003)*0.3;
    ctx.save(); ctx.translate(x,y);
    ctx.shadowColor=acc; ctx.shadowBlur=20*pulse;
    ctx.strokeStyle=acc; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(0,0,28+pulse*5,0,Math.PI*2); ctx.stroke();
    const g=ctx.createRadialGradient(0,0,4,0,0,28);
    g.addColorStop(0,`${acc}44`); g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,28,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle=acc; ctx.font='bold 13px monospace'; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillText('➤',0,0);
    ctx.fillStyle=`${acc}cc`; ctx.font='9px monospace'; ctx.textBaseline='alphabetic';
    ctx.fillText(z?.name||'',0,-42); ctx.fillText('[F] Entrer',0,-28);
    ctx.restore();
  },

  _getPnjData(key) {
    const map={
      elias:typeof DLG_ELIAS!=='undefined'?DLG_ELIAS:null,
      valeriane:typeof DLG_VALERIANE!=='undefined'?DLG_VALERIANE:null,
      theo:typeof DLG_THEO!=='undefined'?DLG_THEO:null,
      aldric:typeof DLG_ALDRIC!=='undefined'?DLG_ALDRIC:null,
      mordred:typeof DLG_MORDRED!=='undefined'?DLG_MORDRED:null,
      vaeltharion:typeof DLG_VAELTHARION!=='undefined'?DLG_VAELTHARION:null,
      rust:typeof DLG_RUST!=='undefined'?DLG_RUST:null,
      luma:typeof DLG_LUMA!=='undefined'?DLG_LUMA:null,
      vieux_gardien:typeof DLG_VIEUX_GARDIEN!=='undefined'?DLG_VIEUX_GARDIEN:null,
    };
    return map[key]||null;
  },
};
