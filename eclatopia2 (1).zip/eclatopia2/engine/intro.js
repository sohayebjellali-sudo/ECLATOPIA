// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/intro.js
// Animation d'introduction cinématique
// ═══════════════════════════════════════════════════════════

const Intro = {
  phase: 0,
  timer: 0,
  frame: 0,
  canvas: null,
  ctx: null,
  onDone: null,

  start(canvas, onDone) {
    this.canvas = canvas;
    this.ctx    = canvas.getContext('2d');
    this.onDone = onDone;
    this.phase  = 0;
    this.timer  = 0;
    this.frame  = 0;
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    this._loop();
  },

  _loop() {
    if (!this.canvas) return;
    this.frame++; this.timer++;
    this._draw();
    if (this.phase < 4) requestAnimationFrame(()=>this._loop());
  },

  _draw() {
    const ctx = this.ctx;
    const W = this.canvas.width, H = this.canvas.height;
    const t = this.frame, ti = this.timer;

    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);

    if      (this.phase === 0) this._drawTitle(ctx, W, H, t, ti);
    else if (this.phase === 1) this._drawBris(ctx, W, H, t, ti);
    else if (this.phase === 2) this._drawChars(ctx, W, H, t, ti);
    else if (this.phase === 3) this._drawReady(ctx, W, H, t, ti);
  },

  // ── PHASE 0 : Titre ───────────────────────────────────────
  _drawTitle(ctx, W, H, t, ti) {
    const alpha = Math.min(1, ti/55);
    ctx.globalAlpha = alpha;

    // Titre principal
    ctx.shadowColor = 'rgba(232,201,106,0.5)'; ctx.shadowBlur = 30;
    ctx.fillStyle = '#e8c96a';
    ctx.font = `bold ${Math.min(W*0.12,72)}px monospace`;
    ctx.textAlign = 'center';
    ctx.fillText('ÉCLATOPIA', W/2, H*0.32);
    ctx.shadowBlur = 0;

    // Sous-titre
    ctx.fillStyle = '#6a5020';
    ctx.font = `${Math.min(W*0.03,16)}px monospace`;
    ctx.fillText('LE PRIX DU VIDE', W/2, H*0.32+44);

    // Tag
    if (ti > 40) {
      ctx.globalAlpha = Math.min(1,(ti-40)/30)*alpha;
      ctx.fillStyle = '#2c2840';
      ctx.font = `${Math.min(W*0.02,11)}px monospace`;
      ctx.fillText('Action-RPG Narratif — PC uniquement', W/2, H*0.32+72);
    }
    ctx.globalAlpha = 1;

    // Ligne décorative
    if (ti > 50) {
      const lw = Math.min(1,(ti-50)/40);
      ctx.strokeStyle = `rgba(232,201,106,${0.3*lw})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(W/2 - 200*lw, H*0.38); ctx.lineTo(W/2 + 200*lw, H*0.38); ctx.stroke();
    }

    if (ti > 140) { this.phase = 1; this.timer = 0; }
  },

  // ── PHASE 1 : Bris de la Pierre ───────────────────────────
  _drawBris(ctx, W, H, t, ti) {
    ctx.fillStyle = '#b8c0d4';
    ctx.font = `${Math.min(W*0.025,13)}px monospace`;
    ctx.textAlign = 'center';

    const msgs = [
      'Il y a dix mille ans…',
      'La Pierre de Lueur maintenait l\'équilibre du monde…',
      'Jusqu\'à ce que Mordred la brise en 1001 éclats…',
      '…et libère ce qui dormait à l\'intérieur.',
    ];
    const msgIdx = Math.min(msgs.length-1, Math.floor(ti/65));
    ctx.fillText(msgs[msgIdx], W/2, H*0.15);

    // Dessin de la Pierre
    ctx.save();
    ctx.translate(W/2, H*0.46);
    const shakeX = ti > 150 ? Math.sin(t*0.8)*(ti-150)*0.1 : 0;
    ctx.translate(shakeX, 0);

    // Aura
    const sg = ctx.createRadialGradient(0,0,8,0,0,70);
    sg.addColorStop(0,'rgba(232,201,106,0.8)'); sg.addColorStop(0.5,'rgba(180,140,50,0.4)'); sg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=sg; ctx.beginPath(); ctx.arc(0,0,70,0,Math.PI*2); ctx.fill();

    // Pierre
    ctx.fillStyle='#b08040';
    ctx.beginPath(); ctx.moveTo(0,-40); ctx.lineTo(34,20); ctx.lineTo(-34,20); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#e8c96a';
    ctx.beginPath(); ctx.moveTo(0,-34); ctx.lineTo(28,16); ctx.lineTo(-28,16); ctx.closePath(); ctx.fill();

    // Centre brillant
    ctx.shadowColor='#fff'; ctx.shadowBlur=15; ctx.fillStyle='rgba(255,255,255,0.6)';
    ctx.beginPath(); ctx.arc(0,-8,8,0,Math.PI*2); ctx.fill();
    ctx.shadowBlur=0;
    ctx.restore();

    // Fissures
    if (ti > 160) {
      const cp = Math.min(1,(ti-160)/60);
      ctx.save(); ctx.translate(W/2, H*0.46);
      ctx.strokeStyle=`rgba(255,200,80,${cp})`; ctx.lineWidth=2;
      ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(22*cp,16+12*cp); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(-20*cp,12+10*cp); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(0,-22*cp-10); ctx.stroke();
      ctx.restore();
    }

    // Explosion
    if (ti > 220) {
      const ep = Math.min(1,(ti-220)/50);
      for (let i=0;i<16;i++) {
        const a=(i/16)*Math.PI*2, r=ep*180;
        ctx.fillStyle=`rgba(232,201,106,${Math.max(0,1-ep)})`;
        ctx.beginPath(); ctx.arc(W/2+Math.cos(a)*r, H*0.46+Math.sin(a)*r*0.5, 6-ep*4, 0, Math.PI*2); ctx.fill();
      }
      ctx.fillStyle='#b8c0d4'; ctx.font=`${Math.min(W*0.025,13)}px monospace`; ctx.textAlign='center';
      ctx.fillText('1001 éclats dispersés dans le monde…', W/2, H*0.82);
    }

    if (ti > 290) { this.phase=2; this.timer=0; }
  },

  // ── PHASE 2 : Personnages ──────────────────────────────────
  _drawChars(ctx, W, H, t, ti) {
    ctx.fillStyle='#b8c0d4';
    ctx.font=`${Math.min(W*0.025,13)}px monospace`; ctx.textAlign='center';
    ctx.fillText('Trois âmes vont décider du destin du monde', W/2, H*0.12);

    const chars=[
      { draw:'drawAelara', name:'AELARA', sub:'La Lumière', color:'#e8c96a', x:W*0.22 },
      { draw:'drawKael',   name:'KAEL',   sub:"L'Ombre",   color:'#4aacdf', x:W*0.5  },
      { draw:'drawTheo',   name:'THÉO',   sub:'La Mémoire',color:'#3acfaa', x:W*0.78 },
    ];

    chars.forEach((c,i)=>{
      const delay=i*35, alpha=Math.min(1,Math.max(0,(ti-delay)/45));
      if (alpha<=0) return;
      ctx.globalAlpha=alpha;
      if (Sprites[c.draw]) Sprites[c.draw](ctx, c.x, H*0.52, this.frame, 1, 'idle');
      ctx.fillStyle=c.color; ctx.font=`bold ${Math.min(W*0.025,13)}px monospace`;
      ctx.textAlign='center'; ctx.fillText(c.name, c.x, H*0.68);
      ctx.fillStyle=`${c.color}88`; ctx.font=`${Math.min(W*0.02,10)}px monospace`;
      ctx.fillText(c.sub, c.x, H*0.68+17);
      ctx.globalAlpha=1;
    });

    // Bouton continuer
    if (ti > 110) {
      const ba=Math.min(1,(ti-110)/30);
      ctx.globalAlpha=ba;
      ctx.strokeStyle='#e8c96a'; ctx.lineWidth=1;
      const bw=Math.min(220,W*0.38), bx=W/2-bw/2, by=H*0.83;
      ctx.strokeRect(bx,by,bw,36);
      ctx.fillStyle='rgba(232,201,106,0.06)'; ctx.fillRect(bx,by,bw,36);
      ctx.fillStyle='#e8c96a'; ctx.font=`${Math.min(W*0.025,12)}px monospace`; ctx.textAlign='center';
      ctx.fillText('Appuyer pour continuer', W/2, by+22);
      ctx.globalAlpha=1;

      this.canvas.style.cursor='pointer';
      this.canvas.onclick=()=>{
        this.canvas.onclick=null; this.canvas.style.cursor='default';
        this.phase=3; this.timer=0;
      };
    }
  },

  // ── PHASE 3 : Transition sortie ───────────────────────────
  _drawReady(ctx, W, H, t, ti) {
    const fadeOut=Math.min(1,ti/30);
    ctx.fillStyle=`rgba(0,0,0,${fadeOut})`; ctx.fillRect(0,0,W,H);
    if (fadeOut>=1 && this.onDone) {
      this.phase=4;
      const cb=this.onDone; this.onDone=null;
      cb();
    }
  },
};
