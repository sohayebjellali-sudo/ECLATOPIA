// ÉCLATOPIA 2 — engine/ai.js
// AI et BossAI sont définis dans engine/combat.js
// Ce fichier est un placeholder pour la compatibilité index.html
