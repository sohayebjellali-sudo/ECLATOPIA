// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — engine/ui.js
// Interface utilisateur, HUD, écrans
// ═══════════════════════════════════════════════════════════

const UI = {

  // ── MESSAGES ──────────────────────────────────────────────
  addMsg(text, color='#e8c96a', duration=3500) {
    const log = document.getElementById('msg-log');
    const el = document.createElement('div');
    el.className = 'msg-line';
    el.style.borderLeftColor = color;
    el.style.color = color;
    el.textContent = text;
    log.appendChild(el);
    if (log.children.length > 5) log.children[0].remove();
    setTimeout(() => el.remove(), duration);
  },

  // ── HUD ───────────────────────────────────────────────────
  updateHUD(player, gs) {
    if (!player) return;
    const hp=player.curHp/player.hp, mp=player.curMp/player.mp;
    const xp=player.xp/player.xpToNext;
    document.getElementById('bar-hp').style.width=`${Math.max(0,hp*100)}%`;
    document.getElementById('val-hp').textContent=`${Math.max(0,Math.round(player.curHp))}/${player.hp}`;
    document.getElementById('bar-mp').style.width=`${Math.max(0,mp*100)}%`;
    document.getElementById('val-mp').textContent=`${Math.max(0,Math.round(player.curMp))}/${player.mp}`;
    document.getElementById('bar-xp').style.width=`${Math.min(100,xp*100)}%`;
    document.getElementById('bar-vide').style.width=`${Math.min(100,gs.vide)}%`;
    document.getElementById('val-vide').textContent=`${Math.round(gs.vide)}%`;
    document.getElementById('hud-level').textContent=`Nv.${player.level}`;
    document.getElementById('hud-gold').textContent=`💰 ${player.gold}`;
    document.getElementById('hud-zone').textContent=ZONE_DATA[gs.currentZone]?.name||'';

    // Morale
    const mf=document.getElementById('bar-morale');
    const mv=document.getElementById('val-morale');
    const isPos = gs.morale >= 0;
    mf.style.left=isPos?'50%':'auto';
    mf.style.right=isPos?'auto':'50%';
    mf.style.width=`${Math.abs(gs.morale)/2}%`;
    mf.style.background=isPos?'linear-gradient(90deg,#40c080,#80e0a0)':'linear-gradient(90deg,#e04060,#ff8080)';
    mv.textContent=`${gs.morale>0?'+':''}${gs.morale}`;

    // HP bar couleur
    const hpBar=document.getElementById('bar-hp');
    if (hp>0.5) hpBar.style.background='linear-gradient(90deg,#c02040,#ff4060)';
    else if (hp>0.25) hpBar.style.background='linear-gradient(90deg,#c06000,#ff9000)';
    else hpBar.style.background='linear-gradient(90deg,#ff0020,#ff4040)';

    // Power CD
    const pcd=document.getElementById('hud-power-cd');
    if (player.powerTimer>0) { pcd.classList.remove('hidden'); pcd.textContent=`⏳ ${CHARACTERS[player.id]?.powerName||'Pouvoir'}`; }
    else pcd.classList.add('hidden');

    // Boss bar
    const bb=document.getElementById('boss-bar');
    if (gs.boss && !gs.boss.defeated) {
      bb.classList.remove('hidden');
      document.getElementById('boss-bar-name').textContent=gs.boss.name;
      document.getElementById('boss-bar-sub').textContent=gs.boss.sub||'';
      document.getElementById('bar-boss').style.width=`${Math.max(0,gs.boss.curHp/gs.boss.hp*100)}%`;
      const bc=gs.boss.col||'#e04060';
      document.getElementById('bar-boss').style.background=`linear-gradient(90deg,${bc}88,${bc})`;
    } else bb.classList.add('hidden');

    // Danger vide sur le canvas
    const canvas=document.getElementById('game-canvas');
    if (gs.vide>75) canvas.style.boxShadow=`inset 0 0 ${gs.vide}px rgba(200,30,60,${(gs.vide-75)/100})`;
    else canvas.style.boxShadow='none';
  },

  // ── QUICKBAR ──────────────────────────────────────────────
  updateQuickbar(player, gs) {
    const qb = document.getElementById('quickbar');
    qb.innerHTML = '';
    const consumables = [...new Set(player.inventory)].filter(id => ITEMS[id]?.type==='consumable').slice(0,4);
    consumables.forEach((id, i) => {
      const item=ITEMS[id]; if(!item) return;
      const slot=document.createElement('div');
      slot.className='qb-slot';
      slot.innerHTML=`${item.sym}<div class="qb-key">${i+1}</div>`;
      slot.title=item.name+'\n'+item.desc;
      slot.onclick=()=>this.useItem(id, player, gs);
      qb.appendChild(slot);
    });
  },

  useItem(id, player, gs) {
    const item=ITEMS[id]; if(!item) return;
    if (item.type!=='consumable') return;
    if (item.hp)    player.curHp=Math.min(player.hp, player.curHp+item.hp);
    if (item.mp)    player.curMp=Math.min(player.mp, player.curMp+item.mp);
    if (item.vide)  gs.vide=Math.max(0, gs.vide+item.vide);
    if (item.xp) {
      player.xp+=item.xp;
      Combat._checkLevelUp(player, gs);
    }
    if (item.moraleBonus) gs.morale=Math.max(-100,Math.min(100,gs.morale+item.moraleBonus));
    const idx=player.inventory.indexOf(id); if(idx>-1) player.inventory.splice(idx,1);
    Particles.spawn(player.x, player.y, '#e8c96a', 8, 4);
    this.addMsg(`✓ ${item.name} utilisé.`, '#e8c96a');
    this.updateQuickbar(player, gs);
  },

  // ── INVENTAIRE ────────────────────────────────────────────
  openInventory(player, gs) {
    const panel=document.getElementById('overlay-inv');
    panel.classList.remove('hidden');
    const grid=document.getElementById('inv-grid');
    grid.innerHTML='';
    const seen=new Set();
    player.inventory.forEach(id=>{
      if(seen.has(id)) return; seen.add(id);
      const item=ITEMS[id]; if(!item) return;
      const el=document.createElement('div');
      el.className='inv-item';
      el.innerHTML=`<div class="item-icon">${item.sym}</div><div class="item-name">${item.name}</div>${item.type==='consumable'?'<div class="item-use">Utiliser [clic]</div>':''}`;
      el.title=item.desc+(item.lore?'\n'+item.lore:'');
      if(item.type==='consumable') el.onclick=()=>{ this.useItem(id,player,gs); this.openInventory(player,gs); };
      grid.appendChild(el);
    });
    document.getElementById('eq-weapon').textContent=player.equippedWeapon ? ITEMS[player.equippedWeapon]?.name||player.equippedWeapon : '—';
    document.getElementById('eq-armor').textContent=player.equippedArmor ? ITEMS[player.equippedArmor]?.name||player.equippedArmor : '—';
  },

  closeInventory() {
    document.getElementById('overlay-inv').classList.add('hidden');
  },

  // ── CARTE ─────────────────────────────────────────────────
  openMap(gs) {
    document.getElementById('overlay-map').classList.remove('hidden');
    const mc=document.getElementById('map-canvas');
    const mctx=mc.getContext('2d');
    mctx.clearRect(0,0,700,400);
    mctx.fillStyle='#06050b'; mctx.fillRect(0,0,700,400);
    // Connexions
    mctx.strokeStyle='rgba(255,255,255,0.15)'; mctx.lineWidth=2;
    WORLD_MAP.connections.forEach(c=>{
      const a=ZONE_DATA[c.from]?.mapPos, b=ZONE_DATA[c.to]?.mapPos;
      if(!a||!b) return;
      mctx.beginPath(); mctx.moveTo(a.x,a.y); mctx.lineTo(b.x,b.y); mctx.stroke();
    });
    // Zones
    Object.values(ZONE_DATA).forEach(z=>{
      if(!z.mapPos) return;
      const unlocked=gs.unlockedZones?.includes(z.id)||z.id===gs.currentZone;
      const isCurrent=z.id===gs.currentZone;
      mctx.beginPath(); mctx.arc(z.mapPos.x,z.mapPos.y,isCurrent?18:14,0,Math.PI*2);
      mctx.fillStyle=unlocked?z.mapColor:'#2c2840'; mctx.fill();
      if(isCurrent){mctx.shadowColor=z.mapColor;mctx.shadowBlur=20;mctx.strokeStyle=z.mapColor;mctx.lineWidth=2;mctx.stroke();mctx.shadowBlur=0;}
      mctx.fillStyle=unlocked?'#fff':'#4a4465'; mctx.font=`${isCurrent?'bold ':''}10px monospace`; mctx.textAlign='center';
      mctx.fillText(z.name, z.mapPos.x, z.mapPos.y+28);
      if(isCurrent){mctx.fillStyle=z.mapColor;mctx.font='9px monospace';mctx.fillText('◀ Vous êtes ici',z.mapPos.x,z.mapPos.y-24);}
    });
    // Légende
    const leg=document.getElementById('map-legend');
    leg.innerHTML='';
    [['Actuel','#e8c96a'],['Déverrouillé','#888'],['Verrouillé','#2c2840']].forEach(([l,c])=>{
      leg.innerHTML+=`<div class="legend-item"><div class="legend-dot" style="background:${c}"></div><span>${l}</span></div>`;
    });
  },

  closeMap() { document.getElementById('overlay-map').classList.add('hidden'); },

  // ── QUEST TRACKER ─────────────────────────────────────────
  updateQuestTracker(questId, gs) {
    const q=QUESTS[questId]; if(!q) return;
    const qt=document.getElementById('quest-tracker');
    qt.classList.remove('hidden');
    document.getElementById('quest-tracker-name').textContent=q.name;
    // Trouver premier objectif non fait
    const obj=q.objectives?.find(o=>!o.done);
    document.getElementById('quest-tracker-obj').textContent=obj?obj.text:'Quête complétée';
  },

  // ── HINT INTERAGIR ────────────────────────────────────────
  showInteractHint(text, x, y, W, H) {
    const hint=document.getElementById('hint-interact');
    hint.classList.remove('hidden');
    hint.textContent=text;
    // Positionner au-dessus du personnage
    const screenX=W/2+(x-Camera.x), screenY=H*0.65+(y)*0.15-80;
    hint.style.left=`${Math.max(10,Math.min(W-150,screenX-50))}px`;
    hint.style.top=`${Math.max(10,screenY)}px`;
  },

  hideInteractHint() { document.getElementById('hint-interact').classList.add('hidden'); },

  // ── PHASE FLASH BOSS ──────────────────────────────────────
  showPhaseFlash(msg, col='#e04060') {
    const existing=document.getElementById('boss-phase-flash');
    if(existing) existing.remove();
    const el=document.createElement('div');
    el.id='boss-phase-flash'; el.textContent=msg; el.style.color=col;
    document.getElementById('screen-game').appendChild(el);
    setTimeout(()=>el.remove(), 2600);
    // Mettre à jour le msg dans la boss bar
    document.getElementById('boss-phase-msg').textContent=msg;
  },

  // ── ÉCRAN GAME OVER ───────────────────────────────────────
  showGameOver(canvas) {
    const ctx=canvas.getContext('2d');
    const W=canvas.width, H=canvas.height;
    ctx.fillStyle='rgba(0,0,0,0.88)'; ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#e04060'; ctx.font=`bold ${Math.min(W*0.08,38)}px monospace`;
    ctx.textAlign='center'; ctx.shadowColor='#e04060'; ctx.shadowBlur=24;
    ctx.fillText('DÉFAITE', W/2, H*0.38);
    ctx.shadowBlur=0;
    ctx.fillStyle='#6a6080'; ctx.font=`${Math.min(W*0.028,13)}px monospace`;
    ctx.fillText('Le monde continue sans toi — pour l\'instant.', W/2, H*0.5);
    ctx.strokeStyle='rgba(232,201,106,0.5)'; ctx.lineWidth=1;
    ctx.strokeRect(W/2-110,H*0.62,220,38);
    ctx.fillStyle='#e8c96a'; ctx.font=`${Math.min(W*0.026,12)}px monospace`;
    ctx.fillText('Appuyer pour recommencer', W/2, H*0.62+23);
    canvas.onclick=()=>location.reload();
  },

  // ── ÉCRAN FIN ─────────────────────────────────────────────
  showEnding(endId, canvas, morale, vide) {
    const ed=ENDINGS[endId]||ENDINGS.equilibre;
    const ctx=canvas.getContext('2d');
    const W=canvas.width, H=canvas.height;

    ctx.fillStyle='#000'; ctx.fillRect(0,0,W,H);

    // Titre
    ctx.fillStyle=ed.color;
    ctx.font=`bold ${Math.min(W*0.038,22)}px monospace`;
    ctx.textAlign='center'; ctx.shadowColor=ed.color; ctx.shadowBlur=24;
    ctx.fillText(ed.title, W/2, H*0.12);
    ctx.shadowBlur=0;
    if(ed.subtitle){
      ctx.fillStyle=`${ed.color}80`; ctx.font=`${Math.min(W*0.025,11)}px monospace`;
      ctx.fillText(ed.subtitle, W/2, H*0.12+22);
    }

    // Séparateur
    ctx.strokeStyle=`${ed.color}40`; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(W/2-120,H*0.17); ctx.lineTo(W/2+120,H*0.17); ctx.stroke();

    // Texte
    const lines=ed.text.split('\n');
    ctx.font=`${Math.min(W*0.025,12)}px monospace`;
    lines.forEach((line,i)=>{
      ctx.fillStyle=line===''?'transparent':'#b8c0d4';
      if(line) ctx.fillText(line, W/2, H*0.22+i*20);
    });

    // Épilogue
    if(ed.epilogue){
      const epLines=ed.epilogue.split('\n');
      const epY=H*0.22+lines.length*20+20;
      ctx.fillStyle=`${ed.color}60`; ctx.font=`italic ${Math.min(W*0.022,10)}px monospace`;
      epLines.forEach((l,i)=>{ if(l) ctx.fillText(l, W/2, epY+i*17); });
    }

    // Stats
    ctx.fillStyle=`${ed.color}70`; ctx.font=`${Math.min(W*0.022,10)}px monospace`;
    ctx.fillText(`Morale : ${morale>0?'+':''}${morale}  |  Vide : ${Math.round(vide)}%`, W/2, H*0.84);
    if(ed.skin) { ctx.fillStyle=`${ed.color}55`; ctx.fillText(`Skin débloqué : ${ed.skin}`, W/2, H*0.87); }

    // Bouton rejouer
    ctx.strokeStyle=`${ed.color}55`; ctx.lineWidth=1;
    ctx.strokeRect(W/2-110,H*0.90,220,38);
    ctx.fillStyle=`${ed.color}99`; ctx.font=`${Math.min(W*0.025,12)}px monospace`;
    ctx.fillText('Appuyer pour rejouer', W/2, H*0.90+23);
    canvas.onclick=()=>location.reload();
  },

  // ── CHAR SELECT ───────────────────────────────────────────
  buildCharSelect(container, onSelect) {
    container.innerHTML='';
    const title=document.createElement('div'); title.className='charsel-title'; title.textContent='Choisissez votre âme'; container.appendChild(title);
    const sub=document.createElement('div'); sub.className='charsel-sub'; sub.textContent='Chaque destin mène à la même vérité — par des routes différentes'; container.appendChild(sub);
    const grid=document.createElement('div'); grid.id='charsel-grid'; container.appendChild(grid);

    let selected='aelara';
    Object.values(CHARACTERS).forEach(c=>{
      const card=document.createElement('div'); card.className='char-card';
      card.style.setProperty('--c',c.color); card.style.borderColor=`${c.color}30`;

      const mc=document.createElement('canvas'); mc.width=80; mc.height=90;
      const mctx=mc.getContext('2d');
      card.appendChild(mc);

      const nameEl=document.createElement('div'); nameEl.className='char-card-name'; nameEl.style.color=c.color; nameEl.textContent=c.name; card.appendChild(nameEl);
      const factionEl=document.createElement('div'); factionEl.className='char-card-faction'; factionEl.style.color=`${c.color}80`; factionEl.textContent=c.faction; card.appendChild(factionEl);
      const descEl=document.createElement('div'); descEl.className='char-card-desc'; descEl.textContent=c.desc; card.appendChild(descEl);

      const statsEl=document.createElement('div'); statsEl.className='char-card-stats';
      [['PV',c.hp,'#e04060'],['ATK',c.atk,'#e08040'],['SPD',c.spd,'#3acfaa'],['DEF',c.def,'#4aacdf']].forEach(([l,v,col])=>{
        const pill=document.createElement('div'); pill.className='stat-pill';
        pill.style.cssText=`color:${col};border-color:${col}50;font-size:8px;`;
        pill.textContent=`${l}:${v}`; statsEl.appendChild(pill);
      });
      card.appendChild(statsEl);

      const powerEl=document.createElement('div'); powerEl.className='char-card-power'; powerEl.textContent=`✦ ${c.powerName} — ${c.powerDesc}`; card.appendChild(powerEl);
      const quoteEl=document.createElement('div'); quoteEl.className='char-card-quote'; quoteEl.textContent=`"${c.quote}"`; card.appendChild(quoteEl);

      card.onclick=()=>{
        document.querySelectorAll('.char-card').forEach(cc=>{cc.style.borderColor=`${cc.dataset.c}30`; cc.style.boxShadow='none';});
        card.style.borderColor=c.color; card.style.boxShadow=`0 0 24px ${c.glow}`;
        selected=c.id;
      };
      card.dataset.c=c.color;

      // Animation miniature
      const animMini=()=>{
        mctx.clearRect(0,0,80,90);
        if(Sprites[c.drawFn]) Sprites[c.drawFn](mctx, 40, 60, Date.now()*0.05, 1, 'idle');
        if(grid.isConnected) requestAnimationFrame(animMini);
      };
      animMini();

      card.onmouseenter=()=>{card.style.transform='translateY(-4px)'; if(selected!==c.id) card.style.borderColor=`${c.color}60`;};
      card.onmouseleave=()=>{card.style.transform='none'; if(selected!==c.id) card.style.borderColor=`${c.color}30`;};
      grid.appendChild(card);
    });

    const startBtn=document.createElement('button'); startBtn.className='btn-start'; startBtn.textContent='Commencer le Voyage';
    startBtn.onclick=()=>onSelect(selected);
    startBtn.onmouseenter=()=>startBtn.style.background='rgba(232,201,106,0.1)';
    startBtn.onmouseleave=()=>startBtn.style.background='transparent';
    container.appendChild(startBtn);
  },
};
