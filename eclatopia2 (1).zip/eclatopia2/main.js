// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — main.js
// Moteur principal : boucle de jeu, input, état, transitions
// PC uniquement — pas de mobile
// ═══════════════════════════════════════════════════════════

// ── CANVAS ────────────────────────────────────────────────
const canvas = document.getElementById('game-canvas');
const ctx    = canvas.getContext('2d');

function resizeCanvas() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// ── ÉTAT GLOBAL ───────────────────────────────────────────
const GS = {
  screen: 'intro',       // intro | charsel | playing | gameover | ending
  player: null,
  currentZone: 'foret',
  unlockedZones: ['foret'],
  enemies: [],
  bossProjs: [],
  playerProjs: [],
  boss: null,
  frame: 0,
  morale: 0,
  vide: 0,
  inputLock: false,
  dialogueOpen: false,
  endingId: null,
  portalVisible: false,
  steles: [],
  steleFound: [],
  hiddenItems: [],
  enemyRespawnTimer: 0,
  lastTime: 0,
};

// ── INPUT ─────────────────────────────────────────────────
const Keys = {};
window.addEventListener('keydown', e => {
  Keys[e.key] = true;
  if ([' ','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) e.preventDefault();
  handleKeyAction(e.key);
});
window.addEventListener('keyup', e => { Keys[e.key] = false; });

function handleKeyAction(key) {
  if (GS.screen !== 'playing') return;
  const p = GS.player; if (!p) return;

  // Inventaire
  if (key === 'i' || key === 'I') {
    const inv = document.getElementById('overlay-inv');
    if (inv.classList.contains('hidden')) UI.openInventory(p, GS);
    else UI.closeInventory();
    return;
  }
  // Carte
  if (key === 'Tab') {
    const mp = document.getElementById('overlay-map');
    if (mp.classList.contains('hidden')) UI.openMap(GS);
    else UI.closeMap();
    return;
  }
  // Interagir
  if (key === 'f' || key === 'F' || key === 'Enter') {
    if (!GS.inputLock) tryInteract();
    return;
  }
  // Briser le Lien (Fin Sacrifice)
  if ((key === 'b' || key === 'B') && GS.vide >= 85) {
    GS.endingId = 'sacrifice';
    GS.screen   = 'ending';
    hideGameUI();
    UI.showEnding('sacrifice', canvas, GS.morale, GS.vide);
    return;
  }
  // Utiliser items rapides 1-4
  if (['1','2','3','4'].includes(key) && !GS.inputLock) {
    const consumables = [...new Set(p.inventory)].filter(id => ITEMS[id]?.type==='consumable');
    const idx = parseInt(key)-1;
    if (consumables[idx]) UI.useItem(consumables[idx], p, GS);
  }
}

// Fermer overlays
document.getElementById('btn-inv-close')?.addEventListener('click', () => UI.closeInventory());
document.getElementById('btn-map-close')?.addEventListener('click', () => UI.closeMap());

// ── CRÉATION JOUEUR ───────────────────────────────────────
function createPlayer(charId) {
  const def = CHARACTERS[charId] || CHARACTERS.aelara;
  return {
    id: charId,
    ...def,
    curHp: def.hp, curMp: def.mp,
    xp: 0, level: 1, xpToNext: 100,
    gold: 50,
    x: 0, y: 0,
    facing: 1,
    state: 'idle',
    atkTimer: 0, atkCd: 380,
    powerTimer: 0,
    shieldActive: false, shieldTimer: 0, shieldHits: 0,
    running: false,
    invincible: false, invincibleTimer: 0,
    cursed: false,
    inventory: [],
    flags: {},
    quests: [],
    equippedWeapon: null,
    equippedArmor: null,
  };
}

// ── SPAWN ENNEMIS ─────────────────────────────────────────
function spawnEnemy() {
  const zone = ZONE_DATA[GS.currentZone];
  const types = zone?.enemies || ['ombre'];
  const type  = types[Math.floor(Math.random()*types.length)];
  const def   = ENEMY_TYPES[type]; if (!def) return;
  const p     = GS.player;
  const living = GS.enemies.filter(e=>e.curHp>0).length;
  if (living >= 6) return;

  const side = Math.random()>0.5?1:-1;
  const dist = 280+Math.random()*200;
  GS.enemies.push({
    ...def, type,
    curHp: def.hp,
    x: (p?.x||0)+side*dist, y: 0,
    facing: -side,
    state: 'chase',
    frame: 0,
    hurtTimer: 0, atkTimer: 0,
  });
}

// ── STÈLES ────────────────────────────────────────────────
function setupSteles() {
  GS.steles = (ZONE_DATA.foret.steles || []).map((s,i) => ({...s, idx:i}));
  GS.steleFound = [];
}

// ── OBJETS CACHÉS ─────────────────────────────────────────
function setupHiddenItems() {
  const zone = ZONE_DATA[GS.currentZone];
  GS.hiddenItems = (zone?.hiddenItems||[]).map(h=>({...h, collected:false}));
}

// ── CHANGER DE ZONE ───────────────────────────────────────
function changeZone(zoneId) {
  if (!GS.unlockedZones.includes(zoneId)) {
    UI.addMsg('Zone non déverrouillée — vaincs le boss d\'abord.', '#e04060');
    return;
  }
  GS.currentZone = zoneId;
  GS.enemies     = [];
  GS.bossProjs   = [];
  GS.playerProjs = [];
  GS.boss        = null;
  GS.portalVisible = false;
  Particles.clear();
  DmgNums.clear();
  Camera.reset();
  Camera.x = -600; Camera.y = 0;
  if (GS.player) { GS.player.x = -600; GS.player.y = 0; }
  setupHiddenItems();
  for (let i=0;i<3;i++) spawnEnemy();
  document.getElementById('hud-zone').textContent = ZONE_DATA[zoneId]?.name || '';
  UI.addMsg(`📍 ${ZONE_DATA[zoneId]?.name}`, ZONE_DATA[zoneId]?.accent||'#fff');
}

// ── DÉCLENCHER BOSS ───────────────────────────────────────
function triggerBoss() {
  const bossKey = ZONE_DATA[GS.currentZone]?.boss;
  if (!bossKey || GS.bossDefeated?.[GS.currentZone]) return;
  GS.enemies = [];

  const def = BOSS_TYPES[bossKey]; if (!def) return;
  GS.boss = {
    ...def, key: bossKey,
    curHp: def.hp,
    x: (GS.player?.x||0)+420, y: 0,
    facing: -1, frame: 0,
    phase: 0, patTimer: 0, orbitAngle: 0,
    hurtTimer: 0, vx: 0, vy: 0,
    defeated: false, resolvedDialogue: false,
  };
  UI.addMsg(`⚠ ${def.name} — ${def.sub} !`, def.col||'#e04060');
  Camera.shake(300);

  // Pré-dialogue
  Dialogue.showBossPreDialogue(bossKey, GS, () => {
    // Le combat commence après le dialogue
  });
}

// ── INTERAGIR ─────────────────────────────────────────────
function tryInteract() {
  if (GS.inputLock || GS.dialogueOpen) return;
  const p = GS.player; if (!p) return;

  // PNJ
  const zonePnjs = ZONE_DATA[GS.currentZone]?.pnjs || [];
  for (const pnjDef of zonePnjs) {
    const data = getDlgData(pnjDef.key);
    if (!data) continue;
    if (Math.abs(p.x - pnjDef.x) < 80) {
      Dialogue.open(pnjDef.key, GS, () => {
        UI.updateQuickbar(p, GS);
      });
      return;
    }
  }

  // Stèles (zone forêt)
  if (GS.currentZone === 'foret') {
    for (const st of GS.steles) {
      if (GS.steleFound.includes(st.idx)) continue;
      if (Math.abs(p.x - st.x) < 60) {
        GS.steleFound.push(st.idx);
        const text = QUESTS.quete_steles?.stele_texts?.[st.idx] || 'La stèle porte des inscriptions anciennes.';
        showSteleReading(st.idx+1, text);
        if (GS.steleFound.length === 3) {
          setTimeout(()=>{
            UI.addMsg('✓ Toutes les stèles lues — Vaeltharion reconnaîtra ta sagesse.', '#e8c96a');
            p.flags.steles_all = true;
          }, 500);
        }
        return;
      }
    }
  }

  // Objets cachés
  for (const hi of GS.hiddenItems) {
    if (hi.collected) continue;
    if (hi.guardedByBoss && !GS.bossDefeated?.[GS.currentZone]) continue;
    if (Math.abs(p.x - hi.x) < 60) {
      hi.collected = true;
      if (!p.inventory.includes(hi.item)) p.inventory.push(hi.item);
      UI.addMsg(`✓ ${ITEMS[hi.item]?.name || hi.item} obtenu !`, '#e8c96a');
      Particles.spawnBurst(hi.x, 0, '#e8c96a');
      UI.updateQuickbar(p, GS);
      return;
    }
  }

  // Portail
  if (GS.portalVisible) {
    if (Math.abs(p.x - 900) < 80) {
      const nz = getNextZone(GS.currentZone);
      if (nz) changeZone(nz);
      return;
    }
  }

  // Déclencher boss (côté droit de la zone)
  if (!GS.boss && p.x > 580) {
    const bossKey = ZONE_DATA[GS.currentZone]?.boss;
    if (bossKey && !GS.bossDefeated?.[GS.currentZone]) {
      triggerBoss();
    }
  }
}

function getDlgData(key) {
  const map = {
    elias: typeof DLG_ELIAS!=='undefined'?DLG_ELIAS:null,
    valeriane: typeof DLG_VALERIANE!=='undefined'?DLG_VALERIANE:null,
    theo: typeof DLG_THEO!=='undefined'?DLG_THEO:null,
    aldric: typeof DLG_ALDRIC!=='undefined'?DLG_ALDRIC:null,
    mordred: typeof DLG_MORDRED!=='undefined'?DLG_MORDRED:null,
    vaeltharion: typeof DLG_VAELTHARION!=='undefined'?DLG_VAELTHARION:null,
    rust: typeof DLG_RUST!=='undefined'?DLG_RUST:null,
    luma: typeof DLG_LUMA!=='undefined'?DLG_LUMA:null,
    vieux_gardien: typeof DLG_VIEUX_GARDIEN!=='undefined'?DLG_VIEUX_GARDIEN:null,
  };
  return map[key]||null;
}

// ── LECTURE STÈLE ─────────────────────────────────────────
function showSteleReading(num, text) {
  GS.inputLock = true; GS.dialogueOpen = true;
  const box = document.getElementById('dlg-box');
  box.classList.remove('hidden');
  const pc = document.getElementById('dlg-canvas');
  const pctx = pc.getContext('2d');
  pctx.clearRect(0,0,110,140);
  pctx.fillStyle='#3a3228'; pctx.fillRect(10,10,90,120);
  pctx.fillStyle='#c8a060'; pctx.font='bold 11px monospace'; pctx.textAlign='center';
  pctx.fillText('STÈLE',55,35); pctx.fillText(`${num}/3`,55,52);
  pctx.strokeStyle='#c8a060'; pctx.lineWidth=0.7;
  for(let i=0;i<5;i++){ pctx.beginPath(); pctx.moveTo(15,65+i*12); pctx.lineTo(95,65+i*12); pctx.stroke(); }
  document.getElementById('dlg-name').textContent  = `Stèle ${num}`;
  document.getElementById('dlg-name').style.color  = '#c8a060';
  document.getElementById('dlg-title').textContent = 'Inscription ancienne';
  document.getElementById('dlg-text').textContent  = text;
  document.getElementById('dlg-choices').innerHTML = '';
  const btn = document.createElement('button');
  btn.className='dlg-btn'; btn.textContent='Refermer la stèle';
  btn.onclick=()=>{
    box.classList.add('hidden');
    GS.inputLock=false; GS.dialogueOpen=false;
    UI.addMsg(`📜 Stèle ${num}/3 lue.`, '#c8a060');
    Particles.spawnBurst(GS.player?.x||0, 0, '#e8c96a');
  };
  document.getElementById('dlg-choices').appendChild(btn);
}

// ── MISE À JOUR ───────────────────────────────────────────
function update(dt) {
  if (GS.screen !== 'playing') return;
  GS.frame++;
  const p = GS.player; if (!p) return;

  // ── Mouvement ──────────────────────────────────────────
  if (!GS.inputLock) {
    let mx=0, my=0;
    if (Keys['ArrowLeft']||Keys['a']||Keys['A']) mx=-1;
    if (Keys['ArrowRight']||Keys['d']||Keys['D']) mx=1;
    if (Keys['ArrowUp']||Keys['w']||Keys['W'])   my=-1;
    if (Keys['ArrowDown']||Keys['s']||Keys['S']) my=1;
    if (mx&&my){mx*=0.707;my*=0.707;}

    p.running = !!(Keys['Shift']);
    const spd = Combat.getSpeed(p, p.running);
    p.x = Math.max(-980, Math.min(980, p.x + mx*spd*(dt/16.67)));
    p.y = Math.max(-65,  Math.min(65,  p.y + my*spd*(dt/16.67)));
    if (mx!==0) p.facing = mx>0?1:-1;
    p.state = (mx!==0||my!==0) ? (p.running?'run':'walk') : 'idle';

    // Attaque mêlée
    if (Keys[' ']||Keys['z']||Keys['Z']) Combat.playerMelee(GS);
    // Attaque distance
    if (Keys['x']||Keys['X']) Combat.playerRanged(GS, p.facing);
    // Pouvoir
    if (Keys['e']||Keys['E']) Combat.playerPower(GS);
    // Bouclier
    if (Keys['q']||Keys['Q']) Combat.playerShield(GS);
  }

  // ── Timers joueur ──────────────────────────────────────
  p.atkTimer        = Math.max(0, p.atkTimer-dt);
  p.powerTimer      = Math.max(0, p.powerTimer-dt);
  p.shieldTimer     = Math.max(0, p.shieldTimer-dt);
  p.invincibleTimer = Math.max(0, p.invincibleTimer-dt);
  if (p.shieldTimer    <=0) p.shieldActive=false;
  if (p.invincibleTimer<=0) p.invincible=false;
  if (p.atkTimer<=0 && p.state==='attack') p.state='idle';

  // MP regen
  p.curMp = Math.min(p.mp, p.curMp + 0.04*(dt/16.67));

  // ── Systèmes ───────────────────────────────────────────
  AI.update(GS, dt);
  Combat.updatePlayerProjs(GS, dt);
  Combat.updateBossProjs(GS, dt);
  if (GS.boss && !GS.boss.defeated) BossAI.update(GS.boss, p.x, p.y, dt, GS);
  Particles.update(dt);
  DmgNums.update(dt);
  Camera.follow(p.x, p.y);
  Camera.update(dt);

  // ── Respawn ennemis ────────────────────────────────────
  GS.enemyRespawnTimer += dt;
  if (GS.enemyRespawnTimer > 5500 && !GS.boss) {
    GS.enemyRespawnTimer = 0;
    spawnEnemy();
  }

  // ── Vide critique → fin ────────────────────────────────
  if (GS.vide >= 100 && GS.screen !== 'ending') {
    GS.endingId = 'ombre'; GS.screen = 'ending';
    hideGameUI();
    UI.showEnding('ombre', canvas, GS.morale, GS.vide);
    return;
  }

  // ── Portail (auto si proche) ────────────────────────────
  if (p.x > 920 && GS.portalVisible) {
    const nz = getNextZone(GS.currentZone);
    if (nz) changeZone(nz);
  }

  // ── Mines (zone secondaire Montagnes) ──────────────────
  if (GS.currentZone==='montagne' && p.x < -580 && p.inventory.includes('conseil_steles') && !GS.minesTriggered) {
    GS.minesTriggered = true;
    triggerMinesScene();
  }

  // ── Boss trigger auto (côté droit) ─────────────────────
  if (!GS.boss && p.x > 600 && ZONE_DATA[GS.currentZone]?.boss && !GS.bossDefeated?.[GS.currentZone]) {
    triggerBoss();
  }

  // ── Hint interagir ──────────────────────────────────────
  checkInteractHints();

  // ── HUD ────────────────────────────────────────────────
  UI.updateHUD(p, GS);
  UI.updateQuickbar(p, GS);
}

// ── VÉRIFIER HINTS PROXIMITÉ ──────────────────────────────
function checkInteractHints() {
  const p = GS.player; if (!p) return;
  const W = canvas.width, H = canvas.height;
  const zone = ZONE_DATA[GS.currentZone];
  let hint = null;

  for (const pnjDef of (zone?.pnjs||[])) {
    if (Math.abs(p.x - pnjDef.x) < 80) { hint = '[F] Parler'; break; }
  }
  if (!hint && GS.currentZone==='foret') {
    for (const st of GS.steles) {
      if (!GS.steleFound.includes(st.idx) && Math.abs(p.x-st.x)<60) { hint='[F] Lire la stèle'; break; }
    }
  }
  if (!hint) {
    for (const hi of GS.hiddenItems) {
      if (!hi.collected && Math.abs(p.x-hi.x)<60) { hint=`[F] ${hi.label||'Ramasser'}`; break; }
    }
  }
  if (!hint && GS.portalVisible && Math.abs(p.x-900)<80) { hint='[F] Changer de zone'; }

  if (hint) UI.showInteractHint(hint, p.x, p.y, W, H);
  else UI.hideInteractHint();
}

// ── SCÈNE DES MINES ───────────────────────────────────────
function triggerMinesScene() {
  const questDef = QUESTS.quete_murmures_sous_pierre;
  if (!questDef?.scene_key) return;
  const scene = questDef.scene_key;
  Camera.shake(500);
  setTimeout(() => {
    Dialogue.showCinemaScene(
      scene.dialogues.filter(l => !l.condition || GS.player.flags[l.condition]),
      scene.choices,
      GS,
      (choice) => {
        if (!choice) return;
        const fx = choice.effects;
        if (fx?.morale) GS.morale = Math.max(-100, Math.min(100, GS.morale + fx.morale));
        if (fx?.vide)   GS.vide   = Math.max(0, Math.min(100, GS.vide + fx.vide));
        if (fx?.flag)   GS.player.flags[fx.flag] = true;
        if (fx?.item && !GS.player.inventory.includes(fx.item)) {
          GS.player.inventory.push(fx.item);
          UI.addMsg(`✓ ${ITEMS[fx.item]?.name||fx.item} obtenu !`, '#e8c96a');
        }
        const desc = fx?.consequence || '';
        if (desc) setTimeout(()=>UI.addMsg(desc, '#b8c0d4', 5000), 400);
      }
    );
  }, 300);
}

// ── BOUCLE PRINCIPALE ─────────────────────────────────────
function gameLoop(timestamp) {
  const dt = Math.min(timestamp - (GS.lastTime||timestamp), 50);
  GS.lastTime = timestamp;
  update(dt);
  if (GS.screen === 'playing') Renderer.draw(ctx, GS, canvas.width, canvas.height);
  requestAnimationFrame(gameLoop);
}

// ── DÉMARRER ──────────────────────────────────────────────
function startGame(charId) {
  GS.player        = createPlayer(charId);
  GS.currentZone   = 'foret';
  GS.unlockedZones = ['foret'];
  GS.enemies       = [];
  GS.boss          = null;
  GS.bossProjs     = [];
  GS.playerProjs   = [];
  GS.bossDefeated  = {};
  GS.morale        = 0;
  GS.vide          = 0;
  GS.frame         = 0;
  GS.portalVisible = false;
  GS.minesTriggered= false;
  Particles.clear();
  DmgNums.clear();
  Camera.reset();

  setupSteles();
  setupHiddenItems();
  for (let i=0;i<3;i++) spawnEnemy();

  showGameUI();
  GS.screen = 'playing';

  document.getElementById('hud-zone').textContent = ZONE_DATA.foret.name;
  UI.addMsg(`Bienvenue, ${GS.player.name} !`, CHARACTERS[charId]?.color||'#e8c96a');
  setTimeout(()=>UI.addMsg('ZQSD : déplacement  ·  Espace : attaque  ·  E : pouvoir  ·  Q : bouclier  ·  F : interagir  ·  I : inventaire  ·  Tab : carte', '#4a4465', 6000), 800);
  setTimeout(()=>UI.addMsg('Cherche Elias (📜) à gauche — il a ta première quête.', '#c8a060', 5000), 2500);

  requestAnimationFrame(gameLoop);
}

// ── AFFICHER / MASQUER UI ─────────────────────────────────
function showGameUI() {
  document.getElementById('screen-game').classList.add('active');
  document.getElementById('screen-charsel').classList.remove('active');
}

function hideGameUI() {
  document.getElementById('hud').classList.add('hidden');
  document.getElementById('xp-strip').classList.add('hidden');
  document.getElementById('controls-hint').classList.add('hidden');
  document.getElementById('quest-tracker').classList.add('hidden');
  document.getElementById('quickbar').classList.add('hidden');
  document.getElementById('msg-log').innerHTML='';
}

// ── BOOT ──────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {

  // 1. Intro
  const introScreen = document.getElementById('screen-intro');
  introScreen.classList.add('active');

  Intro.start(canvas, () => {
    // 2. Char Select
    introScreen.classList.remove('active');
    canvas.style.display='none';
    const cs = document.getElementById('screen-charsel');
    cs.classList.add('active');
    UI.buildCharSelect(cs, (charId) => {
      cs.classList.remove('active');
      canvas.style.display='block';
      startGame(charId);
    });
  });
});
