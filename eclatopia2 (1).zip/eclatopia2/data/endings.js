// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/endings.js
// Les 5 fins possibles
// ═══════════════════════════════════════════════════════════

const ENDINGS = {

  vraie_fin: {
    id: 'vraie_fin',
    title: 'Vraie Fin — Le Prix du Vide',
    subtitle: 'La seule fin qui coûte quelque chose',
    color: '#7fffee',
    skin: 'Porteur du Vide',
    conditions: ['memoire_mordred', 'codex_liberation'],
    text: `Théo inverse la greffe dans l'Abysse.

Mordred retrouve sa conscience.
Il pleure.
Pour la première fois depuis le Bris, il pleure.

Vaeltharion libère les dix mille âmes.
L'une après l'autre.
Il dit chaque prénom à voix haute.
Ça prend longtemps.

L'Éveillé est refermé de l'intérieur —
par Mordred lui-même, avec sa culpabilité retrouvée comme sceau.

La Pierre ne revient pas.
Vaeltharion disparaît — en souriant pour la première fois depuis dix mille ans.

Aldric témoigne.
Les survivants l'écoutent.
Certains pleurent.
Certains restent silencieux.

Mordred reste.
On lui a demandé de partir.
Il a dit qu'il avait encore à faire.
Personne n'a insisté.

Théo se sent léger.
Et terriblement vide.`,
    epilogue: `Plusieurs années plus tard, la forêt des Murmures s'est tue.
Les arbres ne répètent plus rien.
Peut-être qu'ils ont plus rien à garder.`,
  },

  lumiere: {
    id: 'lumiere',
    title: 'Fin Lumière — Le Retour du Mensonge',
    subtitle: 'La lumière revient. Et elle prend.',
    color: '#e8c96a',
    skin: 'Gardien de la Lumière',
    text: `La Pierre est reconstruite.
La lumière revient sur Éclatopia.

Les gens sortent dans les rues.
Ils lèvent les yeux.
Ils disent merci.

Et imperceptiblement, les habitants commencent à vieillir trop vite.

Les Cachés sont bannis dans les ombres.
Vaeltharion se rendort à l'intérieur de la Pierre.
L'Éveillé aussi — pour l'instant.

Elias ferme ses livres.
Il n'archive plus.
Il dit que ça ne sert plus à rien.

Le cycle recommence.
Dans dix mille ans, quelqu'un d'autre découvrira la vérité.
Et devra choisir.`,
    epilogue: `La lumière est belle.
Elle a toujours été belle.
C'est pour ça que c'est difficile.`,
  },

  equilibre: {
    id: 'equilibre',
    title: 'Fin Équilibre — La Vérité Amère',
    subtitle: 'Personne ne gagne. Tout le monde survit.',
    color: '#b070ff',
    skin: 'Seigneur des Ombres',
    text: `La Pierre reste brisée.
Les factions acceptent — à contrecœur — de coexister dans un monde imparfait.

Ce n'est pas la paix.
C'est l'absence de guerre pour l'instant.

L'Éveillé demeure fragmenté.
Pas libre. Pas emprisonné.
Suspendu quelque part entre les deux.

Vaeltharion continue d'errer dans la Forêt.
Mais il semble moins seul.

Aldric a témoigné.
Pas devant un tribunal.
Devant un survivant.
Une personne.
C'était assez pour commencer.

Le monde est instable.
Pas propre.
Pas certain.

Et libre.`,
    epilogue: `Théo a publié les notes de son père.
Anonymement.
La vérité circule.
Lentement, mais elle circule.`,
  },

  ombre: {
    id: 'ombre',
    title: "Fin Ombre — L'Avènement du Néant",
    subtitle: "L'Éveillé avait juste dix mille ans de faim.",
    color: '#e04060',
    skin: 'Porteur du Néant',
    text: `Le Vide t'engloutit.
L'Éveillé sort de ton corps comme une marée noire.
Il dévore la réalité couche par couche.

Éclatopia devient silence.

Pas dans la violence.
Dans l'indifférence.

L'Éveillé n'avait pas de haine.
Il avait juste dix mille ans de faim.

Vaeltharion essaie de contenir.
Il ne peut pas.
Il disparaît en dernier.
En silence.

Le dernier bruit qu'on entend dans ce monde
c'est Elias qui ferme son livre.`,
    epilogue: `Il n'y a pas d'épilogue.
Il n'y a plus personne pour l'écrire.`,
  },

  sacrifice: {
    id: 'sacrifice',
    title: 'Fin Sacrifice — Le Porteur Brisé',
    subtitle: 'Tu as choisi la seule issue que personne n\'avait prévue.',
    color: '#e8c96a',
    skin: 'Héros Brisé',
    triggerCondition: 'vide >= 85',
    triggerKey: 'b',
    text: `Juste avant que le Vide t'engloutisse complètement, tu brises le Lien.

Tu meurs.
Pas dans la douleur.
Dans la clarté.

Les couleurs reviennent.
Le monde reprend son souffle.

Quelque part, Aelara sent quelque chose se briser en elle.
Quelque part, Kael ferme les yeux.
Quelque part, Théo dessine une carte d'un endroit qu'il n'a jamais vu.
C'est là où tu es maintenant.

L'Éveillé perd son ancrage.
Il se fragmente.
Il s'endort.

Vaeltharion te voit partir.
Il hoche la tête.
Il dit quelque chose en vieux langage Éclatien.

Elias traduit plus tard.

« Merci d'avoir dit non. »`,
    epilogue: `Valériane plante quelque chose là où tu es tombé.
Elle ne dit pas ce que c'est.
Chaque année elle revient.`,
  },
};

function getEnding(id) { return ENDINGS[id] || ENDINGS.equilibre; }
