// ÉCLATOPIA 2 — data/dlg_vaeltharion.js — Vaeltharion, Le Veilleur
const DLG_VAELTHARION = {
  key: 'vaeltharion', name: 'Vaeltharion', title: 'Le Veilleur',
  color: '#7fffee', portraitFn: 'portraitVaeltharion',
  x: 800, zone: 'foret',
  nodes: {
    start: {
      speaker: 'Vaeltharion',
      text: "*(Sa voix est partout et nulle part à la fois.)*\n\nTu entends.",
      choices: [
        { text: "Oui.",                            next: 'oui_vaelt', effects: { flag: 'vaelt_contact' } },
        { text: "Qui êtes-vous ?",                 next: 'qui_vaelt' },
        { text: "...",                            next: 'silence_vaelt', effects: { flag: 'vaelt_silence_approuve' } },
      ]
    },
    oui_vaelt: {
      speaker: 'Vaeltharion',
      text: "Bien.\n\nBeaucoup passent ici. Peu entendent.\n\nCeux qui entendent… ils ont une question. Toujours la même.",
      choices: [
        { text: "Quelle question ?",               next: 'quelle_question' },
        { text: "Ma question est différente.",     next: 'question_diff', effects: { flag: 'vaelt_curiosite' } },
      ]
    },
    quelle_question: {
      speaker: 'Vaeltharion',
      text: "« Pourquoi. »\n\n*(Pause.)*\n\nT'as la tienne ?",
      choices: [
        { text: "Pourquoi vous ?",                 next: 'pourquoi_vaelt', effects: { flag: 'vaelt_question_qui' } },
        { text: "Pourquoi eux ?",                  next: 'pourquoi_eux', effects: { flag: 'vaelt_question_sacrifies' } },
        { text: "Pourquoi tout ça.",               next: 'pourquoi_tout' },
      ]
    },
    pourquoi_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Un silence qui dure.)*\n\nParce que je portais les mémoires de ceux qui restaient.\n\nJe pouvais pas partir. Tant qu'ils étaient là.",
      choices: [
        { text: "Qui est encore là ?",             next: 'encore_la', effects: { flag: 'vaelt_ames' } },
        { text: "Et maintenant — vous pouvez partir ?", next: 'partir_vaelt', effects: { flag: 'vaelt_liberation_possible' } },
      ]
    },
    encore_la: {
      speaker: 'Vaeltharion',
      text: "Tous ceux qui n'ont pas été libérés.\n\nLeurs mémoires flottent dans la forêt.\n\nLes arbres les gardent. Moi aussi.",
      choices: [
        { text: "Comment les libérer ?",           next: 'liberer', effects: { flag: 'vaelt_liberation_methode' } },
        { text: "Vous souffrez ?",                 next: 'souffre_vaelt', effects: { flag: 'vaelt_emotions' } },
      ]
    },
    liberer: {
      speaker: 'Vaeltharion',
      text: "Quelqu'un doit les nommer.\n\nPas les noms officiels. Les vrais.\n\nCeux que leurs proches utilisaient.",
      choices: [
        { text: "Je trouverai ces noms.",          next: null, close: true, effects: { quest: 'quete_vaelt_noms', flag: 'vaelt_quete_noms', morale: +5 } },
        { text: "Où les trouver ?",                next: 'trouver_noms' },
      ]
    },
    trouver_noms: {
      speaker: 'Vaeltharion',
      text: "Les survivants. Les lettres interceptées. Le carnet d'Aldric.\n\nIls ont les noms.",
      choices: [
        { text: "Je les rassemblerai.",            next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +5 } },
      ]
    },
    souffre_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Une pause longue.)*\n\nLa souffrance… c'est quelque chose que tu ressens dans un corps.\n\nJe sais pas si ce que je vis s'appelle souffrance.\n\nMais il y a quelque chose. Oui.",
      choices: [
        { text: "Je suis désolé.",                 next: 'desole_vaelt', effects: { morale: +3 } },
        { text: "Qu'est-ce que c'est alors ?",     next: 'quoi_ressent' },
      ]
    },
    desole_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Un silence doux.)*\n\nMerci.\n\nC'est rare.",
      choices: [
        { text: "Je chercherai les noms.",         next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +5 } },
        { text: "Est-ce que vous vouliez être ici ?", next: 'voulait_vaelt' },
      ]
    },
    voulait_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Pause.)*\n\nPersonne m'a demandé.\n\nIls ont dit « tu porteras leur mémoire ».\n\nJe pouvais pas refuser.",
      choices: [
        { text: "On vous a contraint.",            next: 'contraint_vaelt', effects: { flag: 'vaelt_victime_aussi', morale: +3 } },
        { text: "Vous auriez refusé si vous aviez pu ?", next: 'refus_vaelt' },
      ]
    },
    contraint_vaelt: {
      speaker: 'Vaeltharion',
      text: "C'est un mot que vous utilisez beaucoup.\n\nContraint.\n\nMais même contraint… j'ai choisi de porter plutôt que d'abandonner.\n\nC'est encore un choix.",
      choices: [
        { text: "Un choix difficile.",             next: null, close: true, effects: { morale: +3, flag: 'vaelt_nuance' } },
      ]
    },
    refus_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Longue pause.)*\n\nNon.\n\nMême si j'avais eu le choix.\n\nParce que si j'abandonnais ces mémoires… elles auraient disparu.\n\nEt leur existence — leur vraie existence — aurait été effacée.",
      choices: [
        { text: "Vous avez choisi qu'ils comptent.", next: null, close: true, effects: { morale: +8, flag: 'vaelt_choix_memoire' } },
      ]
    },
    quoi_ressent: {
      speaker: 'Vaeltharion',
      text: "De l'attente.\n\nLongue. Très longue.\n\nEt parfois… de la colère. Quand quelqu'un prétend comprendre sans chercher.",
      choices: [
        { text: "Et avec moi ?",                   next: 'avec_moi_vaelt', effects: { flag: 'vaelt_juge_heros' } },
      ]
    },
    avec_moi_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Pause.)*\n\nT'as posé des questions.\n\nEt t'as attendu les réponses.\n\nC'est différent.",
      choices: [
        { text: "Merci.",                          next: null, close: true, effects: { morale: +5, flag: 'vaelt_respect_heros' } },
        { text: "Je chercherai les noms.",         next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +5 } },
      ]
    },
    partir_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Un long silence.)*\n\nSi quelqu'un les nomme.\n\nS'ils sont reconnus.\n\nAlors peut-être.",
      choices: [
        { text: "Je m'en occupe.",                 next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +5 } },
        { text: "Vous voulez partir ?",            next: 'vouloir_partir' },
      ]
    },
    vouloir_partir: {
      speaker: 'Vaeltharion',
      text: "*(Longue pause.)*\n\nJe veux qu'ils soient en paix.\n\nEt moi avec.\n\nC'est la même chose.",
      choices: [
        { text: "D'accord.",                       next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +5 } },
      ]
    },
    question_diff: {
      speaker: 'Vaeltharion',
      text: "*(Ce qui pourrait être de la curiosité.)*\n\nDis.",
      choices: [
        { text: "Comment tout ça finira.",         next: 'comment_finira', effects: { flag: 'vaelt_question_fin' } },
        { text: "Ce que vous ressentez.",          next: 'souffre_vaelt' },
        { text: "Si vous vouliez être là.",        next: 'voulait_vaelt' },
      ]
    },
    comment_finira: {
      speaker: 'Vaeltharion',
      text: "*(Longue pause.)*\n\nComme vous déciderez.\n\nL'histoire a besoin de quelqu'un pour la terminer.\n\nPas d'un héros. D'un témoin.",
      choices: [
        { text: "Un témoin.",                      next: 'temoin_vaelt', effects: { morale: +5, flag: 'vaelt_heros_temoin' } },
      ]
    },
    temoin_vaelt: {
      speaker: 'Vaeltharion',
      text: "Quelqu'un qui voit. Qui entend. Qui n'oublie pas.\n\nEt qui aide les autres à comprendre.\n\nPas à conclure. À comprendre.",
      choices: [
        { text: "Je serai ce témoin.",             next: null, close: true, effects: { morale: +8, flag: 'heros_temoin_accepte', item: 'parole_vaeltharion' } },
      ]
    },
    qui_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Un silence.)*\n\nUn souvenir qui n'a pas encore trouvé comment se taire.",
      choices: [
        { text: "Souvenir de qui ?",               next: 'souvenir_qui', effects: { flag: 'vaelt_memoire' } },
        { text: "...",                            next: 'oui_vaelt' },
      ]
    },
    souvenir_qui: {
      speaker: 'Vaeltharion',
      text: "De ceux qu'on a oubliés.\n\nExprès.\n\n*(Pause.)*\n\nLa forêt garde ce que les hommes ont voulu enterrer.",
      choices: [
        { text: "Qu'est-ce qu'ils ont voulu enterrer ?", next: 'quoi_enterre', effects: { flag: 'vaelt_verite_enterre' } },
        { text: "Je suis venu pour chercher.",     next: 'quelle_question' },
      ]
    },
    quoi_enterre: {
      speaker: 'Vaeltharion',
      text: "Les noms. Les visages. Les raisons.\n\nEt le fait que certains ont dit non.\n\nOn a enterré ceux qui ont résisté plus profondément que les autres.",
      choices: [
        { text: "Pour qu'on n'apprenne pas que la résistance était possible.", next: null, close: true, effects: { morale: +5, flag: 'vaelt_resistance_enterree', quest: 'quete_vaelt_noms' } },
      ]
    },
    silence_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Un silence encore plus long.)*\n\nBien.\n\nTu sais écouter avant de parler.\n\nC'est rare.",
      choices: [
        { text: "Qui êtes-vous ?",                 next: 'qui_vaelt' },
        { text: "Que portez-vous ?",               next: 'quoi_porte', effects: { flag: 'vaelt_question_fardeau' } },
      ]
    },
    quoi_porte: {
      speaker: 'Vaeltharion',
      text: "Ce qu'ils n'ont pas pu emporter.\n\nLeurs derniers moments.\n\nLeurs dernières pensées.\n\nEt leurs noms. Tous leurs noms.",
      choices: [
        { text: "Vous les connaissez tous ?",      next: 'tous_noms', effects: { flag: 'vaelt_tous_noms' } },
      ]
    },
    tous_noms: {
      speaker: 'Vaeltharion',
      text: "Oui.\n\n*(Pause.)*\n\nÇa prend de la place.",
      choices: [
        { text: "...",                            next: null, close: true, effects: { morale: +5, flag: 'vaelt_humanise' } },
        { text: "Je les trouverai aussi.",         next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +8 } },
      ]
    },
    pourquoi_eux: {
      speaker: 'Vaeltharion',
      text: "*(Un silence très long.)*\n\nParce qu'ils étaient là.\n\nOu parce qu'ils avaient dit non à autre chose avant.\n\nOu parce que quelqu'un avait besoin que ce soit eux.",
      choices: [
        { text: "Des critères arbitraires.",       next: 'arbitraire', effects: { flag: 'vaelt_arbitraire_sacrifice' } },
        { text: "Quelqu'un avait besoin que ce soit eux ?", next: 'besoin_eux' },
      ]
    },
    arbitraire: {
      speaker: 'Vaeltharion',
      text: "Pas complètement.\n\nCeux qui avaient du pouvoir étaient protégés.\n\nCeux qui pouvaient protester étaient choisis en premier.\n\nCe n'est pas aléatoire. C'est stratégique.",
      choices: [
        { text: "Pour réduire la résistance.",     next: null, close: true, effects: { flag: 'vaelt_strategie_sacrifice', morale: +3 } },
      ]
    },
    besoin_eux: {
      speaker: 'Vaeltharion',
      text: "Certains étaient choisis parce qu'ils posaient trop de questions.\n\nOu parce qu'ils avaient refusé autre chose avant.\n\nLe sacrifice comme outil politique.",
      choices: [
        { text: "...",                            next: null, close: true, effects: { morale: +3, flag: 'vaelt_politique_2', quest: 'quete_vaelt_noms' } },
      ]
    },
    pourquoi_tout: {
      speaker: 'Vaeltharion',
      text: "*(Un silence qui dure longtemps.)*\n\nParce que quelqu'un a voulu la lumière plus que la vie des autres.\n\nEt personne a dit non assez fort.",
      choices: [
        { text: "Et vous — vous avez dit non ?",  next: 'non_vaelt', effects: { flag: 'vaelt_resistance_propre' } },
        { text: "Comment faire que ça recommence pas ?", next: 'recommence' },
      ]
    },
    non_vaelt: {
      speaker: 'Vaeltharion',
      text: "*(Très long silence.)*\n\nJ'ai dit non.\n\nEt me voilà.",
      choices: [
        { text: "...",                            next: null, close: true, effects: { morale: +8, flag: 'vaelt_resistance_paye' } },
      ]
    },
    recommence: {
      speaker: 'Vaeltharion',
      text: "Nommer.\n\nTout.\n\nCe qui a été fait. Qui l'a fait. Pourquoi.\n\nEt surtout — nommer ceux qui ont dit non.\n\nPour que les gens sachent que c'était possible.",
      choices: [
        { text: "Je m'en charge.",                next: null, close: true, effects: { quest: 'quete_vaelt_noms', morale: +8, flag: 'vaelt_mission_heros' } },
      ]
    },
  }
};
