// ÉCLATOPIA 2 — data/dlg_theo.js — Théo l'Ingénieur
const DLG_THEO = {
  key: 'theo', name: 'Théo', title: 'Ingénieur',
  color: '#3acfaa', portraitFn: 'portraitTheo',
  x: 620, zone: 'foret',
  nodes: {
    start: {
      speaker: 'Théo',
      text: "*(Il dessine quelque chose. Lève les yeux.)*\n\nAh. T'as l'air de quelqu'un qui a des questions.\n\nMoi aussi.",
      choices: [
        { text: "C'est quoi tu dessines ?", next: 'dessin' },
        { text: "Tu sais des choses sur cette forêt ?", next: 'foret_theo' },
        { text: "Tu connais les mécanismes de la Pierre ?", next: 'pierre_theo', effects: { flag: 'theo_pierre_question' } },
      ]
    },
    dessin: {
      speaker: 'Théo',
      text: "*(Il te montre.)*\n\nUn diagramme du réseau d'énergie de la Pierre. Ou ce qu'il en reste.\n\nMon père était ingénieur en chef. Il m'a appris à lire ces plans avant de me parler d'autre chose.",
      choices: [
        { text: "Et ça ressemble à quoi ?", next: 'resemble' },
        { text: "Ton père travaillait sur la Pierre ?", next: 'pere_theo', effects: { flag: 'theo_pere_mention' } },
      ]
    },
    resemble: {
      speaker: 'Théo',
      text: "À un système circulatoire. Comme le sang dans un corps.\n\nSauf que le corps… c'est tout Éclatopia.\n\nEt le sang…\n\n*(Il s'arrête.)*\n\nCherche les stèles dans la forêt. Elles expliquent mieux que moi.",
      choices: [
        { text: "Non. Dis-le toi-même.", next: 'dis_toi' },
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'theo_a_dit_steles' } },
      ]
    },
    dis_toi: {
      speaker: 'Théo',
      text: "*(Il prend une inspiration.)*\n\nDe l'énergie humaine. De la vie humaine. Prélevée progressivement.\n\nSur tous les habitants.\n\nEt parfois… plus directement.",
      choices: [
        { text: "Les sacrifices.", next: 'sacrifices_theo', effects: { flag: 'theo_confirme_sacrifice', morale: -3 } },
        { text: "...", next: 'silence_theo' },
      ]
    },
    sacrifices_theo: {
      speaker: 'Théo',
      text: "Ouais.\n\nMon père calculait l'efficacité. Les quantités. Les fréquences.\n\n*(Il regarde son dessin.)*\n\nJe comprends les maths. Je comprends pas le reste.",
      choices: [
        { text: "Le reste c'est l'humain.", next: null, close: true, effects: { morale: +3, flag: 'theo_comprend_limite' } },
        { text: "...", next: null, close: true },
      ]
    },
    pere_theo: {
      speaker: 'Théo',
      text: "Ingénieur en chef. Mordred lui faisait confiance.\n\nIl m'a appris le métier avant de me parler d'éthique.\n\nEn fait… il m'a jamais vraiment parlé d'éthique.",
      choices: [
        { text: "Tu t'y es intéressé tout seul ?", next: 'seul_ethique', effects: { morale: +3 } },
        { text: "Et ça t'a manqué ?", next: 'manque_ethique' },
        { text: "Il savait ce que la Pierre prenait ?", next: 'pere_savait', effects: { flag: 'pere_theo_savait' } },
      ]
    },
    seul_ethique: {
      speaker: 'Théo',
      text: "*(Il hausse les épaules.)*\n\nQuand j'ai lu les notes et que j'ai compris… je pouvais plus faire semblant de pas savoir.",
      choices: [
        { text: "Tu as bien fait.", next: null, close: true, effects: { morale: +5, flag: 'theo_confiance' } },
      ]
    },
    manque_ethique: {
      speaker: 'Théo',
      text: "Ouais et non.\n\nSavoir l'éthique plus tôt… ça m'aurait peut-être empêché de travailler.\n\nMaintenant que je l'ai appris moi-même… je sais pourquoi je veux changer les choses.",
      choices: [
        { text: "Mieux vaut tard que jamais.", next: null, close: true, effects: { morale: +2 } },
      ]
    },
    pere_savait: {
      speaker: 'Théo',
      text: "*(Il hésite.)*\n\nOuais.\n\nSes notes sont très précises sur les quantités. Et sur les sources.\n\n*(Il s'arrête.)*\n\nIl appelait ça de la « bioénergie distribuée ».\n\nJ'aurais préféré qu'il trouve un autre terme.",
      choices: [
        { text: "Tu lui as jamais pardonné ?", next: 'pardon_pere_theo', effects: { flag: 'theo_pere_relation' } },
        { text: "Tu as ses notes ?", next: 'notes_pere_theo', effects: { flag: 'theo_notes_pere', quest: 'quete_notes_theo' } },
      ]
    },
    pardon_pere_theo: {
      speaker: 'Théo',
      text: "*(Long silence.)*\n\nJe sais pas si pardonner c'est le bon mot.\n\nJe comprends ce qu'il a fait. Pourquoi il l'a fait.\n\nÇa suffit pas pour être en paix avec.",
      choices: [
        { text: "Ce n'est pas pareil, comprendre et pardonner.", next: null, close: true, effects: { morale: +3, flag: 'theo_confiance' } },
        { text: "Il méritait d'être pardonné ?", next: 'merite_pardon_theo' },
      ]
    },
    merite_pardon_theo: {
      speaker: 'Théo',
      text: "Est-ce que quelqu'un mérite le pardon ?\n\nOu est-ce qu'on pardonne parce qu'on a besoin de pouvoir continuer ?",
      choices: [
        { text: "Les deux peuvent être vrais.", next: null, close: true, effects: { morale: +2, flag: 'theo_confiance' } },
      ]
    },
    notes_pere_theo: {
      speaker: 'Théo',
      text: "Quelque part. Je les ai jamais fini de lire.\n\nParce qu'à chaque page je trouve quelque chose que j'aurais préféré pas savoir.",
      choices: [
        { text: "Je peux t'aider.", next: 'aide_notes', effects: { quest: 'quete_notes_theo', morale: +3 } },
        { text: "Est-ce que tu veux les finir ?", next: 'finir_notes' },
      ]
    },
    aide_notes: {
      speaker: 'Théo',
      text: "*(Il te regarde.)*\n\nPourquoi ? T'as rien à y gagner.",
      choices: [
        { text: "La vérité. Pour moi aussi.", next: null, close: true, effects: { quest: 'quete_notes_theo', flag: 'theo_confiance', morale: +3 } },
        { text: "Pour t'aider.", next: null, close: true, effects: { quest: 'quete_notes_theo', flag: 'theo_confiance_max', morale: +5 } },
      ]
    },
    finir_notes: {
      speaker: 'Théo',
      text: "*(Il réfléchit longuement.)*\n\nPeut-être que les notes me diront aussi ce qu'il a essayé de faire.\n\n*(Il hoche la tête.)*\n\nD'accord. Aide-moi à les finir.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_notes_theo', flag: 'theo_confiance_max' } },
      ]
    },
    foret_theo: {
      speaker: 'Théo',
      text: "La forêt c'est un résidu.\n\nL'énergie qui a été absorbée… une partie est revenue là. Transformée en mémoire. En échos.\n\nMon père appelait ça de la « persistance thermique ». J'appelle ça des fantômes.",
      choices: [
        { text: "Des fantômes des sacrifiés ?", next: 'fantomes_theo', effects: { flag: 'theo_fantomes_foret' } },
        { text: "Est-ce dangereux ?", next: 'dangereux_theo' },
      ]
    },
    fantomes_theo: {
      speaker: 'Théo',
      text: "En partie. Pas leur personnalité entière. Juste les moments forts. Les émotions intenses.\n\nC'est pour ça que la forêt est oppressante. Elle rejoue des moments de peur, de résignation, de douleur.",
      choices: [
        { text: "Et de colère.", next: 'colere_theo', effects: { flag: 'vaeltharion_colere' } },
        { text: "Comment on les aide ?", next: null, close: true, effects: { quest: 'quete_vaelt_noms' } },
      ]
    },
    colere_theo: {
      speaker: 'Théo',
      text: "*(Il s'arrête.)*\n\nOuais. Surtout de colère.\n\nCeux qui ont dit non. Ceux qui ont résisté.\n\nIls sont encore là. Et ils attendent que quelqu'un entende.",
      choices: [
        { text: "J'entendrai.", next: null, close: true, effects: { morale: +5, quest: 'quete_vaelt_noms' } },
      ]
    },
    dangereux_theo: {
      speaker: 'Théo',
      text: "Ça dépend.\n\nSi tu restes trop longtemps dans les zones de forte concentration… ça peut brouiller la frontière entre toi et les mémoires.\n\nT'as l'impression que leurs pensées sont les tiennes.",
      choices: [
        { text: "Comment rester lucide ?", next: 'lucide_theo', effects: { item: 'conseil_prenom' } },
      ]
    },
    lucide_theo: {
      speaker: 'Théo',
      text: "Rappelle-toi quelque chose d'ancré en toi. Un souvenir précis. Un prénom.\n\nQuelque chose qui est à toi et pas à eux.",
      choices: [
        { text: "Merci.", next: null, close: true, effects: { item: 'conseil_prenom', morale: +2 } },
      ]
    },
    pierre_theo: {
      speaker: 'Théo',
      text: "Les mécanismes. Oui.\n\nMon père m'a appris l'ingénierie avant de me parler de l'éthique.\n\nEn fait… il m'a jamais vraiment parlé de l'éthique.",
      choices: [
        { text: "Tu t'y es intéressé tout seul ?", next: 'seul_ethique', effects: { morale: +3 } },
        { text: "T'as des pistes pour remplacer la Pierre ?", next: 'pistes_pierre_theo', effects: { flag: 'theo_cherche_alternative' } },
      ]
    },
    pistes_pierre_theo: {
      speaker: 'Théo',
      text: "Des pistes théoriques.\n\nLes éclats de la Pierre — si on les utilise autrement. Pas pour centraliser l'énergie mais pour la distribuer. Sans prélèvement. Sans sacrifice.\n\nMais j'ai besoin de quelqu'un pour tester ça dans le monde réel.",
      choices: [
        { text: "Je peux tester.", next: null, close: true, effects: { quest: 'quete_alternative', morale: +3 } },
        { text: "Et si ça marche pas ?", next: 'marche_pas_theo' },
      ]
    },
    marche_pas_theo: {
      speaker: 'Théo',
      text: "On continue à chercher.\n\nMon père a cherché toute sa vie. Moi j'ai commencé plus tôt. Et j'ai un avantage qu'il avait pas.",
      choices: [
        { text: "Lequel ?", next: 'avantage_theo' },
      ]
    },
    avantage_theo: {
      speaker: 'Théo',
      text: "Je sais ce qu'il ne faut pas faire.\n\nGrâce à lui.",
      choices: [
        { text: "C'est quelque chose.", next: null, close: true, effects: { morale: +3, flag: 'theo_confiance' } },
      ]
    },
    silence_theo: {
      speaker: '...',
      text: "*(Un silence s'installe.)*",
      choices: [
        { text: "Ton père savait ce qu'il faisait.", next: 'pere_savait' },
        { text: "Je pars.", next: null, close: true },
      ]
    },
  }
};
