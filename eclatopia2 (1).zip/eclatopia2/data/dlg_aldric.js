// ÉCLATOPIA 2 — data/dlg_aldric.js — Aldric, le Capitaine
const DLG_ALDRIC = {
  key: 'aldric', name: 'Aldric', title: '???',
  color: '#8090a0', portraitFn: 'portraitAldric',
  x: -700, zone: 'montagne',
  nodes: {
    start: {
      speaker: '???',
      text: "*(L'homme lève la tête. Il t'a entendu arriver de loin.)*\n\nT'aurais pas dû venir ici.",
      choices: [
        { text: "Je cherche Aldric.", next: 'cherche_aldric' },
        { text: "Je cherche juste un abri.", next: 'abri_aldric' },
        { text: "Valériane m'a dit que tu étais ici.", next: 'valeriane_dit_aldric', effects: { flag: 'aldric_sait_valeriane' } },
        { text: "Elias m'a dit de te trouver.", next: 'elias_dit_aldric', effects: { flag: 'aldric_sait_elias' } },
      ]
    },
    cherche_aldric: {
      speaker: '???',
      text: "*(Long silence.)*\n\nPourquoi ?",
      choices: [
        { text: "Pour comprendre ce qui s'est passé.", next: 'revele_aldric' },
        { text: "Pour lui donner une chance de s'expliquer.", next: 'chance_aldric', effects: { morale: +3 } },
        { text: "Pour lui demander des comptes.", next: 'comptes_aldric', effects: { morale: -5 } },
      ]
    },
    revele_aldric: {
      speaker: 'Aldric',
      text: "*(Il baisse la tête.)*\n\nC'est moi.\n\nAldric. Ancien capitaine des Gardiens.",
      choices: [
        { text: "Qu'est-ce que tu as fait ?", next: 'quoi_fait_aldric', effects: { flag: 'aldric_revele' } },
        { text: "Pourquoi tu te caches ?", next: 'pourquoi_cache_aldric' },
      ]
    },
    quoi_fait_aldric: {
      speaker: 'Aldric',
      text: "*(Il ne répond pas tout de suite.)*\n\nJ'ai exécuté des ordres.\n\nDes ordres que j'aurais dû refuser.",
      choices: [
        { text: "Quels ordres ?", next: 'quels_ordres_aldric', effects: { flag: 'aldric_ordres' } },
        { text: "Pourquoi tu les as pas refusés ?", next: 'pourquoi_pas_refuse_aldric' },
      ]
    },
    quels_ordres_aldric: {
      speaker: 'Aldric',
      text: "*(Il prend une longue inspiration.)*\n\nRassembler les personnes désignées.\n\nLes escorter jusqu'au Temple.\n\nVeiller à ce que ça se passe… dans l'ordre.",
      choices: [
        { text: "Les personnes désignées pour le sacrifice.", next: 'sacrifice_direct_aldric', effects: { flag: 'aldric_sacrifice_confirme', morale: -5 } },
        { text: "Et tu savais ce qui allait leur arriver ?", next: 'savait_aldric' },
      ]
    },
    savait_aldric: {
      speaker: 'Aldric',
      text: "*(Il ferme les yeux.)*\n\nOuais.\n\nJe savais.",
      choices: [
        { text: "Et tu l'as fait quand même.", next: 'fait_quand_meme_aldric', effects: { morale: -5 } },
        { text: "Comment tu vivais avec ça ?", next: 'vivre_avec_aldric' },
      ]
    },
    fait_quand_meme_aldric: {
      speaker: 'Aldric',
      text: "Ouais.\n\n*(Pause.)*\n\nJe me disais que si c'est pas moi… ce sera quelqu'un d'autre. Et que moi au moins je le ferai avec… respect.\n\n*(Il s'arrête.)*\n\nJe sais comment ça sonne.",
      choices: [
        { text: "Ça sonne comme une excuse.", next: 'excuse_aldric', effects: { morale: -3 } },
        { text: "Ça sonne comme quelqu'un qui savait que c'était mal.", next: 'savait_mal_aldric', effects: { morale: +3 } },
      ]
    },
    excuse_aldric: {
      speaker: 'Aldric',
      text: "*(Il hoche la tête.)*\n\nOuais. C'est une excuse.\n\nEt c'est pour ça que je suis ici.",
      choices: [
        { text: "Tu te punis.", next: 'se_punit_aldric' },
        { text: "Te cacher c'est pas te punir.", next: 'cacher_pas_punir_aldric', effects: { morale: +2 } },
      ]
    },
    se_punit_aldric: {
      speaker: 'Aldric',
      text: "Pas vraiment.\n\nJe sais pas quoi payer. Je sais pas ce qui suffirait.",
      choices: [
        { text: "Témoigner pourrait suffire.", next: 'temoigner_aldric', effects: { morale: +5, quest: 'quete_aldric' } },
      ]
    },
    temoigner_aldric: {
      speaker: 'Aldric',
      text: "*(Il te regarde longuement.)*\n\nTémoigner. Devant qui ?",
      choices: [
        { text: "Devant ceux qui veulent savoir.", next: 'temoignage_accept', effects: { morale: +3, flag: 'aldric_temoignage_accepte' } },
        { text: "Devant les survivants.", next: 'devant_survivants_aldric', effects: { morale: +5 } },
      ]
    },
    temoignage_accept: {
      speaker: 'Aldric',
      text: "D'accord.\n\nMais j'ai besoin de preuves de ce que j'ai fait. Pour pas pouvoir me défausser.\n\nIl y a des documents dans les ruines du Temple. Trouve-les.",
      choices: [
        { text: "Je les trouverai.", next: null, close: true, effects: { quest: 'quete_aldric', flag: 'aldric_temoignage_futur', item: null } },
      ]
    },
    devant_survivants_aldric: {
      speaker: 'Aldric',
      text: "*(Il ferme les yeux.)*\n\nJe sais pas si je peux regarder leurs yeux.\n\nMais t'as raison. C'est à eux que je dois répondre.",
      choices: [
        { text: "Je t'aiderai.", next: null, close: true, effects: { quest: 'quete_aldric', flag: 'aldric_survivants_temoignage', morale: +5 } },
      ]
    },
    cacher_pas_punir_aldric: {
      speaker: 'Aldric',
      text: "T'as raison.\n\nAlors c'est quoi — me cacher ?\n\n*(Pause.)*\n\nPeut-être que j'attends quelque chose.",
      choices: [
        { text: "Que quelqu'un vienne te chercher.", next: 'quelquun_cherche_aldric', effects: { morale: +3 } },
      ]
    },
    quelquun_cherche_aldric: {
      speaker: 'Aldric',
      text: "*(Il te regarde longuement.)*\n\nOuais.\n\nEt maintenant t'es là.\n\n*(Pause.)*\n\nC'est pas une coïncidence.",
      choices: [
        { text: "Qu'est-ce que tu veux faire maintenant ?", next: 'temoigner_aldric', effects: { quest: 'quete_aldric' } },
      ]
    },
    savait_mal_aldric: {
      speaker: 'Aldric',
      text: "Ouais.\n\nLe problème c'est que savoir que c'est mal… ça suffit pas. Il faut aussi agir en conséquence.",
      choices: [
        { text: "Tu peux encore agir.", next: 'temoigner_aldric', effects: { morale: +3 } },
      ]
    },
    vivre_avec_aldric: {
      speaker: 'Aldric',
      text: "Pas bien.\n\nUn jour j'ai arrêté de dormir.\n\nQuand j'ai escorté une famille. La mère. Le père. Deux enfants.\n\nLes enfants m'ont demandé si on allait voir de la lumière.\n\n*(Sa voix se brise légèrement.)*\n\nJ'ai dit oui.",
      choices: [
        { text: "...", next: null, close: true, effects: { morale: +3, flag: 'aldric_famille_enfants' } },
        { text: "Tu leur as menti pour les protéger.", next: 'menti_proteger_aldric', effects: { morale: +2 } },
      ]
    },
    menti_proteger_aldric: {
      speaker: 'Aldric',
      text: "*(Il rit amèrement.)*\n\nOuais. C'est ce que je me disais.\n\nMais mentir pour protéger quelqu'un… c'est quand même mentir.\n\nEt ça m'a pas empêché de continuer à marcher.",
      choices: [
        { text: "...", next: null, close: true, effects: { flag: 'aldric_moment_rupture' } },
      ]
    },
    leurs_noms: {
      speaker: 'Aldric',
      text: "*(Il se lève. Sort un petit carnet.)*\n\nOuais.\n\nJ'ai gardé une liste. En secret. Contre les ordres.\n\nJe sais pas pourquoi j'ai fait ça à l'époque. Maintenant je sais.",
      choices: [
        { text: "Pour ne pas oublier.", next: 'carnet_donner', effects: { morale: +5 } },
        { text: "Pour te rappeler ce que t'as fait.", next: 'carnet_donner', effects: { morale: +2 } },
      ]
    },
    carnet_donner: {
      speaker: 'Aldric',
      text: "*(Il te regarde.)*\n\nOuais. Et parce que si quelqu'un venait un jour chercher des réponses…\n\nTu veux le carnet ?",
      choices: [
        { text: "Oui.", next: null, close: true, effects: { item: 'carnet_aldric', quest: 'quete_aldric', flag: 'carnet_obtenu', morale: +5 } },
        { text: "Garde-le. Mais témoigne.", next: 'temoigner_aldric', effects: { morale: +3 } },
      ]
    },
    sacrifice_direct_aldric: {
      speaker: 'Aldric',
      text: "*(Il détourne les yeux.)*\n\nOuais.",
      choices: [
        { text: "Combien ?", next: 'combien_aldric' },
        { text: "T'as leurs noms ?", next: 'leurs_noms' },
      ]
    },
    combien_aldric: {
      speaker: 'Aldric',
      text: "*(Un très long silence.)*\n\nJe les ai tous comptés. Dans ma tête. Toutes les nuits depuis.\n\nJe les ai tous.",
      choices: [
        { text: "...", next: null, close: true, effects: { morale: +3, flag: 'aldric_hante' } },
        { text: "T'as leurs noms ?", next: 'leurs_noms' },
      ]
    },
    pourquoi_pas_refuse_aldric: {
      speaker: 'Aldric',
      text: "*(Il regarde ses mains.)*\n\nParce que j'avais peur.\n\nEt parce que… j'avais confiance en Mordred.\n\nIl avait une façon de présenter les choses qui semblait logique.",
      choices: [
        { text: "La logique ne justifie pas tout.", next: null, close: true, effects: { morale: +3, flag: 'aldric_logique_non' } },
        { text: "Et maintenant ?", next: 'temoigner_aldric' },
      ]
    },
    pourquoi_cache_aldric: {
      speaker: 'Aldric',
      text: "Parce que ceux que j'ai aidés à tuer méritaient mieux que de voir leur bourreau vivre normalement.",
      choices: [
        { text: "Te cacher c'est aussi une façon d'éviter.", next: 'cacher_pas_punir_aldric', effects: { morale: +2 } },
        { text: "Je peux t'aider à te présenter.", next: 'temoigner_aldric', effects: { morale: +5 } },
      ]
    },
    abri_aldric: {
      speaker: '???',
      text: "*(Il te regarde longuement.)*\n\nIl y a une grotte 200 mètres au nord.\n\nPars.",
      choices: [
        { text: "T'es Aldric.", next: 'revele_aldric', effects: { flag: 'heros_reconnait_aldric' } },
        { text: "Merci.", next: null, close: true },
      ]
    },
    valeriane_dit_aldric: {
      speaker: 'Aldric',
      text: "*(Il se retourne brusquement.)*\n\nValériane.\n\n*(Il lâche un soupir.)*\n\nElle a pas changé.",
      choices: [
        { text: "Vous vous connaissez bien ?", next: 'connaissent_valer_aldric' },
        { text: "Elle m'a dit de venir.", next: 'revele_aldric' },
      ]
    },
    connaissent_valer_aldric: {
      speaker: 'Aldric',
      text: "Elle soignait les personnes que j'escortais.\n\nNous on se croisait dans les couloirs du Temple. On se regardait pas dans les yeux.\n\n*(Un silence.)*\n\nOn s'est pas reparlé depuis.",
      choices: [
        { text: "...", next: 'revele_aldric' },
      ]
    },
    elias_dit_aldric: {
      speaker: 'Aldric',
      text: "*(Il se raidit.)*\n\nElias.\n\n*(Très long silence.)*\n\nQu'est-ce qu'il t'a dit sur moi ?",
      choices: [
        { text: "Que tu as exécuté les ordres.", next: 'executant_aldric', effects: { flag: 'elias_aldric_dit' } },
        { text: "Juste ton nom.", next: 'revele_aldric' },
      ]
    },
    executant_aldric: {
      speaker: 'Aldric',
      text: "*(Il hoche la tête.)*\n\nC'est exact.\n\nElias gardait les traces. Moi j'exécutais. On était deux rouages différents du même mécanisme.",
      choices: [
        { text: "Et Mordred était la tête.", next: 'mordred_tete_aldric', effects: { flag: 'mordred_chef_mecanisme' } },
        { text: "Un crime a besoin des trois.", next: 'trois_aldric', effects: { morale: +2 } },
      ]
    },
    mordred_tete_aldric: {
      speaker: 'Aldric',
      text: "Ouais.\n\nMordred décidait. J'exécutais. Elias archivait.\n\n*(Pause.)*\n\nUn crime a besoin des trois.",
      choices: [
        { text: "C'est une analyse lucide.", next: null, close: true, effects: { morale: +3, flag: 'aldric_confiance' } },
      ]
    },
    trois_aldric: {
      speaker: 'Aldric',
      text: "Ouais.\n\nÀ des degrés différents. Mais ouais.",
      choices: [
        { text: "...", next: null, close: true, effects: { flag: 'aldric_confiance', morale: +2 } },
      ]
    },
    chance_aldric: {
      speaker: '???',
      text: "*(Il te regarde longtemps.)*\n\nC'est moi — Aldric.",
      choices: [
        { text: "Je t'écoute.", next: 'quoi_fait_aldric', effects: { flag: 'aldric_revele' } },
      ]
    },
    comptes_aldric: {
      speaker: '???',
      text: "*(Il te regarde froidement.)*\n\nT'as les mains pour ça ?",
      choices: [
        { text: "Non. Tu as raison.", next: 'revele_aldric', effects: { morale: +3 } },
        { text: "Je trouverai bien.", next: 'refuse_comptes' },
      ]
    },
    refuse_comptes: {
      speaker: 'Aldric',
      text: "*(Il se lève. Te regarde calmement.)*\n\nJe suis armé. Et j'ai survécu à plus difficile.\n\nMais je vais pas me battre. Mourir en me défendant… c'est encore une façon d'éviter de répondre.\n\nSi tu veux des réponses — assieds-toi.",
      choices: [
        { text: "Je veux des réponses.", next: 'quoi_fait_aldric', effects: { morale: +3 } },
      ]
    },
  }
};
