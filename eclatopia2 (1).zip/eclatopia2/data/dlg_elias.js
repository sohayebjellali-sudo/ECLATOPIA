// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/dlg_elias.js
// Dialogues d'Elias — cryptiques, fragmentés
// Il ne dit jamais tout. Il teste. Il mesure.
// ═══════════════════════════════════════════════════════════

const DLG_ELIAS = {
  key: 'elias',
  name: 'Elias',
  title: 'Archiviste',
  color: '#c8a060',
  portraitFn: 'portraitElias',
  x: -220, zone: 'foret',

  nodes: {

    start: {
      speaker: 'Elias',
      text: "*(Il lève les yeux de son livre. Longue pause.)*\n\nAh. T'as survécu jusqu'ici.",
      choices: [
        { text: "Qui êtes-vous ?",                              next: 'identite' },
        { text: "Cette forêt — qu'est-ce qui s'y passe ?",     next: 'foret_mystere' },
        { text: "Je cherche quelque chose.",                    next: 'cherche' },
        { text: "Je passe juste.",                             next: null, close: true },
      ]
    },

    identite: {
      speaker: 'Elias',
      text: "Quelqu'un qui devrait être mort.\n\n*(Il replonge dans son livre.)*\n\nArchiviste. Enfin. Je l'étais.",
      choices: [
        { text: "Vous l'étiez ?",             next: 'etait' },
        { text: "Archiviste de quoi ?",       next: 'archives_quoi' },
      ]
    },

    etait: {
      speaker: 'Elias',
      text: "Il n'y a plus grand-chose à archiver.\n\nCe qu'on voulait cacher… c'est tout ce qui reste.",
      choices: [
        { text: "Qu'est-ce qu'on voulait cacher ?", next: 'cacher' },
        { text: "Qui c'est « on » ?",               next: 'qui_on' },
      ]
    },

    cacher: {
      speaker: 'Elias',
      text: "*(Il ferme son livre. Te regarde pour la première fois vraiment.)*\n\nTu demandes ça comme si t'en avais pas déjà une idée.\n\nT'as quelqu'un dans ta famille qui a disparu ?",
      choices: [
        { text: "Oui.",     next: 'oui_famille',  effects: { flag: 'famille_disparue' } },
        { text: "Non.",     next: 'non_famille' },
        { text: "Pourquoi vous demandez ça ?", next: 'pourquoi_famille' },
      ]
    },

    oui_famille: {
      speaker: 'Elias',
      text: "*(Il hoche la tête lentement.)*\n\nIls ont pas disparu.\n\nIls ont été… utilisés.\n\nC'est pas pareil.",
      choices: [
        { text: "Utilisés comment ?", next: 'utilises' },
        { text: "...",               next: 'silence_elias' },
      ]
    },

    utilises: {
      speaker: 'Elias',
      text: "*(Il se lève. Marche vers la fenêtre.)*\n\nEst-ce que t'as déjà regardé la Pierre de Lueur… vraiment regardé ?\n\nPas juste vu. Regardé.",
      choices: [
        { text: "Je ne l'ai jamais vue.",                  next: 'jamais_vue' },
        { text: "Elle brillait. C'est tout.",              next: 'brille' },
        { text: "Elle était dans mon village.",            next: 'village_pierre', effects: { flag: 'village_pierre' } },
      ]
    },

    brille: {
      speaker: 'Elias',
      text: "Ouais.\n\nTu sais ce qui brille comme ça ?\n\nLe feu. Et la foi.\n\nLe feu consomme. Et la foi… aussi.\n\n*(Il se rassoit.)*\n\nRepose-moi ta question dans quelques heures.",
      choices: [
        { text: "Non. Parlez maintenant.",                 next: 'parler_maintenant' },
        { text: "D'accord.",                              next: null, close: true, effects: { flag: 'elias_confiance_1' } },
      ]
    },

    parler_maintenant: {
      speaker: 'Elias',
      text: "*(Un demi-sourire.)*\n\nD'accord. T'as du cran.\n\nÉcoute bien. Je répète pas.",
      choices: [
        { text: "Je vous écoute.", next: 'ecoute_vrai' },
      ]
    },

    ecoute_vrai: {
      speaker: 'Elias',
      text: "La Pierre de Lueur ne génère rien.\n\nElle prend.\n\nC'est tout ce que je te dis pour l'instant. Trouve les stèles dans la forêt. Tu comprendras le reste toi-même.",
      choices: [
        { text: "Où sont ces stèles ?",            next: 'steles_lieu' },
        { text: "Pourquoi pas tout me dire ?",     next: 'pourquoi_pas_tout' },
      ]
    },

    pourquoi_pas_tout: {
      speaker: 'Elias',
      text: "Parce que si je te dis tout… tu me croiras peut-être.\n\nMais si tu le découvres toi-même… tu pourras plus l'ignorer.\n\nC'est pas pareil.",
      choices: [
        { text: "Où sont les stèles ?",            next: 'steles_lieu' },
        { text: "J'aurai d'autres questions.",     next: null, close: true, effects: { flag: 'elias_confiance_2' } },
      ]
    },

    steles_lieu: {
      speaker: 'Elias',
      text: "Trois. Une au nord du premier marais. Une contre le vieux chêne fissuré. La troisième… cherche le bruit de l'eau là où il n'y a pas de rivière.\n\n*(Il se rassoit.)*\n\nEt lis-les dans l'ordre.",
      choices: [
        { text: "Pourquoi dans l'ordre ?",         next: 'ordre_steles' },
        { text: "D'accord.",                      next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    ordre_steles: {
      speaker: 'Elias',
      text: "Parce que la vérité… ça se digère.\n\nPas ça s'avale d'un coup.",
      choices: [
        { text: "Je les trouverai.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    foret_mystere: {
      speaker: 'Elias',
      text: "*(Il lève les yeux.)*\n\nT'as entendu les arbres ?",
      choices: [
        { text: "Oui.",        next: 'oui_arbres', effects: { flag: 'entendu_arbres' } },
        { text: "Non.",        next: 'non_arbres' },
        { text: "Peut-être.",  next: 'peutetre_arbres' },
      ]
    },

    oui_arbres: {
      speaker: 'Elias',
      text: "*(Il hoche la tête. Ça a l'air de le rassurer.)*\n\nBien.\n\nCeux qui entendent… peuvent comprendre.",
      choices: [
        { text: "Comprendre quoi ?",               next: 'comprendre_quoi' },
        { text: "Qu'est-ce qu'ils disent ?",       next: 'disent_quoi' },
      ]
    },

    comprendre_quoi: {
      speaker: 'Elias',
      text: "Ce qui a été fait ici.\n\nCe qui continue d'être fait.\n\n*(Il se lève, marche vers toi.)*\n\nT'as un nom ?",
      choices: [
        { text: "Je m'appelle [Héros].",           next: 'nom_heros', effects: { flag: 'elias_sait_nom' } },
        { text: "Ça vous regarde ?",               next: 'regarde_pas' },
      ]
    },

    nom_heros: {
      speaker: 'Elias',
      text: "*(Il répète ton prénom doucement, comme pour vérifier quelque chose.)*\n\nHm.\n\nTon nom est dans mes archives.\n\nC'est pas un hasard que t'es ici.",
      choices: [
        { text: "Quoi ?",                          next: 'nom_archives', effects: { flag: 'heros_dans_archives' } },
        { text: "C'est quoi vos archives ?",       next: 'archives_quoi' },
      ]
    },

    nom_archives: {
      speaker: 'Elias',
      text: "*(Il retourne à son bureau. Cherche un livre.)*\n\nPas maintenant. D'abord les stèles.\n\nEnsuite on parle.",
      choices: [
        { text: "Non — parlez maintenant.",        next: 'archives_maintenant' },
        { text: "D'accord. Les stèles.",           next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'nom_archives_bientot' } },
      ]
    },

    archives_maintenant: {
      speaker: 'Elias',
      text: "*(Il referme le livre.)*\n\nSi je te dis ce que je sais…\n\nT'auras pas l'envie d'aller dans cette forêt. T'auras l'envie de fuir.\n\nEt je peux pas me permettre que tu fuis.",
      choices: [
        { text: "Je ne fuirai pas.",               next: 'pas_fuir', effects: { morale: +3 } },
        { text: "D'accord. Les stèles d'abord.",  next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    pas_fuir: {
      speaker: 'Elias',
      text: "*(Il te regarde longuement. Hoche la tête.)*\n\nBien.\n\nAlors lis les stèles. Et reviens me voir avec ce que t'as compris.\n\nPas ce que t'as lu. Ce que t'as compris.",
      choices: [
        { text: "Je reviendrai.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_test_comprendre' } },
      ]
    },

    cherche: {
      speaker: 'Elias',
      text: "*(Il ne lève pas les yeux.)*\n\nTout le monde cherche quelque chose ici.\n\nSurtout leurs morts.",
      choices: [
        { text: "Leurs morts ?",                  next: 'leurs_morts' },
        { text: "Ce que je cherche est plus concret.", next: 'concret' },
      ]
    },

    leurs_morts: {
      speaker: 'Elias',
      text: "La forêt garde les derniers moments. Les dernières images. Les derniers mots.\n\nCeux qui sont passés par ici… ils ont laissé quelque chose.",
      choices: [
        { text: "Passés = morts ?",               next: 'passes_morts', effects: { flag: 'comprehension_foret_1' } },
        { text: "Qu'est-ce qu'ils ont laissé ?",  next: 'laisse_quoi' },
      ]
    },

    passes_morts: {
      speaker: 'Elias',
      text: "*(Il te regarde longuement.)*\n\nT'es rapide.\n\nOuais. Ici c'est un cimetière qui se souvient.",
      choices: [
        { text: "Se souvient de quoi ?",           next: 'souvient_quoi' },
        { text: "Qui sont les morts ?",            next: 'qui_sont_morts' },
      ]
    },

    souvient_quoi: {
      speaker: 'Elias',
      text: "De tout ce qu'on leur a pris.\n\n*(Il se lève.)*\n\nCherche les stèles. Tu verras.",
      choices: [
        { text: "Où ?",                           next: 'steles_lieu' },
        { text: "Ce qu'on leur a pris ?",         next: 'pris_quoi' },
      ]
    },

    pris_quoi: {
      speaker: 'Elias',
      text: "*(Un long silence. Il ferme les yeux.)*\n\nPas encore.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { flag: 'elias_pas_encore' } },
      ]
    },

    qui_sont_morts: {
      speaker: 'Elias',
      text: "Des gens ordinaires.\n\nDes gens qui vivaient. Qui aimaient. Qui dormaient.\n\nEt qui ont été… choisis.\n\n*(Il s'arrête.)*\n\nJ'ai pas dit sacrifiés. J'ai dit choisis.",
      choices: [
        { text: "Il y a une différence ?",        next: 'difference_choix', effects: { flag: 'comprehension_foret_2' } },
        { text: "Choisis par qui ?",              next: 'choisis_par_qui' },
      ]
    },

    difference_choix: {
      speaker: 'Elias',
      text: "*(Il sourit tristement.)*\n\nCette question… t'es la première personne qui la pose.\n\nReviens me voir après les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_confiance_3' } },
      ]
    },

    choisis_par_qui: {
      speaker: 'Elias',
      text: "*(Il referme son livre d'un coup sec.)*\n\nPas par moi.",
      choices: [
        { text: "Mais vous savez qui.",           next: 'sait_qui', effects: { flag: 'elias_sait' } },
        { text: "D'accord. Les stèles d'abord.", next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    sait_qui: {
      speaker: 'Elias',
      text: "*(Il te regarde droit dans les yeux.)*\n\nOuais. Je sais.\n\nEt c'est pour ça que je suis encore en vie — parce que je me tais.\n\n*(Il baisse la voix.)*\n\nCherche les stèles. Et reviens.",
      choices: [
        { text: "Je reviens.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'elias_confiance_max' } },
      ]
    },

    qui_on: {
      speaker: 'Elias',
      text: "*(Il sourit sans joie.)*\n\nLes Gardiens. Les Administrateurs. Les Conseillers du Roi.\n\nTous ceux qui savaient et qui se sont tus.",
      choices: [
        { text: "Vous en faisiez partie ?",        next: 'faisait_partie', effects: { flag: 'elias_garde_ancien' } },
        { text: "Le Roi Mordred ?",                next: 'mordred_roi', effects: { flag: 'mordred_implique_1' } },
      ]
    },

    faisait_partie: {
      speaker: 'Elias',
      text: "*(Un long silence.)*\n\nOuais.",
      choices: [
        { text: "Alors vous êtes coupable.",      next: 'coupable_elias', effects: { morale: -3 } },
        { text: "Et maintenant ?",               next: 'maintenant_elias' },
        { text: "...",                           next: 'silence_elias' },
      ]
    },

    coupable_elias: {
      speaker: 'Elias',
      text: "*(Il ne se défend pas.)*\n\nOuais.",
      choices: [
        { text: "Pourquoi vous parlez maintenant ?", next: 'pourquoi_parler' },
        { text: "...",                              next: 'silence_elias' },
      ]
    },

    pourquoi_parler: {
      speaker: 'Elias',
      text: "Parce qu'il reste plus grand monde à protéger en se taisant.\n\nEt parce que t'es là.\n\nCherche les stèles. Je serai là quand tu reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_repent' } },
      ]
    },

    maintenant_elias: {
      speaker: 'Elias',
      text: "Maintenant je garde ce que je peux. Les vérités qu'on voulait enterrer.\n\nToi tu peux les porter. Si t'es prêt.",
      choices: [
        { text: "Je suis prêt.",                  next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', morale: +3 } },
        { text: "Comment vous savez que je le suis ?", next: 'comment_pret' },
      ]
    },

    comment_pret: {
      speaker: 'Elias',
      text: "*(Il hausse les épaules.)*\n\nJe sais pas.\n\nMais t'as pas encore fui.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    mordred_roi: {
      speaker: 'Elias',
      text: "*(Il détourne les yeux.)*\n\nCherche les stèles d'abord.",
      choices: [
        { text: "Non. Répondez.",                 next: 'mordred_roi_suite' },
        { text: "D'accord.",                     next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    mordred_roi_suite: {
      speaker: 'Elias',
      text: "*(Il prend une inspiration.)*\n\nMordred croyait ce qu'il faisait.\n\nC'est le pire genre de coupable.",
      choices: [
        { text: "Il croyait quoi ?",              next: 'mordred_croyait', effects: { flag: 'mordred_conviction' } },
        { text: "Qu'est-ce qu'il a fait ?",       next: 'mordred_fait', effects: { flag: 'mordred_implique_2' } },
      ]
    },

    mordred_croyait: {
      speaker: 'Elias',
      text: "Que c'était nécessaire.\n\nQue sans sacrifice, il n'y aurait pas d'ordre.\n\nQue les gens… avaient besoin d'être protégés d'eux-mêmes.",
      choices: [
        { text: "Et il avait tort.",              next: 'mordred_tort', effects: { morale: +3, flag: 'jugement_mordred' } },
        { text: "Peut-être qu'il avait partiellement raison.", next: 'mordred_raison', effects: { morale: -3 } },
        { text: "...",                            next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    mordred_tort: {
      speaker: 'Elias',
      text: "*(Il hoche la tête.)*\n\nOuais.\n\nMais les gens qui ont tort avec conviction… c'est plus dangereux que ceux qui font le mal par intérêt.",
      choices: [
        { text: "Pourquoi ?",                     next: 'pourquoi_conviction' },
        { text: "Je comprends.",                 next: null, close: true, effects: { quest: 'quete_steles', flag: 'elias_sagesse_mordred' } },
      ]
    },

    pourquoi_conviction: {
      speaker: 'Elias',
      text: "Parce qu'ils arrêtent pas. Même face aux preuves. Même face aux morts.\n\nIls se disent que c'est un prix à payer.\n\nEt les prix… ça se paye toujours avec les autres.",
      choices: [
        { text: "Et Aldric dans tout ça ?",       next: 'aldric_mention', effects: { flag: 'aldric_mention_1' } },
        { text: "Je vais chercher les stèles.",   next: null, close: true, effects: { quest: 'quete_steles', flag: 'elias_confiance_mordred' } },
      ]
    },

    aldric_mention: {
      speaker: 'Elias',
      text: "*(Il s'arrête net.)*\n\nT'as entendu ce nom… où ?",
      choices: [
        { text: "Dans des documents.",            next: 'documents_aldric', effects: { flag: 'heros_cherche_aldric' } },
        { text: "Dans le village.",              next: 'village_aldric' },
        { text: "Je l'ai juste deviné.",         next: 'invente_aldric' },
      ]
    },

    documents_aldric: {
      speaker: 'Elias',
      text: "*(Il se lève brusquement.)*\n\nQuels documents. Où.\n\nC'est important.",
      choices: [
        { text: "Dans les ruines au nord.", next: null, close: true, effects: { flag: 'aldric_urgent', quest: 'quete_steles' } },
        { text: "Je ne sais plus.",        next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    village_aldric: {
      speaker: 'Elias',
      text: "*(Quelque chose change dans ses yeux.)*\n\nQui t'en a parlé ?",
      choices: [
        { text: "Un villageois.",          next: null, close: true, effects: { flag: 'aldric_village', quest: 'quete_steles' } },
        { text: "Je préfère pas dire.",   next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    invente_aldric: {
      speaker: 'Elias',
      text: "*(Il te regarde longuement.)*\n\nNon. T'as pas inventé.",
      choices: [
        { text: "Pourquoi vous dites ça ?", next: 'sait_aldric', effects: { flag: 'elias_sait_aldric' } },
      ]
    },

    sait_aldric: {
      speaker: 'Elias',
      text: "Parce que personne invente ce nom.\n\nOn l'entend, un jour. Et après, il reste.\n\nVa chercher les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'aldric_mystere' } },
      ]
    },

    mordred_fait: {
      speaker: 'Elias',
      text: "*(Il prend une longue inspiration.)*\n\nIl a ordonné.\n\nPas fait lui-même. Ordonné.\n\nC'est ça la différence entre un roi et un bourreau. Le roi… il signe. Et quelqu'un d'autre exécute.",
      choices: [
        { text: "Et quelqu'un a exécuté.",        next: 'executant', effects: { flag: 'aldric_executant' } },
        { text: "C'est aussi coupable.",          next: 'aussi_coupable', effects: { morale: +3 } },
      ]
    },

    executant: {
      speaker: 'Elias',
      text: "*(Il hoche la tête très lentement.)*\n\nOuais.\n\n*(Un silence.)*\n\nCherche les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'aldric_executant' } },
      ]
    },

    aussi_coupable: {
      speaker: 'Elias',
      text: "*(Il plisse les yeux.)*\n\nT'as raison.\n\nMais les tribunaux… ils ont pas toujours vu les choses comme ça.",
      choices: [
        { text: "Et toi, comment tu le vois ?",  next: 'elias_voit' },
        { text: "Je vais chercher les stèles.",  next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    elias_voit: {
      speaker: 'Elias',
      text: "*(Il ferme les yeux.)*\n\nJe suis pas en position de juger.\n\nJ'ai signé aussi.",
      choices: [
        { text: "...", next: null, close: true, effects: { quest: 'quete_steles', flag: 'elias_signe_aussi' } },
      ]
    },

    mordred_raison: {
      speaker: 'Elias',
      text: "*(Il te regarde froidement.)*\n\nT'as pas encore vu les stèles.\n\nReviens me dire ça après.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    archives_quoi: {
      speaker: 'Elias',
      text: "Des noms. Des dates. Des lieux.\n\nLa vérité bureaucratique des événements.\n\n*(Pause.)*\n\nLe problème avec la vérité bureaucratique… c'est qu'elle dit ce qui s'est passé. Jamais pourquoi.",
      choices: [
        { text: "Et vous, vous savez pourquoi ?",   next: 'sait_pourquoi' },
        { text: "Il y a un Journal du Sacrifice ?", next: 'journal_sacrifice', effects: { flag: 'journal_sacrifice_mention' } },
      ]
    },

    sait_pourquoi: {
      speaker: 'Elias',
      text: "En partie.\n\nC'est le problème des archives. On garde trop. On comprend pas assez.",
      choices: [
        { text: "Qu'est-ce que vous ne comprenez pas encore ?", next: 'comprend_pas' },
        { text: "Les stèles.",                                  next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    comprend_pas: {
      speaker: 'Elias',
      text: "Pourquoi ça continue.\n\nLe sacrifice s'est arrêté. La Pierre est brisée.\n\nMais quelque chose continue de prendre.",
      choices: [
        { text: "Quoi continue de prendre ?",     next: 'quoi_continue', effects: { flag: 'quelque_chose_continue' } },
        { text: "Je chercherai.",                next: null, close: true, effects: { quest: 'quete_steles', flag: 'chercher_ce_qui_continue' } },
      ]
    },

    quoi_continue: {
      speaker: 'Elias',
      text: "Je sais pas.\n\n*(Il se retourne vers ses livres.)*\n\nMais les arbres, eux… ils le savent peut-être.\n\nCherche les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    journal_sacrifice: {
      speaker: 'Elias',
      text: "*(Il se raidit légèrement.)*\n\nOù t'as entendu ce nom ?",
      choices: [
        { text: "Dans des rumeurs.",  next: 'rumeurs_journal', effects: { flag: 'journal_sacrifice_cherche' } },
        { text: "Je l'ai deviné.",   next: 'devine_journal' },
      ]
    },

    rumeurs_journal: {
      speaker: 'Elias',
      text: "*(Il se lève. Cherche dans ses tiroirs.)*\n\nIl existe. Mais il est pas ici.\n\nSi tu le trouves… apporte-le moi avant de le lire.",
      choices: [
        { text: "Pourquoi avant ?",    next: 'avant_lire', effects: { flag: 'journal_pas_lire_seul' } },
        { text: "D'accord.",          next: null, close: true, effects: { quest: 'quete_journal', flag: 'journal_sacrifice_cherche' } },
      ]
    },

    avant_lire: {
      speaker: 'Elias',
      text: "Parce que certaines choses… ça se lit pas seul.\n\nT'as besoin de contexte pour pas en tirer les mauvaises conclusions.",
      choices: [
        { text: "D'accord.",                          next: null, close: true, effects: { quest: 'quete_journal', flag: 'journal_pas_lire_seul' } },
        { text: "Je le lirai moi-même.",             next: 'lira_seul', effects: { morale: -3, flag: 'heros_independant' } },
      ]
    },

    lira_seul: {
      speaker: 'Elias',
      text: "*(Il hoche la tête lentement.)*\n\nD'accord.\n\nMais reviens après. Quoi que tu aies conclu.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_journal' } },
      ]
    },

    devine_journal: {
      speaker: 'Elias',
      text: "*(Il te regarde différemment.)*\n\nIntéressant.\n\nCherche les stèles d'abord. Et reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'heros_intuition' } },
      ]
    },

    non_famille: {
      speaker: 'Elias',
      text: "*(Il te regarde différemment.)*\n\nVraiment ?\n\nOu tu t'en souviens pas ?",
      choices: [
        { text: "Vraiment.",    next: 'vraiment_non' },
        { text: "...",         next: 'oui_famille', effects: { flag: 'famille_disparue_maybe' } },
      ]
    },

    vraiment_non: {
      speaker: 'Elias',
      text: "*(Il hoche la tête lentement.)*\n\nTu as de la chance.\n\nOu tu as été épargné.\n\nC'est pas la même chose.",
      choices: [
        { text: "Épargné de quoi ?", next: 'epargne_quoi' },
        { text: "D'accord.",        next: null, close: true },
      ]
    },

    epargne_quoi: {
      speaker: 'Elias',
      text: "*(Il se retourne.)*\n\nPas encore. Cherche les stèles d'abord.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    pourquoi_famille: {
      speaker: 'Elias',
      text: "Parce que ceux qui viennent ici… en général ils cherchent quelqu'un.\n\nQuelqu'un qui a disparu sans explication. Sans corps. Sans rien.",
      choices: [
        { text: "Non, rien de tel.",              next: 'non_famille' },
        { text: "Oui. Ma famille.",               next: 'oui_famille', effects: { flag: 'famille_disparue' } },
        { text: "C'est arrivé dans mon village.", next: 'oui_famille', effects: { flag: 'famille_disparue' } },
      ]
    },

    non_arbres: {
      speaker: 'Elias',
      text: "*(Il rebaisse les yeux.)*\n\nAttends.",
      choices: [
        { text: "J'attends quoi ?",  next: 'attendre' },
        { text: "D'accord.",        next: null, close: true },
      ]
    },

    peutetre_arbres: {
      speaker: 'Elias',
      text: "*(Il sourit légèrement.)*\n\nHonnête. J'aime ça.",
      choices: [
        { text: "Qu'est-ce que j'aurais pu entendre ?", next: 'disent_quoi' },
      ]
    },

    attendre: {
      speaker: 'Elias',
      text: "Que la forêt te remarque.\n\nSi elle t'entend pas… tu l'entendras pas.\n\nCertains passent toute leur vie sans l'entendre. T'as l'air d'être le genre à entendre.",
      choices: [
        { text: "Comment vous savez ?",    next: 'comment_sait_foret' },
        { text: "D'accord.",              next: null, close: true },
      ]
    },

    comment_sait_foret: {
      speaker: 'Elias',
      text: "*(Il sourit légèrement.)*\n\nT'es là. T'aurais pu t'arrêter au village.\n\nT'as continué.",
      choices: [
        { text: "Et alors ?",  next: 'et_alors_elias' },
      ]
    },

    et_alors_elias: {
      speaker: 'Elias',
      text: "Les gens qui s'arrêtent là-bas… ils savent pas. Ils sentent juste que c'est assez loin.\n\nToi t'as continué. Ça veut dire que t'as besoin de comprendre.\n\nEt ça… ça t'aidera ici.",
      choices: [
        { text: "Ou ça me tuera.",   next: 'ou_tuer', effects: { morale: -2 } },
        { text: "Je comprends.",    next: null, close: true, effects: { morale: +2 } },
      ]
    },

    ou_tuer: {
      speaker: 'Elias',
      text: "*(Un silence. Puis, doucement :)*\n\nOuais. Possible aussi.",
      choices: [
        { text: "Je risquerai.", next: null, close: true, effects: { morale: +3, flag: 'prend_risque' } },
      ]
    },

    disent_quoi: {
      speaker: 'Elias',
      text: "Rien de direct.\n\nIls répètent. Ce qu'ils ont entendu. Ce qu'ils ont vu.\n\nC'est pas pareil que parler. C'est plus comme… témoigner.",
      choices: [
        { text: "Témoigner de quoi ?",          next: 'temoigner_quoi' },
        { text: "Je veux chercher les stèles.", next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    temoigner_quoi: {
      speaker: 'Elias',
      text: "*(Il s'arrête. Choisit ses mots soigneusement.)*\n\nDe quelque chose qu'on aurait préféré oublier.\n\nEt qui refuse de l'être.",
      choices: [
        { text: "Qu'est-ce qu'on ne peut pas oublier ?", next: 'oublier_quoi', effects: { flag: 'comprehension_foret_3' } },
        { text: "Les stèles m'en diront plus.",          next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    oublier_quoi: {
      speaker: 'Elias',
      text: "Les noms.\n\nOn a oublié leurs noms. À dessein.\n\nEt maintenant la forêt les garde.",
      choices: [
        { text: "Les noms de qui ?",  next: 'noms_de_qui', effects: { flag: 'comprehension_sacrifice_partielle' } },
        { text: "...",               next: 'silence_apres_noms' },
      ]
    },

    noms_de_qui: {
      speaker: 'Elias',
      text: "*(Il te regarde. Longtemps. Puis :)*\n\nVas chercher les stèles.\n\nEt reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_confiance_4' } },
      ]
    },

    silence_apres_noms: {
      speaker: 'Elias',
      text: "*(Il hoche la tête. Ce silence-là, il le respecte.)*\n\nLes stèles. Commence par là.",
      choices: [
        { text: "Oui.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
      ]
    },

    concret: {
      speaker: 'Elias',
      text: "Le concret… c'est ce que la forêt mange en premier.\n\nCherche les stèles. T'as besoin de comprendre avant d'agir.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    laisse_quoi: {
      speaker: 'Elias',
      text: "Des mémoires. Des émotions. Des derniers instants.\n\nLes arbres les gardent. Et les rejouent.",
      choices: [
        { text: "Comme des fantômes.",  next: 'fantomes_elias' },
        { text: "Les stèles parlent de ça ?", next: 'steles_lieu' },
      ]
    },

    fantomes_elias: {
      speaker: 'Elias',
      text: "Pas des fantômes.\n\nDes témoignages.\n\nLa différence c'est que les fantômes appartiennent aux vivants.\n\nCes mémoires… elles appartiennent à ceux qui les ont laissées.",
      choices: [
        { text: "Je comprends.", next: null, close: true, effects: { quest: 'quete_steles', morale: +2 } },
      ]
    },

    jamais_vue: {
      speaker: 'Elias',
      text: "*(Il te regarde étrangement.)*\n\nVraiment.\n\nD'où tu viens ?",
      choices: [
        { text: "D'un village loin d'ici.",     next: 'village_loin' },
        { text: "Je préfère pas dire.",         next: 'prefere_pas' },
      ]
    },

    village_loin: {
      speaker: 'Elias',
      text: "*(Il cherche quelque chose dans ses livres.)*\n\nLoin comment ?",
      choices: [
        { text: "Très loin. Vous connaissez pas.",      next: 'tres_loin', effects: { flag: 'heros_origine_obscure' } },
        { text: "À l'est des Montagnes Brisées.",       next: 'est_montagnes', effects: { flag: 'heros_est' } },
      ]
    },

    tres_loin: {
      speaker: 'Elias',
      text: "*(Il referme son livre lentement.)*\n\nPeut-être.\n\nOu peut-être que j'ai juste pas le bon volume.",
      choices: [
        { text: "Qu'est-ce que ça veut dire ?",  next: 'bon_volume', effects: { flag: 'heros_archives_possible' } },
        { text: "Les stèles.",                  next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    bon_volume: {
      speaker: 'Elias',
      text: "Ça veut dire que j'archive pas tout.\n\nCertains noms… on me les a demandé de pas garder.\n\n*(Il te regarde.)*\n\nCherche les stèles. Et reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'heros_nom_cache_possible' } },
      ]
    },

    est_montagnes: {
      speaker: 'Elias',
      text: "*(Il marque une pause. Cherche dans ses livres.)*\n\nIl y avait des villages là-bas. Avant les Montagnes Brisées.\n\nBeaucoup ont été… évacués. Il y a longtemps.",
      choices: [
        { text: "Évacués ou autre chose ?",  next: 'evacues', effects: { flag: 'villages_est_disparus' } },
        { text: "Les stèles d'abord.",      next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    evacues: {
      speaker: 'Elias',
      text: "*(Il ne répond pas directement.)*\n\nCherche les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'villages_est_secret' } },
      ]
    },

    prefere_pas: {
      speaker: 'Elias',
      text: "*(Il hoche la tête.)*\n\nJuste.\n\nT'as besoin de savoir… ou de comprendre ?",
      choices: [
        { text: "Comprendre.",  next: 'comprendre_quoi', effects: { flag: 'heros_veut_comprendre' } },
        { text: "Les deux.",   next: 'les_deux', effects: { morale: +2 } },
      ]
    },

    les_deux: {
      speaker: 'Elias',
      text: "*(Il sourit pour la première fois vraiment.)*\n\nBonne réponse.\n\nLes stèles. Et reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_confiance_max' } },
      ]
    },

    village_pierre: {
      speaker: 'Elias',
      text: "*(Il se retourne brusquement.)*\n\nQuel village ?",
      choices: [
        { text: "Je préfère pas dire.",    next: 'village_pierre_secret', effects: { flag: 'village_pierre_heros' } },
        { text: "[Nom du village].",      next: 'village_pierre_nom', effects: { flag: 'village_pierre_heros' } },
      ]
    },

    village_pierre_secret: {
      speaker: 'Elias',
      text: "*(Il hoche la tête lentement.)*\n\nD'accord.\n\nMais note que certains villages avaient des Pierres subsidiaires. Plus petites. Plus… locales.\n\nEt les Pierres subsidiaires… elles prenaient aussi.",
      choices: [
        { text: "Elles prenaient quoi ?",    next: 'prenaient_quoi_village', effects: { flag: 'pierre_subsidiaire' } },
        { text: "Je comprends.",            next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    prenaient_quoi_village: {
      speaker: 'Elias',
      text: "Les mêmes choses.\n\nMoins. Mais les mêmes.\n\n*(Il se retourne.)*\n\nCherche les stèles.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'pierre_subsidiaire_prend' } },
      ]
    },

    village_pierre_nom: {
      speaker: 'Elias',
      text: "*(Il va droit dans ses livres.)*\n\n*(Long silence.)*\n\nD'accord.\n\n*(Il referme le livre.)*\n\nLes stèles. En priorité.",
      choices: [
        { text: "Vous avez trouvé quelque chose ?", next: 'trouve_quelque_chose', effects: { flag: 'heros_village_archives' } },
        { text: "D'accord.",                       next: null, close: true, effects: { quest: 'quete_steles', flag: 'heros_village_archives' } },
      ]
    },

    trouve_quelque_chose: {
      speaker: 'Elias',
      text: "*(Il te regarde.)*\n\nLes stèles d'abord.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles', flag: 'elias_sait_village_heros' } },
      ]
    },

    regarde_pas: {
      speaker: 'Elias',
      text: "*(Il sourit.)*\n\nSi. Parce que ton nom est peut-être dans mes livres.\n\nEt dans ce cas… t'as un problème.",
      choices: [
        { text: "Quel problème ?",                 next: 'quel_probleme' },
        { text: "Je m'appelle [Héros].",           next: 'nom_heros', effects: { flag: 'elias_sait_nom' } },
      ]
    },

    quel_probleme: {
      speaker: 'Elias',
      text: "*(Il retourne à son bureau.)*\n\nCherche les stèles. T'auras une idée.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles' } },
      ]
    },

    silence_elias: {
      speaker: '...',
      text: "*(Un silence s'installe entre vous.)*",
      choices: [
        { text: "Je vais chercher les stèles.", next: null, close: true, effects: { quest: 'quete_steles', item: 'conseil_steles' } },
        { text: "J'ai encore des questions.",  next: 'start' },
      ]
    },
  }
};
