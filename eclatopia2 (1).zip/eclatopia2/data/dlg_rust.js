// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/dlg_rust.js
// Rust — Forgeron des Montagnes
// Il sait beaucoup. Il parle peu. Il forge mieux.
// ═══════════════════════════════════════════════════════════

const DLG_RUST = {
  key: 'rust',
  name: 'Rust',
  title: 'Forgeron',
  color: '#e08040',
  portraitFn: 'portraitRust',
  x: -160, zone: 'montagne',

  nodes: {
    start: {
      speaker: 'Rust',
      text: "Tiens, un aventurier qui survit aux Montagnes. Ça mérite du respect.\n\nJ'ai ce qu'il te faut — armes, potions. Et si tu m'aides avec quelque chose… je te forge quelque chose de spécial.",
      choices: [
        { text: "Quel quelque chose ?",                          next: 'probleme' },
        { text: "Montre-moi ta boutique.",                      next: 'shop' },
        { text: "Parle-moi de l'Éclat du Remords.",             next: 'eclat_info' },
        { text: "Ton passé à l'Académie de Mordred ?",          next: 'academie' },
        { text: "Juste passer.",                               next: null, close: true },
      ]
    },

    probleme: {
      speaker: 'Rust',
      text: "Mon ami d'enfance, Dorel. On s'était candidatés ensemble à l'Académie. Mordred m'a choisi, pas lui.\n\nIl y a eu une explosion dans ma forge il y a dix ans. Les témoins ont vu Dorel partir juste avant.\n\nMais… je suis plus sûr.",
      choices: [
        { text: "Tu penses qu'il est innocent ?",               next: 'dorel_innocent' },
        { text: "Je lui parlerai si je le croise.",             next: 'merci_dorel', effects: { morale: +5 } },
        { text: "Où est-il ?",                                 next: 'dorel_lieu' },
        { text: "Ce n'est pas mon problème.",                  next: 'offensé', effects: { morale: -4 } },
      ]
    },

    dorel_innocent: {
      speaker: 'Rust',
      text: "*(Il hésite.)*\n\nDe plus en plus, oui. Un éclat instable dans les murs — c'est ce que dit le rapport.\n\nMais accepter ça… c'est accepter que j'ai passé dix ans à haïr quelqu'un pour rien.\n\nC'est difficile.",
      choices: [
        { text: "La vérité est difficile, mais nécessaire.",    next: 'merci_dorel', effects: { morale: +8 } },
        { text: "Tu n'as pas à pardonner tout de suite.",      next: 'merci_dorel', effects: { morale: +3 } },
      ]
    },

    dorel_lieu: {
      speaker: 'Rust',
      text: "Dans les cavernes du nord des Montagnes.\n\nÉvite le golem Gorath si tu veux y aller vite. Ou affronte-le — l'Éclat du Remords que je veux est dans cette zone.\n\nApporte-le ici, je te forge la Lame du Remords. Elle est efficace contre les créatures du Vide.",
      choices: [
        { text: "Marché conclu.",                              next: 'marche_conclu', effects: { quest: 'quete_rust' } },
        { text: "Et Dorel si je le trouve ?",                 next: 'dorel_message' },
      ]
    },

    dorel_message: {
      speaker: 'Rust',
      text: "*(Long silence.)*\n\nDis-lui que… j'ai relu le rapport.\n\nJuste ça. Il comprendra.",
      choices: [
        { text: "Je le lui dirai.",  next: 'marche_conclu', effects: { quest: 'quete_rust', flag: 'message_dorel' } },
      ]
    },

    merci_dorel: {
      speaker: 'Rust',
      text: "Merci. Prends ça pour la route.\n\nEt si tu ramènes l'Éclat du Remords de Gorath… je te forge quelque chose que même L'Éveillé craindra.",
      choices: [
        { text: "Je reviendrai.",                              next: null, close: true, effects: { item: 'potion_rust', quest: 'quete_rust' } },
        { text: "Parle-moi de ta boutique.",                  next: 'shop' },
      ]
    },

    offensé: {
      speaker: 'Rust',
      text: "*(Il hausse les épaules.)*\n\nPeut-être.\n\nMais si tu croises quelqu'un qui s'appelle Dorel dans les cavernes… dis-lui que Rust demande si tout va bien. C'est tout.",
      choices: [
        { text: "Je m'en souviendrai.",   next: null, close: true },
        { text: "D'accord, j'irai.",     next: 'merci_dorel', effects: { morale: +3 } },
      ]
    },

    shop: {
      speaker: 'Rust',
      text: "Voilà ce que j'ai. L'Épée Renforcée est mon chef-d'œuvre — Acier de Gardien. L'Armure de Grès résiste aux golems.\n\nLa Lame des Condamnés est spéciale. Elle coupe tout. Mais elle coûte plus que de l'or.",
      choices: [
        { text: "Épée Renforcée — 80 or (+8 ATK)",                      next: null, close: true, effects: { buy: { item: 'epee_renforcee', cost: 80 } } },
        { text: "Armure de Grès — 120 or (+10 DEF)",                    next: null, close: true, effects: { buy: { item: 'armure_gres', cost: 120 } } },
        { text: "Potion de Vigueur — 30 or (+50 PV)",                   next: null, close: true, effects: { buy: { item: 'potion_vigueur', cost: 30 } } },
        { text: "Larme de Statue — 60 or (Vide -15)",                   next: null, close: true, effects: { buy: { item: 'larme_statue', cost: 60 } } },
        { text: "Lame des Condamnés — 200 or (+20 ATK, monde gris)",    next: 'lame_avertissement' },
        { text: "Rien pour l'instant.",                                next: null, close: true },
      ]
    },

    lame_avertissement: {
      speaker: 'Rust',
      text: "*(Il pose la lame sur le comptoir.)*\n\nElle coupe plus qu'elle doit. Et elle prend quelque chose en échange.\n\nChaque coup la rend plus tranchante. Et toi… moins.\n\nT'es sûr ?",
      choices: [
        { text: "Oui. Je la prends.",                next: null, close: true, effects: { buy: { item: 'lame_condamnes', cost: 200 } } },
        { text: "Non. Je vais réfléchir.",           next: 'shop' },
      ]
    },

    eclat_info: {
      speaker: 'Rust',
      text: "L'Éclat du Remords est gardé par Gorath dans les Montagnes. Golem géant — lent mais dévastateur.\n\nSa faiblesse : les fissures sur son corps brillent orange. Attaque-les. Et reste en mouvement.",
      choices: [
        { text: "Merci pour les infos.",               next: 'marche_conclu', effects: { quest: 'quete_rust' } },
        { text: "Je veux aussi voir ta boutique.",     next: 'shop' },
      ]
    },

    marche_conclu: {
      speaker: 'Rust',
      text: "Ramène-moi l'Éclat et je forge la Lame. C'est la seule arme qui inflige des dégâts réels à L'Éveillé — forgée avec de la vraie culpabilité, pas juste de l'acier.\n\nBonne chasse.",
      choices: [
        { text: "Je reviendrai.", next: null, close: true, effects: { quest: 'quete_rust', flag: 'marche_rust' } },
      ]
    },

    academie: {
      speaker: 'Rust',
      text: "J'étais l'apprenti forgeron de Mordred. Il m'a appris à canaliser l'énergie des éclats dans le métal.\n\nQuand j'ai compris que la Pierre volait la vie des habitants… j'ai plié bagage.\n\nMordred avait raison sur la corruption. La façon dont il a agi… moins.",
      choices: [
        { text: "Il aurait dû consulter des alliés.",  next: 'academie_allie' },
        { text: "Regrettes-tu l'Académie ?",           next: 'regret_academie' },
        { text: "Et maintenant ?",                     next: 'shop' },
      ]
    },

    academie_allie: {
      speaker: 'Rust',
      text: "Exactement. J'aurais aidé s'il m'avait demandé. Au lieu de ça, il a tout brisé seul dans la nuit.\n\nRésultat : L'Éveillé libre, le monde en guerre, et moi coincé dans ces foutues montagnes.",
      choices: [
        { text: "Aide-moi maintenant. C'est encore possible.", next: 'marche_conclu', effects: { morale: +5 } },
      ]
    },

    regret_academie: {
      speaker: 'Rust',
      text: "Chaque jour. Mais regretter ne forge pas l'acier. Je préfère construire quelque chose d'utile avec ce que j'ai.",
      choices: [
        { text: "Sage approche.", next: 'shop', effects: { morale: +2 } },
      ]
    },
  }
};
