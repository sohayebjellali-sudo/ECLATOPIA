// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/items.js
// Base de données complète des objets
// ═══════════════════════════════════════════════════════════

const ITEMS = {

  // ── ARMES ─────────────────────────────────────────────────
  epee_renforcee: {
    id: 'epee_renforcee', name: "Épée Renforcée",
    sym: '⚔', type: 'weapon',
    desc: "Forgée avec de l'Acier de Gardien par Rust. Équilibrée, fiable.",
    atk: 8, def: 0,
    lore: "L'acier garde la forme de ce qu'il a traversé.",
  },
  lame_condamnes: {
    id: 'lame_condamnes', name: "Lame des Condamnés",
    sym: '🗡', type: 'weapon',
    desc: "+20 ATK. Chaque coup consume ton âme : -5 morale, monde gris.",
    atk: 20, def: 0, cursed: true,
    lore: "Elle coupe mieux que tout. Et elle te coupe aussi.",
  },
  lame_remords: {
    id: 'lame_remords', name: "Lame du Remords",
    sym: '⚔', type: 'weapon',
    desc: "+15 ATK. +40% dégâts vs L'Éveillé. Forgée avec l'Éclat du Remords.",
    atk: 15, def: 0, vsEveille: 1.4,
    lore: "Rust a mis dix ans de culpabilité dans ce métal.",
  },
  dagues_ombre: {
    id: 'dagues_ombre', name: "Dagues d'Ombre",
    sym: '🗡', type: 'weapon',
    desc: "+12 ATK. +20% vitesse d'attaque. Silencieuses.",
    atk: 12, def: 0, atkSpeedBonus: 0.2,
    lore: "Ce qu'on ne voit pas arrive toujours plus vite.",
  },
  baton_memoire: {
    id: 'baton_memoire', name: "Bâton de Mémoire",
    sym: '🪄', type: 'weapon',
    desc: "+6 ATK. Les ondes d'énergie de Théo portent +50% loin.",
    atk: 6, def: 0, rangeBonus: 1.5, forChar: 'theo',
    lore: "Fabriqué avec des fragments de stèles. Il résonne quand on s'en approche.",
  },

  // ── ARMURES ───────────────────────────────────────────────
  armure_gres: {
    id: 'armure_gres', name: "Armure de Grès",
    sym: '🛡', type: 'armor',
    desc: "+10 DEF. Résistante aux golems. Lourde mais fiable.",
    atk: 0, def: 10,
    lore: "Taillée dans la roche des Montagnes Brisées. Elle garde l'odeur de la lave.",
  },
  manteau_ombre: {
    id: 'manteau_ombre', name: "Manteau des Ombres",
    sym: '🧥', type: 'armor',
    desc: "+7 DEF. -15% dégâts des ennemis d'ombre. Pour Kael.",
    atk: 0, def: 7, shadowRes: 0.15, forChar: 'kael',
    lore: "La nuit ne mord pas les siens.",
  },
  cape_lumiere: {
    id: 'cape_lumiere', name: "Cape de Lumière",
    sym: '🌟', type: 'armor',
    desc: "+8 DEF. Soigne 3 PV/sec quand le bouclier est actif.",
    atk: 0, def: 8, shieldRegen: 3, forChar: 'aelara',
    lore: "La lumière protège ceux qui la portent honnêtement.",
  },
  tunique_voyageur: {
    id: 'tunique_voyageur', name: "Tunique du Voyageur",
    sym: '🧣', type: 'armor',
    desc: "+6 DEF. +1 portée d'interaction. Bonne pour explorer.",
    atk: 0, def: 6, interactRange: 1,
    lore: "Usée aux coudes. Elle a vu beaucoup de routes.",
  },

  // ── CONSOMMABLES ──────────────────────────────────────────
  potion_vigueur: {
    id: 'potion_vigueur', name: "Potion de Vigueur",
    sym: '🧪', type: 'consumable',
    desc: "+50 PV instantané.",
    hp: 50,
    lore: "Rust la prépare avec des herbes des Montagnes. Goût de soufre.",
  },
  potion_rust: {
    id: 'potion_rust', name: "Potion de Rust",
    sym: '🧪', type: 'consumable',
    desc: "+50 PV. Cadeau de Rust.",
    hp: 50,
    lore: "Il l'a préparée en pensant à Dorel.",
  },
  parchemin_soin: {
    id: 'parchemin_soin', name: "Parchemin de Soin",
    sym: '📋', type: 'consumable',
    desc: "+60 PV. Vendu par Luma.",
    hp: 60,
    lore: "Écrit par une guérisseuse de la Cité, avant l'engloutissement.",
  },
  elixir_grand: {
    id: 'elixir_grand', name: "Élixir de Résurrection",
    sym: '⚗', type: 'consumable',
    desc: "+100 PV. Ressuscite si PV tombent à 0 une fois.",
    hp: 100, revive: true,
    lore: "Il ne ramène pas les morts. Il empêche les vivants de mourir.",
  },
  larme_statue: {
    id: 'larme_statue', name: "Larme de Statue",
    sym: '💧', type: 'consumable',
    desc: "Vide -15. Les statues pleurent encore.",
    vide: -15,
    lore: "Collectée au pied d'une des stèles de la Forêt. Elle est froide.",
  },
  rune_purif: {
    id: 'rune_purif', name: "Rune de Purification",
    sym: '✨', type: 'consumable',
    desc: "Vide -20. Vendue par Luma.",
    vide: -20,
    lore: "Gravée à rebours sur l'éclat. Ça fait du bruit quand on la casse.",
  },
  elixir_vide: {
    id: 'elixir_vide', name: "Élixir du Vide",
    sym: '⚗', type: 'consumable',
    desc: "Vide -30. Rare. Très amer.",
    vide: -30,
    lore: "Théo a mis six mois à le formuler. Il dit que ça marche en théorie.",
  },
  codex_anciens: {
    id: 'codex_anciens', name: "Codex des Anciens",
    sym: '📖', type: 'consumable',
    desc: "+200 XP. Connaissances condensées.",
    xp: 200,
    lore: "Ce que des siècles de savants ont mis en pages. À dévorer.",
  },

  // ── CLÉS / QUÊTE ──────────────────────────────────────────
  parchemin_elias: {
    id: 'parchemin_elias', name: "Parchemin des Origines",
    sym: '📜', type: 'key',
    desc: "Guide vers les stèles de la Forêt. Donné par Elias.",
    lore: "L'écriture est serrée. Elias a relu avant de donner.",
  },
  conseil_steles: {
    id: 'conseil_steles', name: "Conseil des Stèles",
    sym: '🪨', type: 'key',
    desc: "Tu sais où chercher les trois stèles.",
    lore: "Les stèles sont dans l'ordre. L'ordre importe.",
  },
  conseil_prenom: {
    id: 'conseil_prenom', name: "Le Prénom",
    sym: '🔤', type: 'key',
    desc: "Rappelle-toi ton prénom dans la Forêt. Toujours.",
    lore: "C'est la première chose qui t'appartient vraiment.",
  },
  carnet_aldric: {
    id: 'carnet_aldric', name: "Carnet d'Aldric",
    sym: '📓', type: 'key',
    desc: "Liste des victimes du Rituel. Tenu en secret par Aldric.",
    lore: "Les noms sont écrits petit, serrés. Comme s'il avait peur d'en manquer.",
    unlocks: ['vaelt_noms', 'fin_vraie_possible'],
  },
  codex_liberation: {
    id: 'codex_liberation', name: "Codex des Libérations",
    sym: '📗', type: 'key',
    desc: "Procédure pour libérer les âmes de chaque éclat. Donné par Luma.",
    lore: "Il n'y a pas de formule magique. Juste du temps et du respect.",
    unlocks: ['vraie_fin_methode'],
  },
  memoire_mordred: {
    id: 'memoire_mordred', name: "Mémoire de Mordred",
    sym: '💭', type: 'key',
    desc: "Fragment de conscience de Mordred. Clé de la Vraie Fin.",
    lore: "Ça pèse rien dans la main. Ça pèse tout dans la tête.",
    unlocks: ['vraie_fin_accessible'],
  },
  sagesse_mordred: {
    id: 'sagesse_mordred', name: "Paroles de Mordred",
    sym: '💬', type: 'key',
    desc: "Ce qu'il t'a enseigné. Morale +5 permanent.",
    moraleBonus: 5,
    lore: "La conviction sans questionnement est une forme de violence.",
  },
  parole_vaeltharion: {
    id: 'parole_vaeltharion', name: "Parole de Vaeltharion",
    sym: '🌀', type: 'key',
    desc: "Il t'a reconnu comme témoin. Ouvre le dialogue vrai.",
    lore: "Les témoins ne concluent pas. Ils rapportent.",
    unlocks: ['vaelt_combat_evitable'],
  },
  notes_pere_theo: {
    id: 'notes_pere_theo', name: "Notes du père de Théo",
    sym: '📐', type: 'key',
    desc: "Calculs d'ingénierie sur la Pierre. Incomplets mais révélateurs.",
    lore: "Techniquement réalisable. Il a utilisé ces mots.",
    unlocks: ['alternative_energie_piste'],
  },
  eclat_gorath: {
    id: 'eclat_gorath', name: "Éclat du Remords",
    sym: '💎', type: 'key',
    desc: "Fragment de la Pierre, gardé par Gorath. Permet la Lame du Remords.",
    lore: "Il vibre légèrement. Ou c'est toi.",
    unlocks: ['lame_remords_forgeable'],
  },
  eclat_nyxara: {
    id: 'eclat_nyxara', name: "Éclat des Profondeurs",
    sym: '💎', type: 'key',
    desc: "Fragment de la Pierre, gardé par Nyxara.",
    lore: "L'eau en reste sur les doigts.",
    unlocks: ['eclat_count'],
  },
  journal_archiviste: {
    id: 'journal_archiviste', name: "Journal du Dernier Archiviste",
    sym: '📔', type: 'key',
    desc: "Journal personnel trouvé dans la Cité Engloutie. Pour Luma.",
    lore: "L'écriture s'arrête au milieu d'une phrase.",
    unlocks: ['luma_parents_reponse'],
  },
  chanson_archiviste: {
    id: 'chanson_archiviste', name: "Mélodie des Archivistes",
    sym: '🎵', type: 'key',
    desc: "Chanson ancienne. Peut atteindre Nyxara avant qu'elle attaque.",
    lore: "Luma l'a transcrite de mémoire. Sa voix tremblait.",
    unlocks: ['nyxara_combat_evitable'],
  },
  lettre_victime: {
    id: 'lettre_victime', name: "Lettre d'une victime",
    sym: '✉', type: 'key',
    desc: "Jamais envoyée. Jamais reçue. Contient un prénom.",
    lore: "Elle commence par « Je rentrerai. »",
    unlocks: ['vaelt_noms_lettre'],
  },
  fragment_dorel: {
    id: 'fragment_dorel', name: "Fragment de Dorel",
    sym: '🔮', type: 'key',
    desc: "L'éclat que Dorel garde sous son lit. Il ne rêve plus.",
    lore: "Chaud au toucher. Comme si quelque chose respirait dedans.",
    unlocks: ['vieux_gardien_reponse'],
  },
  preuves_temple: {
    id: 'preuves_temple', name: "Preuves du Temple",
    sym: '📄', type: 'key',
    desc: "Documents officiels des Gardiens. Noms. Dates. Ordres signés.",
    lore: "La signature de Mordred est en bas. Et celle d'Aldric à côté.",
    unlocks: ['aldric_temoignage_pret', 'mordred_accuse_officiel'],
  },
};

// Lookup rapide
function getItem(id) { return ITEMS[id] || null; }
