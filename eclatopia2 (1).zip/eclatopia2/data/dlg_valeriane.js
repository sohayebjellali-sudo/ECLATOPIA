// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/dlg_valeriane.js
// ═══════════════════════════════════════════════════════════
const DLG_VALERIANE = {
  key: 'valeriane', name: 'Valériane', title: 'Guérisseuse',
  color: '#80c890', portraitFn: 'portraitValeriane',
  x: 300, zone: 'foret',
  nodes: {
    start: {
      speaker: 'Valériane',
      text: "*(Elle soigne quelqu'un. Lève les yeux brièvement.)*\n\nAttends. J'ai presque fini.",
      choices: [
        { text: "Prends ton temps.",                 next: 'attend', effects: { morale: +2 } },
        { text: "J'ai besoin d'aide maintenant.",   next: 'aide_urgente' },
        { text: "Qui tu soignes ?",                 next: 'qui_soigne' },
      ]
    },
    attend: {
      speaker: 'Valériane',
      text: "*(Elle finit. Se retourne.)*\n\nVoilà. Qu'est-ce que tu veux savoir ?\n\nT'es venu de loin pour vouloir autant savoir.",
      choices: [
        { text: "Comment tu sais ?",                  next: 'comment_sait' },
        { text: "Elias m'envoie.",                   next: 'elias_envoie', effects: { flag: 'valeriane_elias_lien' } },
        { text: "Je cherche des réponses sur cette forêt.", next: 'foret_valeriane' },
        { text: "Tu sais des choses sur les sacrifices ?",  next: 'sacrifices_valeriane', effects: { flag: 'valeriane_pierre_sujet' } },
      ]
    },
    comment_sait: {
      speaker: 'Valériane',
      text: "Les gens qui viennent juste passer… ils posent pas de questions.\n\nToi t'as les yeux de quelqu'un qui a déjà commencé à comprendre quelque chose.\n\nC'est plus dangereux que de pas comprendre du tout.",
      choices: [
        { text: "Dangereux comment ?",               next: 'dangereux_comprendre' },
        { text: "Je cherche la vérité sur la Pierre.", next: 'sacrifices_valeriane' },
      ]
    },
    dangereux_comprendre: {
      speaker: 'Valériane',
      text: "Parce que quand tu sais à moitié… tu peux construire n'importe quelle conclusion.\n\nEt la conclusion que t'as envie de construire… c'est rarement la bonne.",
      choices: [
        { text: "Alors aide-moi à tout savoir.",     next: 'tout_savoir', effects: { morale: +2 } },
        { text: "Je suis prudent.",                 next: 'prudent' },
      ]
    },
    tout_savoir: {
      speaker: 'Valériane',
      text: "D'accord. Mais je commence par une question.\n\nEst-ce que quelqu'un dans ta famille a disparu… sans explication ?",
      choices: [
        { text: "Oui.",    next: 'oui_disparition', effects: { flag: 'famille_disparue' } },
        { text: "Non.",   next: 'non_disparition' },
        { text: "Je ne sais pas.",  next: 'sais_pas_disparition', effects: { flag: 'heros_memoire_flou' } },
      ]
    },
    oui_disparition: {
      speaker: 'Valériane',
      text: "*(Elle pose ses affaires.)*\n\nIls ont pas disparu.\n\nIls ont été pris.\n\n*(Pause.)*\n\nTu veux savoir comment. Cherche les stèles d'abord. Reviens. On parle.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'valeriane_apres_steles', morale: +3 } },
        { text: "Non. Dis-le maintenant.", next: 'sacrifices_valeriane' },
      ]
    },
    non_disparition: {
      speaker: 'Valériane',
      text: "Possible. Ou c'est que les disparitions étaient avant toi. Avant ta naissance.\n\nCherche les stèles. Reviens.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'valeriane_heros_avant_naissance' } },
      ]
    },
    sais_pas_disparition: {
      speaker: 'Valériane',
      text: "Normal. On sait rarement ce qu'on a perdu avant de chercher.\n\nCherche les stèles. T'auras peut-être une partie de la réponse.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'valeriane_guide_heros' } },
      ]
    },
    foret_valeriane: {
      speaker: 'Valériane',
      text: "La forêt garde ce que les hommes ont voulu oublier.\n\nPas des fantômes. Des témoignages.\n\nLa différence c'est que les fantômes appartiennent aux vivants. Ces mémoires appartiennent à ceux qui les ont laissées.",
      choices: [
        { text: "Les arbres répètent les derniers mots ?",  next: 'derniers_mots_valer' },
        { text: "Qui les a laissées ?",                     next: 'qui_a_laisse', effects: { flag: 'comprehension_sacrifice_2' } },
      ]
    },
    derniers_mots_valer: {
      speaker: 'Valériane',
      text: "Ouais. Et les derniers mots… c'est rarement les vrais.\n\nQuand on souffre, on dit souvent ce qu'on pense que l'autre veut entendre.",
      choices: [
        { text: "Et les vrais mots, ils étaient quoi ?",   next: 'vrais_mots_valer' },
        { text: "Comment trouver la vérité alors ?",       next: 'trouver_verite_valer' },
      ]
    },
    vrais_mots_valer: {
      speaker: 'Valériane',
      text: "Je sais pas. Mais j'ai vu les visages.\n\nCertains étaient résignés.\nCertains avaient encore de l'espoir jusqu'au bout.\nCertains avaient juste peur.\n\n*(Elle baisse les yeux.)*\n\nEt certains n'avaient pas compris ce qui se passait.",
      choices: [
        { text: "Tu étais là.",                            next: 'toi_etais_valer', effects: { flag: 'valeriane_temoin' } },
        { text: "...",                                    next: null, close: true, effects: { morale: +2 } },
      ]
    },
    toi_etais_valer: {
      speaker: 'Valériane',
      text: "*(Elle te regarde longuement.)*\n\nJe soigne les survivants.\n\n*(Pause.)*\n\nT'as compris ce que ça veut dire ?",
      choices: [
        { text: "Que tu étais là.",                       next: 'etait_la_valer', effects: { flag: 'valeriane_temoin_confirme' } },
        { text: "Que tu guéris des gens.",               next: 'attendu_mieux' },
      ]
    },
    etait_la_valer: {
      speaker: 'Valériane',
      text: "*(Elle ne nie pas.)*\n\nJ'aurais pu partir. J'aurais dû partir.\n\nJ'ai pas pu.",
      choices: [
        { text: "Pourquoi ?",                             next: 'pourquoi_reste_valer', effects: { flag: 'valeriane_raison_reste' } },
        { text: "...",                                   next: null, close: true, effects: { flag: 'valeriane_mystere' } },
      ]
    },
    pourquoi_reste_valer: {
      speaker: 'Valériane',
      text: "Parce que quelqu'un devait rester pour soigner ce qu'on avait abîmé.\n\nPas de héros. Juste quelqu'un avec des bandages.",
      choices: [
        { text: "Tu te sens coupable ?",                 next: 'culpabilite_valer', effects: { flag: 'valeriane_culpabilite' } },
        { text: "C'est important ce que tu fais.",       next: null, close: true, effects: { morale: +5, flag: 'valeriane_alliee' } },
      ]
    },
    culpabilite_valer: {
      speaker: 'Valériane',
      text: "*(Un long silence.)*\n\nJ'aurais pu parler. Il y a longtemps.\n\nJ'ai pas parlé.",
      choices: [
        { text: "Pourquoi pas ?",                        next: 'pourquoi_pas_parle_valer' },
        { text: "Il n'est pas trop tard.",               next: null, close: true, effects: { morale: +3, flag: 'valeriane_alliee' } },
      ]
    },
    pourquoi_pas_parle_valer: {
      speaker: 'Valériane',
      text: "Parce que j'avais peur.\n\nEt parce qu'une partie de moi voulait croire que c'était pour le bien.\n\n*(Elle baisse les yeux.)*\n\nLa lumière était belle. On voulait y croire.",
      choices: [
        { text: "La lumière de la Pierre ?",             next: 'lumiere_pierre_valer', effects: { flag: 'lumiere_fausse_2' } },
        { text: "...",                                  next: null, close: true, effects: { flag: 'valeriane_honte' } },
      ]
    },
    lumiere_pierre_valer: {
      speaker: 'Valériane',
      text: "Ouais.\n\nElle était belle. Et propre. Et certaine.\n\nLe problème avec les choses belles et certaines… c'est qu'on pose pas les bonnes questions.",
      choices: [
        { text: "Quelles questions ?",                  next: 'quelles_questions_valer' },
        { text: "Je comprends.",                       next: null, close: true, effects: { flag: 'valeriane_confiance', morale: +3 } },
      ]
    },
    quelles_questions_valer: {
      speaker: 'Valériane',
      text: "D'où vient cette lumière.\n\nCe qu'elle coûte.\n\nÀ qui.",
      choices: [
        { text: "Et les réponses ?",                   next: null, close: true, effects: { flag: 'valeriane_enigme_ouverte', quest: 'quete_valeriane' } },
      ]
    },
    sacrifices_valeriane: {
      speaker: 'Valériane',
      text: "*(Elle pose ses affaires. Te regarde.)*\n\nLa Pierre prenait des années de vie. Imperceptiblement. Chacun donnait sans savoir.\n\nMais c'était pas assez. Alors on a demandé des… contributions. Plus grandes.",
      choices: [
        { text: "Qui a demandé ça ?",                  next: 'qui_demande_valer', effects: { flag: 'mordred_implique_3' } },
        { text: "Et les gens ont accepté ?",           next: 'ont_accepte_valer' },
      ]
    },
    qui_demande_valer: {
      speaker: 'Valériane',
      text: "Le Conseil. Le Roi. Les Gardiens.\n\nMordred supervisait. Aldric exécutait.\n\n*(Elle s'arrête.)*\n\nC'est tout ce que je dis pour l'instant.",
      choices: [
        { text: "D'accord.",                          next: null, close: true, effects: { flag: 'mordred_aldric_impliques', morale: +2 } },
      ]
    },
    ont_accepte_valer: {
      speaker: 'Valériane',
      text: "Certains ont cru que c'était pour le bien de tous.\n\nD'autres… n'avaient pas vraiment le choix.\n\nEt certains ont dit non.\n\n*(Pause.)*\n\nCeux qui ont dit non… on n'en parle plus.",
      choices: [
        { text: "Vaeltharion ?",                      next: 'vaelt_non_valer', effects: { flag: 'vaeltharion_a_dit_non' } },
        { text: "Qu'est-ce qu'on leur a fait ?",      next: 'fait_aux_non_valer' },
      ]
    },
    vaelt_non_valer: {
      speaker: 'Valériane',
      text: "*(Elle se fige.)*\n\nT'as mis les pièces ensemble ?",
      choices: [
        { text: "Oui.",                              next: null, close: true, effects: { flag: 'vaeltharion_heros_sait', morale: +5 } },
      ]
    },
    fait_aux_non_valer: {
      speaker: 'Valériane',
      text: "*(Elle se retourne.)*\n\nCherche les stèles.\n\nIls y sont mentionnés.",
      choices: [
        { text: "D'accord.", next: null, close: true, effects: { quest: 'quete_steles', flag: 'steles_non_mentionnes' } },
      ]
    },
    qui_soigne: {
      speaker: 'Valériane',
      text: "*(Sans lever les yeux.)*\n\nQuelqu'un qui a survécu à quelque chose qu'il aurait pas dû survivre.",
      choices: [
        { text: "Et toi, tu as survécu à quoi ?",    next: 'survie_valer', effects: { flag: 'valeriane_survivante_possible' } },
        { text: "...",                              next: 'attend' },
      ]
    },
    survie_valer: {
      speaker: 'Valériane',
      text: "*(Elle lève les yeux.)*\n\nÀ moi-même.\n\n*(Pause.)*\n\nC'est le plus difficile.",
      choices: [
        { text: "Je comprends.", next: null, close: true, effects: { morale: +3, flag: 'valeriane_intime' } },
        { text: "...",          next: 'attend' },
      ]
    },
    aide_urgente: {
      speaker: 'Valériane',
      text: "*(Elle lève les yeux.)*\n\nBlessure ? Maladie ?",
      choices: [
        { text: "Non. Des réponses.",     next: 'attend' },
        { text: "Oui, je suis blessé.",  next: 'soin_urgence', effects: { heal: 30 } },
      ]
    },
    soin_urgence: {
      speaker: 'Valériane',
      text: "*(Elle s'approche. T'examine.)*\n\nC'est pas grave. Tiens.\n\n*(Elle te donne quelque chose.)*\n\nRepose-toi un peu.",
      choices: [
        { text: "Merci.",   next: null, close: true, effects: { morale: +2 } },
        { text: "Je peux pas me reposer. Il y a des choses à comprendre.", next: 'attend', effects: { flag: 'valeriane_intrigue' } },
      ]
    },
    attendu_mieux: {
      speaker: 'Valériane',
      text: "*(Un demi-sourire.)*\n\nOuais. Aussi.\n\nMais surtout j'étais là. Et j'ai vu.",
      choices: [
        { text: "Qu'est-ce que tu as vu ?",  next: 'vrais_mots_valer' },
      ]
    },
    trouver_verite_valer: {
      speaker: 'Valériane',
      text: "Les actions. Pas les mots.\n\nCe que les gens ont fait, avant les derniers mots.",
      choices: [
        { text: "D'accord. Merci.", next: null, close: true, effects: { flag: 'valeriane_conseil_verite', morale: +3 } },
      ]
    },
    qui_a_laisse: {
      speaker: 'Valériane',
      text: "Des gens ordinaires.\n\nQui avaient des vies. Qui avaient des prénoms.\n\nOn leur a pris les deux.",
      choices: [
        { text: "On leur a pris les prénoms ?", next: 'pris_prenoms', effects: { flag: 'comprehension_oubli_noms' } },
      ]
    },
    pris_prenoms: {
      speaker: 'Valériane',
      text: "On a effacé leurs traces. Leurs noms. Leurs histoires.\n\nComme si ne pas les nommer les rendait moins réels.",
      choices: [
        { text: "Je les nommerai.",  next: null, close: true, effects: { morale: +5, flag: 'heros_promesse_memoire', quest: 'quete_vaelt_noms' } },
        { text: "...",              next: null, close: true, effects: { morale: +2 } },
      ]
    },
    elias_envoie: {
      speaker: 'Valériane',
      text: "*(Elle hausse un sourcil.)*\n\nElias t'a envoyé vers moi ?\n\nC'est nouveau. Il te fait confiance, alors.",
      choices: [
        { text: "Vous vous connaissez ?",           next: 'se_connaissent_valer' },
        { text: "Il n'a pas dit grand-chose.",     next: 'pas_grand_chose_valer' },
      ]
    },
    se_connaissent_valer: {
      speaker: 'Valériane',
      text: "On se connaît. On est pas d'accord sur grand-chose.\n\nMais on est d'accord sur l'essentiel : quelqu'un devait rester.",
      choices: [
        { text: "C'est quoi l'essentiel ?",        next: 'essentiel_valer' },
        { text: "D'accord.",                      next: 'attend' },
      ]
    },
    essentiel_valer: {
      speaker: 'Valériane',
      text: "Que si personne reste pour soigner, pour témoigner, pour garder…\n\nAlors c'est comme si ça n'avait pas eu lieu.\n\nEt ça, c'est inacceptable.",
      choices: [
        { text: "Et maintenant je suis là.",       next: null, close: true, effects: { flag: 'valeriane_lien_fort', morale: +3 } },
      ]
    },
    pas_grand_chose_valer: {
      speaker: 'Valériane',
      text: "*(Elle rit doucement.)*\n\nÇa lui ressemble.\n\nAssieds-toi. Je vais te parler de ce qu'il a pas dit.",
      choices: [
        { text: "D'accord.", next: 'tout_savoir' },
      ]
    },
    prudent: {
      speaker: 'Valériane',
      text: "La prudence c'est bien.\n\nLa prudence excessive… ça t'empêche de décider quand il faut.",
      choices: [
        { text: "Je sais quand décider.",         next: null, close: true, effects: { morale: +2 } },
        { text: "Comment trouver le juste milieu ?", next: null, close: true, effects: { morale: +2, flag: 'valeriane_sagesse_prudence' } },
      ]
    },
  }
};
