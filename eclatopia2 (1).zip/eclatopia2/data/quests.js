// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/quests.js
// Toutes les quêtes — principales et secondaires
// ═══════════════════════════════════════════════════════════

const QUESTS = {

  // ══════════════════════════════════════════════════════
  // QUÊTE PRINCIPALE
  // ══════════════════════════════════════════════════════

  main_quest: {
    id: 'main_quest',
    name: "Le Prix du Vide",
    type: 'main',
    zone: 'all',
    giver: 'elias',
    desc: "Quelque chose ne va pas dans cette forêt. Et Elias sait plus qu'il ne dit.",
    objectives: [
      { id: 'steles_lues',    text: "Lire les trois stèles de la Forêt (0/3)",        done: false },
      { id: 'vaelt_vaincu',   text: "Vaincre ou convaincre Vaeltharion",              done: false },
      { id: 'gorath_vaincu',  text: "Franchir les Montagnes Brisées",                done: false },
      { id: 'nyxara_vaincue', text: "Descendre dans la Cité Engloutie",              done: false },
      { id: 'eveille_final',  text: "Affronter L'Éveillé dans l'Abysse d'Ébène",    done: false },
    ],
    // Twists révélés progressivement dans cette quête :
    // 1. La lumière vient des sacrifices
    // 2. Vaeltharion est une victime
    // 3. Théo est lié indirectement
    // 4. Aldric a exécuté les ordres
    // 5. Le héros descend des sacrificateurs
  },

  // ══════════════════════════════════════════════════════
  // ACTE 1 — FORÊT DES MURMURES
  // ══════════════════════════════════════════════════════

  quete_steles: {
    id: 'quete_steles',
    name: "Ce que les pierres gardent",
    type: 'secondary',
    zone: 'foret',
    giver: 'elias',
    desc: "Elias t'a dit de chercher trois stèles dans la forêt. Il a dit de les lire dans l'ordre. Il n'a pas dit pourquoi.",
    hint: "Les stèles ne sont pas faciles à trouver. Certains disent que c'est voulu.",
    objectives: [
      { id: 'stele_1', text: "Trouver la première stèle (au nord du marais)",        done: false },
      { id: 'stele_2', text: "Trouver la deuxième stèle (près du chêne fissuré)",   done: false },
      { id: 'stele_3', text: "Trouver la troisième stèle (là où l'eau est absente)", done: false },
      { id: 'elias_retour', text: "Revenir voir Elias avec ce que tu as compris",   done: false },
    ],
    // Textes des stèles (cryptiques, pas de révélation directe)
    stele_texts: [
      "Ils sont venus à l'aube.\nIls portaient leurs prénoms.\nIls n'ont pas protesté — on leur avait dit que c'était pour le bien de tous.\n\nLeurs prénoms sont dans la pierre.\nLa pierre garde ce que les hommes effacent.",
      "La lumière qui éclaire le royaume\nnait dans l'obscurité d'un choix.\nCeux qui font la lumière\nne la voient jamais.",
      "Vaeltharion a dit non.\nC'est pour ça qu'il est encore là.\nCeux qui disent non restent.\nCeux qui obéissent disparaissent.",
    ],
    reward: { item: 'parchemin_elias', morale: +5, flag: 'steles_lues' },
  },

  quete_valeriane: {
    id: 'quete_valeriane',
    name: "Les blessures qu'on voit pas",
    type: 'secondary',
    zone: 'foret',
    giver: 'valeriane',
    desc: "Valériane soigne les survivants. Elle sait des choses. Elle attend que tu poses les bonnes questions.",
    hint: "Elle ne dit pas tout d'un coup. Reviens plusieurs fois.",
    objectives: [
      { id: 'valeriane_1', text: "Parler à Valériane une première fois",    done: false },
      { id: 'steles_avant', text: "Lire les stèles avant de revenir",      done: false },
      { id: 'valeriane_2', text: "Revenir voir Valériane après les stèles", done: false },
      { id: 'lettres',     text: "Trouver des lettres dans les ruines (optionnel)", done: false },
    ],
    reward: { flag: 'valeriane_alliee', morale: +8 },
  },

  quete_theo: {
    id: 'quete_theo',
    name: "L'héritage du père",
    type: 'secondary',
    zone: 'foret',
    giver: 'theo',
    desc: "Théo a les notes de son père — ingénieur en chef de la Pierre. Il n'ose pas les finir seul.",
    hint: "Les notes sont quelque part dans la Forêt ou les Montagnes. Il faut chercher.",
    objectives: [
      { id: 'theo_parler',  text: "Parler à Théo",                                  done: false },
      { id: 'notes_trouver', text: "Trouver les notes du père de Théo",             done: false },
      { id: 'notes_lire',   text: "Lire les notes avec Théo",                       done: false },
      { id: 'theo_decide',  text: "Décider de ce qu'on fait avec ces informations", done: false },
    ],
    reward: { item: 'notes_pere_theo', flag: 'theo_allie', morale: +6 },
  },

  quete_vieux_gardien: {
    id: 'quete_vieux_gardien',
    name: "Le fils qui a oublié son prénom",
    type: 'secondary',
    zone: 'foret',
    giver: 'vieux_gardien',
    desc: "Le vieux gardien attend son fils depuis dix ans. Son fils Dorel est rentré — mais il n'est plus lui.",
    hint: "Dorel garde quelque chose. Le fragment sous son lit brille la nuit.",
    objectives: [
      { id: 'vg_parler',    text: "Parler au Vieux Gardien à l'entrée de la Forêt", done: false },
      { id: 'dorel_trouver', text: "Trouver Dorel dans le village",                 done: false },
      { id: 'fragment_dorel', text: "Comprendre ce que porte Dorel",               done: false },
      { id: 'vg_retour',    text: "Revenir voir le Vieux Gardien",                 done: false },
    ],
    reward: { item: 'fragment_dorel', flag: 'dorel_compris', morale: +5 },
  },

  quete_vaelt_noms: {
    id: 'quete_vaelt_noms',
    name: "Nommer les morts",
    type: 'secondary',
    zone: 'foret',
    giver: 'vaeltharion',
    desc: "Vaeltharion porte les noms de tous ceux qui ont été sacrifiés. Il attend que quelqu'un les retrouve — les vrais noms, ceux que leurs proches utilisaient.",
    hint: "Les noms sont dans le carnet d'Aldric, dans les lettres des victimes, et dans les mémoires des survivants.",
    objectives: [
      { id: 'vaelt_contact',   text: "Entrer en contact avec Vaeltharion",          done: false },
      { id: 'noms_lettre',     text: "Trouver au moins une lettre avec un prénom",  done: false },
      { id: 'noms_aldric',     text: "Obtenir le carnet d'Aldric",                  done: false },
      { id: 'noms_valeriane',  text: "Demander à Valériane les noms qu'elle connaît", done: false },
      { id: 'noms_remettre',   text: "Remettre les noms à Vaeltharion",             done: false },
    ],
    reward: { item: 'parole_vaeltharion', morale: +15, flag: 'vaelt_noms_remis' },
  },

  // ══════════════════════════════════════════════════════
  // ACTE 2 — MONTAGNES BRISÉES
  // ══════════════════════════════════════════════════════

  quete_murmures_sous_pierre: {
    id: 'quete_murmures_sous_pierre',
    name: "Les Murmures Sous la Pierre",
    type: 'main_secondary',
    zone: 'montagne',
    giver: 'villageois',
    desc: "Des villageois parlent de mines abandonnées depuis l'Éclatement. Quelqu'un a entendu des voix dedans. Personne n'est revenu raconter.",
    hint: "L'entrée principale est bloquée. Il y a un passage secondaire quelque part.",
    objectives: [
      { id: 'mines_entree',  text: "Trouver l'entrée cachée des mines",                              done: false },
      { id: 'mines_descente', text: "Descendre dans les galeries",                                  done: false },
      { id: 'mines_corps',   text: "Découvrir la salle centrale (scène clé)",                       done: false },
      { id: 'mines_choix',   text: "Décider du sort du cœur cristallisé",                          done: false },
    ],
    // SCÈNE CLÉ : corps fusionnés au cœur cristallisé
    // Dialogues déclenchés automatiquement à l'approche
    scene_key: {
      trigger_dist: 80,
      dialogues: [
        { speaker: 'Héros', text: "…C'est des gens.", color: '#ddd5cc' },
        { speaker: 'Valériane', text: "On leur a fait ça…", color: '#80c890', condition: 'valeriane_alliee' },
        { speaker: 'Vaeltharion', text: "Non.\n\nVous vous êtes fait ça.", color: '#7fffee' },
      ],
      choices: [
        {
          text: "Détruire le cœur cristallisé",
          effects: { morale: -5, vide: +12, flag: 'coeur_detruit',
            consequence: "Les ennemis de la zone deviennent plus agressifs. Vaeltharion gagne en puissance." },
        },
        {
          text: "Laisser le cœur intact",
          effects: { morale: +5, vide: -5, flag: 'coeur_laisse',
            consequence: "Le monde reste stable. Mais la vérité est retardée." },
        },
        {
          text: "Purifier le cœur (nécessite codex_liberation)",
          needs: 'codex_liberation',
          effects: { morale: +15, vide: -15, flag: 'coeur_purifie',
            consequence: "Les âmes fusionnées sont libérées. La salle s'illumine un instant." },
        },
      ],
    },
    reward_destroy: { flag: 'mines_done', morale: -5 },
    reward_leave:   { flag: 'mines_done', morale: +5 },
    reward_purify:  { flag: 'mines_done', flag2: 'ames_purifiees_mines', morale: +15, item: 'larme_statue' },
  },

  quete_aldric: {
    id: 'quete_aldric',
    name: "L'homme qui a obéi",
    type: 'secondary',
    zone: 'montagne',
    giver: 'valeriane',
    desc: "Aldric vit dans les Montagnes. Il se cache. Valériane dit qu'il attend qu'on vienne le chercher.",
    hint: "Il est armé. Il ne se battra pas. Il attend.",
    objectives: [
      { id: 'aldric_trouver',  text: "Trouver Aldric dans les Montagnes Brisées",   done: false },
      { id: 'aldric_ecouter',  text: "L'écouter sans juger trop vite",              done: false },
      { id: 'preuves_temple',  text: "Trouver les preuves dans les ruines du Temple", done: false },
      { id: 'aldric_temoigne', text: "Convaincre Aldric de témoigner",              done: false },
    ],
    reward: { item: 'carnet_aldric', flag: 'aldric_allie', morale: +10 },
  },

  quete_rust: {
    id: 'quete_rust',
    name: "La Lame du Remords",
    type: 'secondary',
    zone: 'montagne',
    giver: 'rust',
    desc: "Rust peut forger une arme capable de blesser L'Éveillé. Il a besoin de l'Éclat du Remords — gardé par Gorath.",
    hint: "Gorath est lent. Ses fissures brillent — tape-les en priorité.",
    objectives: [
      { id: 'rust_parler',   text: "Parler à Rust et accepter la mission",           done: false },
      { id: 'eclat_trouver', text: "Obtenir l'Éclat du Remords (vaincre Gorath)",  done: false },
      { id: 'eclat_retour',  text: "Rapporter l'Éclat à Rust",                      done: false },
      { id: 'lame_forgee',   text: "Recevoir la Lame du Remords",                   done: false },
    ],
    optional: {
      id: 'rust_dorel',
      text: "Transmettre un message de Rust à Dorel (optionnel)",
      reward: { item: 'potion_rust', morale: +5 },
    },
    reward: { item: 'lame_remords', flag: 'lame_forgee' },
  },

  // ══════════════════════════════════════════════════════
  // ACTE 3 — CITÉ ENGLOUTIE
  // ══════════════════════════════════════════════════════

  quete_luma: {
    id: 'quete_luma',
    name: "Ce que l'eau n'efface pas",
    type: 'secondary',
    zone: 'cite',
    giver: 'luma',
    desc: "Luma cherche le Journal du Dernier Archiviste — ses parents travaillaient dans la Cité. Elle veut savoir.",
    hint: "Le journal est au fond des ruines. Les spectres là-bas ne sont pas des ennemis — ils sont perdus.",
    objectives: [
      { id: 'luma_parler',   text: "Parler à Luma dans la Cité",                    done: false },
      { id: 'journal_trouver', text: "Trouver le Journal du Dernier Archiviste",    done: false },
      { id: 'journal_retour', text: "Rapporter le journal à Luma",                  done: false },
    ],
    reward: { item: 'codex_liberation', flag: 'luma_alliee', morale: +10 },
  },

  quete_chanson: {
    id: 'quete_chanson',
    name: "La mélodie que Nyla chantait",
    type: 'secondary',
    zone: 'cite',
    giver: 'luma',
    desc: "Luma connaît une chanson qui peut atteindre Nyxara avant qu'elle attaque. Nyxara s'appelait Nyla. Elle était archiviste.",
    hint: "Si tu as la mélodie, Nyxara hésite une fraction de seconde. C'est assez.",
    objectives: [
      { id: 'chanson_apprendre', text: "Apprendre la Mélodie des Archivistes de Luma", done: false },
    ],
    condition: 'luma_alliee',
    reward: { item: 'chanson_archiviste', morale: +5 },
  },

  // ══════════════════════════════════════════════════════
  // ACTE 4 — ABYSSE D'ÉBÈNE
  // ══════════════════════════════════════════════════════

  quete_mordred: {
    id: 'quete_mordred',
    name: "L'homme derrière le roi",
    type: 'secondary',
    zone: 'abysse',
    giver: 'mordred',
    desc: "Mordred est dans l'Abysse. Il attend depuis la Brisure. Il sait des choses sur lui-même qu'il n'a jamais dits à personne.",
    hint: "Il ne mentira pas si tu poses les bonnes questions. Il n'a plus rien à protéger.",
    objectives: [
      { id: 'mordred_trouver', text: "Trouver Mordred dans l'Abysse d'Ébène",       done: false },
      { id: 'mordred_ecouter', text: "L'écouter sans partir",                       done: false },
      { id: 'mordred_temoigne', text: "L'amener à accepter de témoigner",           done: false },
    ],
    reward: { item: 'memoire_mordred', item2: 'sagesse_mordred', flag: 'mordred_allie', morale: +12 },
  },

  quete_mordred_temoignage: {
    id: 'quete_mordred_temoignage',
    name: "Nommer les responsables",
    type: 'secondary',
    zone: 'abysse',
    giver: 'mordred',
    desc: "Mordred est prêt à nommer les autres responsables — mais seulement si tu as rassemblé les preuves du Temple et le carnet d'Aldric.",
    objectives: [
      { id: 'preuves_ok',  text: "Avoir les preuves du Temple",         done: false, needs: 'preuves_temple' },
      { id: 'carnet_ok',   text: "Avoir le carnet d'Aldric",            done: false, needs: 'carnet_aldric' },
      { id: 'mordred_nom', text: "Faire témoigner Mordred",             done: false },
    ],
    reward: { flag: 'mordred_temoignage_fait', morale: +15, unlocks_end: ['vraie_fin'] },
  },

  // ══════════════════════════════════════════════════════
  // QUÊTES LIBRES / EXPLORATION
  // ══════════════════════════════════════════════════════

  quete_lettres: {
    id: 'quete_lettres',
    name: "Les lettres jamais envoyées",
    type: 'exploration',
    zone: 'foret',
    giver: 'valeriane',
    desc: "Des victimes ont écrit des lettres avant. Certaines ont été interceptées par les Gardiens. Certaines sont encore dans les ruines.",
    objectives: [
      { id: 'lettre_1', text: "Trouver une première lettre",   done: false },
      { id: 'lettre_2', text: "Trouver une deuxième lettre",  done: false },
      { id: 'lettre_3', text: "Trouver une troisième lettre", done: false },
    ],
    reward: { item: 'lettre_victime', flag: 'lettres_trouvees', morale: +8 },
  },

  quete_journaux: {
    id: 'quete_journaux',
    name: "Les journaux intimes",
    type: 'exploration',
    zone: 'all',
    giver: 'valeriane',
    desc: "Certains gardaient des journaux jusqu'au bout. Pas sur le sacrifice — sur leur vie. Ce qu'ils aimaient.",
    objectives: [
      { id: 'journal_foret',    text: "Trouver un journal dans la Forêt",          done: false },
      { id: 'journal_montagne', text: "Trouver un journal dans les Montagnes",    done: false },
    ],
    reward: { flag: 'journaux_trouves', morale: +6, unlocks: ['vaelt_noms_journaux'] },
  },

  quete_origine: {
    id: 'quete_origine',
    name: "Qui suis-je vraiment",
    type: 'hidden',
    zone: 'all',
    giver: null,
    desc: "Il y a des trous dans ton histoire. Valériane le sait. Elias le soupçonne. La forêt garde peut-être la réponse.",
    hint: "Ne pas demander directement. Observer. Croiser les informations.",
    objectives: [
      { id: 'origine_elias',     text: "Demander à Elias si ton nom est dans ses archives", done: false },
      { id: 'origine_valeriane', text: "Parler à Valériane de ton village",                 done: false },
      { id: 'origine_steles',    text: "Chercher dans les stèles",                          done: false },
      { id: 'origine_mordred',   text: "Demander à Mordred",                                done: false },
    ],
    // TWIST : le héros descend d'un des sacrificateurs — pas des victimes
    // Cette quête révèle ça progressivement, sans le dire directement
    reward: { flag: 'origine_comprise', morale: -5, flag2: 'heros_origine_revele' },
  },

  quete_notes_theo: {
    id: 'quete_notes_theo',
    name: "L'ingénieur et son fils",
    type: 'secondary',
    zone: 'foret',
    giver: 'theo',
    desc: "Théo n'a pas fini de lire les notes de son père. Il a besoin d'aide — ou juste de quelqu'un qui reste.",
    objectives: [
      { id: 'theo_confiance',  text: "Gagner assez la confiance de Théo",            done: false },
      { id: 'notes_foret',     text: "Trouver les premières notes dans la Forêt",    done: false },
      { id: 'notes_montagne',  text: "Trouver les notes restantes dans les Montagnes", done: false },
      { id: 'theo_lire',       text: "Lire les notes avec Théo",                     done: false },
    ],
    reward: { item: 'notes_pere_theo', flag: 'theo_confiance_max', morale: +8 },
  },

  quete_memoire: {
    id: 'quete_memoire',
    name: "Ce qu'on t'a pris",
    type: 'hidden',
    zone: 'foret',
    giver: 'valeriane',
    desc: "Valériane a dit que les éclats peuvent prendre des souvenirs. Tu as des trous dans ta mémoire.",
    hint: "Ce que tu ne trouves pas dans ta tête, cherche-le à l'extérieur.",
    objectives: [
      { id: 'mem_valeriane', text: "Parler à Valériane des éclats et de la mémoire", done: false },
      { id: 'mem_eclat',     text: "Trouver un éclat lié à tes souvenirs perdus",   done: false },
    ],
    reward: { flag: 'memoire_recuperee', morale: +5, unlocks: ['heros_passe_eclaire'] },
  },

  quete_alternative: {
    id: 'quete_alternative',
    name: "Une lumière sans sacrifice",
    type: 'hidden',
    zone: 'all',
    giver: 'theo',
    desc: "Théo cherche une alternative à la Pierre. Une énergie sans prélèvement. Son père n'a pas trouvé. Peut-être toi.",
    hint: "Les notes du père + les archives de Luma + les observations de Théo dans la Forêt.",
    objectives: [
      { id: 'alt_notes',  text: "Avoir les notes du père de Théo",                  done: false, needs: 'notes_pere_theo' },
      { id: 'alt_luma',   text: "Obtenir les archives de Luma sur les éclats",      done: false },
      { id: 'alt_theo',   text: "Combiner les recherches avec Théo",                done: false },
    ],
    reward: { flag: 'alternative_trouvee', morale: +20, unlocks: ['vraie_fin_alternative'] },
  },
};

// Helpers
function getQuest(id) { return QUESTS[id] || null; }
function getActiveQuests(playerQuests) {
  return playerQuests.map(id => QUESTS[id]).filter(Boolean);
}
