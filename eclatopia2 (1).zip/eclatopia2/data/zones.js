// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/zones.js
// Définitions des zones — terrain, PNJ, ennemis, portails
// ═══════════════════════════════════════════════════════════

const ZONE_DATA = {

  foret: {
    id: 'foret',
    name: 'Forêt des Murmures',
    sub: 'Les arbres se souviennent',
    accent: '#3acfaa',
    bgTop: '#050d05',
    bgBot: '#091408',
    groundColor: '#0e1a0a',
    groundLine: '#162810',
    groundY: 0.66,
    fogColor: 'rgba(20,60,20,0.20)',
    ambientLight: '#1a3a1a',
    enemies: ['ombre', 'esprit'],
    boss: 'vaeltharion',
    pnjs: [
      { key: 'vieux_gardien', x: -680, y: 0, label: '???' },
      { key: 'elias',         x: -220, y: 0, label: 'Archiviste' },
      { key: 'valeriane',     x:  300, y: 0, label: 'Guérisseuse' },
      { key: 'theo',          x:  620, y: 0, label: 'Ingénieur' },
    ],
    steles: [
      { x: -420, y: 0, idx: 0, label: 'Stèle 1 — Nord du marais' },
      { x:   80, y: 0, idx: 1, label: 'Stèle 2 — Chêne fissuré' },
      { x:  520, y: 0, idx: 2, label: 'Stèle 3 — Là où l\'eau est absente' },
    ],
    portals: [
      { x: 900, nextZone: 'montagne', label: '➤ Montagnes Brisées', requiresBoss: true },
    ],
    // Objets cachés / lettres
    hiddenItems: [
      { x: -350, y: 0, item: 'lettre_victime',  label: '✉ Lettre', hidden: true },
      { x:  200, y: 0, item: 'journal_archiviste', label: '📔 Journal', hidden: true },
    ],
    mapPos: { x: 80, y: 200 },
    mapColor: '#3acfaa',
    lore: "Ici les arbres témoignent. Ils ont vu ce que les hommes ont préféré oublier. La forêt garde les noms.",
  },

  montagne: {
    id: 'montagne',
    name: 'Montagnes Brisées',
    sub: "L'Académie de Mordred était ici",
    accent: '#e08040',
    bgTop: '#0c0a06',
    bgBot: '#18120a',
    groundColor: '#221608',
    groundLine: '#382410',
    groundY: 0.65,
    fogColor: 'rgba(50,30,10,0.12)',
    ambientLight: '#2a1a08',
    enemies: ['golem', 'golem_petit'],
    boss: 'gorath',
    pnjs: [
      { key: 'rust',   x: -160, y: 0, label: 'Forgeron' },
      { key: 'aldric', x: -700, y: 0, label: '???' },
    ],
    steles: [],
    portals: [
      { x: 900, nextZone: 'cite', label: '➤ Cité Engloutie', requiresBoss: true },
    ],
    hiddenItems: [
      { x: -500, y: 0, item: 'preuves_temple',  label: '📄 Documents',  hidden: true },
      { x:  300, y: 0, item: 'notes_pere_theo',  label: '📐 Notes', hidden: true },
      { x: -800, y: 0, item: 'eclat_gorath',     label: '💎 Éclat', hidden: false, guardedByBoss: true },
    ],
    // Mines — zone spéciale déclenchée par quête
    subZones: [
      {
        id: 'mines',
        name: 'Mines abandonnées',
        triggerX: -600,
        triggerItem: 'conseil_steles', // Accessible après stèles
        bgTop: '#040408',
        fogColor: 'rgba(10,10,40,0.4)',
        // Scène clé des mines ici
        keySceneX: -800,
      },
    ],
    mapPos: { x: 300, y: 150 },
    mapColor: '#e08040',
    lore: "L'Académie de Mordred formait les ingénieurs et les Gardiens. Les golems exécutent encore leurs dernières instructions.",
  },

  cite: {
    id: 'cite',
    name: 'Cité Engloutie',
    sub: 'Sous les eaux, les archives',
    accent: '#4aacdf',
    bgTop: '#030a10',
    bgBot: '#050e1a',
    groundColor: '#06101e',
    groundLine: '#0e1e34',
    groundY: 0.64,
    fogColor: 'rgba(10,40,80,0.25)',
    ambientLight: '#0a2040',
    enemies: ['sirene', 'spectre_cite'],
    boss: 'nyxara',
    pnjs: [
      { key: 'luma', x: -180, y: 0, label: 'Bibliothécaire' },
    ],
    steles: [],
    portals: [
      { x: 900, nextZone: 'abysse', label: "➤ Abysse d'Ébène", requiresBoss: true },
    ],
    hiddenItems: [
      { x:  400, y: 0, item: 'journal_archiviste', label: '📔 Journal du Dernier Archiviste', hidden: true },
      { x: -400, y: 0, item: 'chanson_archiviste',  label: '🎵 Partition', hidden: true },
    ],
    mapPos: { x: 520, y: 280 },
    mapColor: '#4aacdf',
    lore: "Engloutie lors du Premier Rituel. Les archives sont encore là, sous les couches d'eau. Les spectres font encore leur routine.",
  },

  abysse: {
    id: 'abysse',
    name: "Abysse d'Ébène",
    sub: 'Là où la Pierre fut brisée',
    accent: '#e04060',
    bgTop: '#030208',
    bgBot: '#06030e',
    groundColor: '#080410',
    groundLine: '#100618',
    groundY: 0.65,
    fogColor: 'rgba(50,5,20,0.30)',
    ambientLight: '#1a0510',
    enemies: ['demon_abysse', 'eclat_corrompu', 'gardien_abysse'],
    boss: 'eveille',
    pnjs: [
      { key: 'mordred', x: -100, y: 0, label: '???' },
    ],
    steles: [],
    portals: [],
    hiddenItems: [
      { x: 200, y: 0, item: 'preuves_temple', label: '📄 Archives du Roi', hidden: true },
    ],
    mapPos: { x: 620, y: 340 },
    mapColor: '#e04060',
    lore: "L'endroit le plus sombre d'Éclatopia. Mordred a brisé la Pierre ici. L'Éveillé est à son plus fort dans ce vide.",
  },
};

// Ordre des zones pour la progression
const ZONE_ORDER = ['foret', 'montagne', 'cite', 'abysse'];

// Carte du monde (positions relatives pour le rendu)
const WORLD_MAP = {
  width: 700, height: 400,
  connections: [
    { from: 'foret', to: 'montagne' },
    { from: 'montagne', to: 'cite' },
    { from: 'cite', to: 'abysse' },
  ],
};

function getZone(id) { return ZONE_DATA[id] || ZONE_DATA.foret; }
function getNextZone(id) {
  const idx = ZONE_ORDER.indexOf(id);
  return idx >= 0 && idx < ZONE_ORDER.length - 1 ? ZONE_ORDER[idx + 1] : null;
}
