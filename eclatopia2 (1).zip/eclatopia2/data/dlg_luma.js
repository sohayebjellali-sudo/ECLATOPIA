// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/dlg_luma.js
// Luma — Bibliothécaire de la Cité Engloutie
// Elle sait la Vraie Fin. Elle attend quelqu'un de digne.
// ═══════════════════════════════════════════════════════════

const DLG_LUMA = {
  key: 'luma',
  name: 'Luma',
  title: 'Bibliothécaire',
  color: '#b070ff',
  portraitFn: 'portraitLuma',
  x: -180, zone: 'cite',

  nodes: {
    start: {
      speaker: 'Luma',
      text: "Tu arrives enfin.\n\nJ'ai lu les prophéties. J'ai attendu quelqu'un capable d'en supporter le poids.\n\nMais certaines vérités ont un prix — pour moi comme pour toi.",
      choices: [
        { text: "Quels secrets sur la Pierre ?",              next: 'secrets' },
        { text: "Que veux-tu en échange ?",                  next: 'prix' },
        { text: "Une façon de sauver L'Éveillé ?",           next: 'sauver' },
        { text: "Montre-moi ta boutique.",                   next: 'shop' },
        { text: "Parle-moi de toi.",                        next: 'luma_self' },
      ]
    },

    secrets: {
      speaker: 'Luma',
      text: "La Pierre n'a pas été créée par les Draconis comme les archives officielles le prétendent.\n\nElle existait avant eux.\n\nEt L'Éveillé… il n'est pas séparé de la Pierre. Il EST la conscience collective de ceux qui l'ont alimentée.",
      choices: [
        { text: "L'Éveillé peut être sauvé ?",               next: 'sauver' },
        { text: "Comment l'ont-ils emprisonné ?",            next: 'emprisonnement' },
        { text: "Pourquoi cette vérité est cachée ?",        next: 'cache' },
        { text: "Que dois-je faire ?",                      next: 'conseils' },
      ]
    },

    sauver: {
      speaker: 'Luma',
      text: "Oui.\n\nSi chaque éclat est utilisé pour libérer l'âme qu'il contient — pas pour l'absorber — L'Éveillé perd progressivement sa rage.\n\nQuand la dernière âme est libérée, il peut enfin se dissoudre en paix.\n\nC'est la Vraie Fin. Difficile, mais possible.",
      choices: [
        { text: "Je ferai ce choix à chaque boss.",          next: 'guide_liberation', effects: { morale: +10, flag: 'vraie_fin_unlocked' } },
        { text: "Et si j'absorbe certains éclats ?",         next: 'absorption_consequence' },
        { text: "Il y a un coût pour moi ?",                next: 'cout_liberation' },
      ]
    },

    guide_liberation: {
      speaker: 'Luma',
      text: "Bien.\n\nVoici le Codex des Libérations — il détaille comment procéder pour chaque boss.\n\nPour Vaeltharion : lui remettre les noms des victimes.\nPour Gorath : toucher sa fissure centrale avec le Remords.\nPour Nyxara : lui chanter la mélodie de Nyla.\nPour L'Éveillé… tu verras quand tu seras là.",
      choices: [
        { text: "Merci, Luma.",                             next: null, close: true, effects: { item: 'codex_liberation' } },
        { text: "J'ai d'autres questions.",                 next: 'start' },
      ]
    },

    absorption_consequence: {
      speaker: 'Luma',
      text: "Absorber un éclat te rend plus puissant… mais augmente le Vide.\n\nSi le Vide atteint 100%, L'Éveillé prend le contrôle.\n\nEt absorber plus de 2 éclats ferme la porte sur la Vraie Fin — il en faut trop pour stabiliser L'Éveillé ensuite.",
      choices: [
        { text: "Je comprends le risque.",                  next: 'sauver' },
      ]
    },

    cout_liberation: {
      speaker: 'Luma',
      text: "Libérer une âme au lieu d'absorber sa puissance… tu seras moins fort à court terme.\n\nMais ta morale augmentera, ton Vide diminuera.\n\nEt à long terme — tu auras accès à des capacités inaccessibles autrement.",
      choices: [
        { text: "Le choix juste n'est pas toujours le plus facile.", next: 'guide_liberation', effects: { morale: +5 } },
      ]
    },

    emprisonnement: {
      speaker: 'Luma',
      text: "Vaeltharion. Il était le gardien volontaire — une âme qui a accepté de rester dans la Pierre pour contenir la colère des autres.\n\nIl leur donnait de l'espoir de l'intérieur.\n\nQuand Mordred a brisé la Pierre… Vaeltharion a été libéré. Et L'Éveillé aussi.",
      choices: [
        { text: "Vaeltharion n'est pas un ennemi ?",         next: 'vaeltharion_allie' },
        { text: "Comment puis-je l'aider ?",                next: 'sauver' },
      ]
    },

    vaeltharion_allie: {
      speaker: 'Luma',
      text: "Exactement.\n\nIl teste ceux qui viennent — pour trouver quelqu'un digne d'entendre la vérité.\n\nSi tu le convaincs plutôt que de simplement le battre… il deviendra un allié contre L'Éveillé.",
      choices: [
        { text: "Je le convaincrai.",                       next: null, close: true, effects: { flag: 'vaelt_ally_possible' } },
        { text: "Merci Luma.",                             next: 'shop' },
      ]
    },

    cache: {
      speaker: 'Luma',
      text: "Parce que la vérité détruirait le système de pouvoir des Gardiens.\n\nJ'ai lu ça dans les archives quand j'avais 13 ans. J'aurais dû parler. Je ne l'ai pas fait.\n\nC'est mon crime.",
      choices: [
        { text: "Tu aurais dû parler.",                     next: 'reproche_luma', effects: { morale: -5 } },
        { text: "Tu étais jeune. Tu ne pouvais pas savoir.", next: 'pardon_luma', effects: { morale: +5 } },
        { text: "Il n'est pas trop tard pour agir.",        next: 'action_luma' },
      ]
    },

    reproche_luma: {
      speaker: 'Luma',
      text: "*(Elle baisse les yeux.)*\n\nOuais.\n\nSi j'avais parlé… peut-être que Mordred n'aurait pas agi seul.\n\nJe porte ça chaque jour.",
      choices: [
        { text: "Alors aide-moi vraiment.",                 next: 'guide_liberation', effects: { morale: +3 } },
      ]
    },

    pardon_luma: {
      speaker: 'Luma',
      text: "Merci.\n\nMais la compréhension n'efface pas la responsabilité.\n\nJe t'aide maintenant pour que cette vérité serve à quelque chose.",
      choices: [
        { text: "Ensemble, on peut réparer ça.",            next: 'guide_liberation', effects: { morale: +8 } },
      ]
    },

    action_luma: {
      speaker: 'Luma',
      text: "Exactement.\n\nJ'ai rassemblé tout ce que j'ai dans ce Codex. Prends-le.\n\nEt reviens si tu trouves le Journal du Dernier Archiviste au fond de la Cité — il parle de mes parents.",
      choices: [
        { text: "Je le trouverai.",                        next: null, close: true, effects: { quest: 'quete_luma', item: 'codex_liberation' } },
      ]
    },

    prix: {
      speaker: 'Luma',
      text: "Le Journal du Dernier Archiviste.\n\nIl est quelque part dans les ruines du fond — là où l'eau n'est pas trop profonde.\n\nMes parents étaient archivistes ici. L'engloutissement les a pris. Je veux savoir si… si ils ont souffert.",
      choices: [
        { text: "Je le trouverai.",                        next: 'quete_luma_accept', effects: { quest: 'quete_luma', morale: +8 } },
        { text: "C'est trop dangereux.",                   next: 'danger_luma' },
        { text: "Quelle récompense ?",                    next: 'recompense_luma' },
      ]
    },

    quete_luma_accept: {
      speaker: 'Luma',
      text: "Merci.\n\nPrends le Codex en attendant — il te sera utile.\n\nFais attention aux spectres au fond. Ils sont peut-être des âmes de ceux qui sont morts ici.\n\nIls méritent la paix, pas la destruction.",
      choices: [
        { text: "Je m'en souviendrai.",                    next: null, close: true, effects: { item: 'codex_liberation' } },
      ]
    },

    danger_luma: {
      speaker: 'Luma',
      text: "Je comprends.\n\nMais si tu changes d'avis… les archives resteront fermées jusqu'à ton retour.",
      choices: [
        { text: "D'accord, j'irai.",                      next: 'quete_luma_accept', effects: { quest: 'quete_luma' } },
        { text: "Au revoir, Luma.",                       next: null, close: true },
      ]
    },

    recompense_luma: {
      speaker: 'Luma',
      text: "Le Codex des Libérations, qui débloque la Vraie Fin.\n\nEt le savoir pour choisir correctement face à chaque boss.\n\nCe que tu ne peux pas acheter ailleurs.",
      choices: [
        { text: "Marché conclu.",                         next: 'quete_luma_accept', effects: { quest: 'quete_luma' } },
      ]
    },

    conseils: {
      speaker: 'Luma',
      text: "Nyxara — le boss de cette zone — s'appelait Nyla. Elle était archiviste comme moi.\n\nSi tu as appris la Mélodie des Archivistes et que tu la lui chantes… elle pourrait redevenir elle-même brièvement. Assez pour céder l'éclat sans combat.",
      choices: [
        { text: "Apprends-moi cette mélodie.",            next: 'melodie', effects: { quest: 'quete_chanson' } },
        { text: "Je préfère combattre.",                 next: 'shop' },
      ]
    },

    melodie: {
      speaker: 'Luma',
      text: "*(Elle ferme les yeux. Fredonne quelque chose de court.)*\n\nVoilà. Je l'ai transcrite ici.\n\nNyla la chantait quand elle travaillait tard. Je l'entendais de l'autre bout des archives.",
      choices: [
        { text: "Merci.",                               next: null, close: true, effects: { item: 'chanson_archiviste', flag: 'melodie_apprise' } },
      ]
    },

    luma_self: {
      speaker: 'Luma',
      text: "Je suis la dernière archiviste de la Cité Engloutie.\n\nMes parents sont morts ici lors de l'engloutissement.\n\nJ'ai passé ma vie dans ces ruines à déchiffrer ce que les Draconis ont laissé.\n\nCertaines nuits, je crois entendre leurs voix dans l'eau.",
      choices: [
        { text: "Je suis désolé pour tes parents.",      next: 'prix', effects: { morale: +3 } },
        { text: "Les âmes peuvent être libérées.",      next: 'sauver' },
      ]
    },

    shop: {
      speaker: 'Luma',
      text: "J'échange des connaissances et des objets contre de l'or.\n\nCe sont mes fonds pour continuer les recherches.",
      choices: [
        { text: "Parchemin de Soin — 40 or (+60 PV)",                next: null, close: true, effects: { buy: { item: 'parchemin_soin', cost: 40 } } },
        { text: "Rune de Purification — 90 or (Vide -20)",           next: null, close: true, effects: { buy: { item: 'rune_purif', cost: 90 } } },
        { text: "Codex des Anciens — 150 or (+200 XP)",              next: null, close: true, effects: { buy: { item: 'codex_anciens', cost: 150 } } },
        { text: "Élixir du Vide — 120 or (Vide -30)",                next: null, close: true, effects: { buy: { item: 'elixir_vide', cost: 120 } } },
        { text: "Rien pour l'instant.",                             next: null, close: true },
      ]
    },
  }
};
