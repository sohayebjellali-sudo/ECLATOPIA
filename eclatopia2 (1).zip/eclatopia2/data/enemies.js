// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/enemies.js
// Ennemis réguliers + boss avec phases et patterns
// ═══════════════════════════════════════════════════════════

// ── ENNEMIS RÉGULIERS ─────────────────────────────────────
const ENEMY_TYPES = {

  ombre: {
    id: 'ombre', name: 'Ombre Errante',
    desc: "Forme humanoïde instable. Corps noir aux contours flous. Elle flotte.",
    hp: 35, atk: 6, def: 2, spd: 1.4, sz: 34,
    col: '#ff3050', xp: 20, gold: [5,15], moraleDrain: -3, vidGain: 0.5,
    atkRange: 32, atkCd: 1400,
    drawFn: 'drawOmbreErrante',
    // Comportement : approche lente, attaque par projection
    ai: 'chase_slow',
    // Attaque spéciale : projection d'ombre (projectile)
    specialAtk: { type: 'proj', dmgMult: 0.7, range: 180, cd: 3500 },
    weakTo: 'light',
    lore: "Elle répète les derniers mots de quelqu'un. Si tu écoutes assez longtemps tu l'entends.",
  },

  esprit: {
    id: 'esprit', name: 'Esprit Ancien',
    desc: "Plus ancien que les Ombres. Il se souvient de quelque chose.",
    hp: 50, atk: 8, def: 4, spd: 0.9, sz: 30,
    col: '#8080ff', xp: 28, gold: [8,20], moraleDrain: -4, vidGain: 0.7,
    atkRange: 28, atkCd: 1600,
    drawFn: 'drawEsprit',
    ai: 'orbit',
    specialAtk: { type: 'slow_field', dmgMult: 0.5, range: 100, cd: 4000 },
    weakTo: 'light',
    lore: "Il gravite autour des stèles. Comme s'il les gardait — ou s'il essayait de les lire.",
  },

  golem: {
    id: 'golem', name: 'Golem de Pierre',
    desc: "Corps de roche avec fissures lumineuses orangées. Lent. Très puissant.",
    hp: 110, atk: 15, def: 14, spd: 0.55, sz: 50,
    col: '#e08040', xp: 45, gold: [15,30], moraleDrain: -2, vidGain: 0.3,
    atkRange: 50, atkCd: 2000,
    drawFn: 'drawGolem',
    ai: 'stomp_chase',
    specialAtk: { type: 'ground_slam', dmgMult: 1.2, range: 80, cd: 4500 },
    weakTo: 'wave',
    lore: "Ils exécutent encore leurs dernières instructions. Personne ne leur a dit que la mission était terminée.",
  },

  golem_petit: {
    id: 'golem_petit', name: 'Éclat de Golem',
    desc: "Fragment d'un golem brisé. Petit, rapide, agressif.",
    hp: 30, atk: 10, def: 4, spd: 1.8, sz: 22,
    col: '#c06030', xp: 18, gold: [5,12], moraleDrain: -1, vidGain: 0.2,
    atkRange: 24, atkCd: 900,
    drawFn: 'drawGolemPetit',
    ai: 'chase_fast',
    lore: "Il cherche ses autres morceaux.",
  },

  sirene: {
    id: 'sirene', name: 'Sirène Corrompue',
    desc: "Mi-humain, mi-poisson. Peau pâle bleutée. Elle chantait avant.",
    hp: 70, atk: 10, def: 6, spd: 1.15, sz: 42,
    col: '#4aacdf', xp: 38, gold: [10,25], moraleDrain: -4, vidGain: 0.6,
    atkRange: 38, atkCd: 1600,
    drawFn: 'drawSirene',
    ai: 'circle_attack',
    specialAtk: { type: 'sound_wave', dmgMult: 0.6, range: 200, cd: 3800 },
    weakTo: 'fire',
    lore: "Elle s'appelait Nyla. Elle a touché un éclat. C'était il y a longtemps.",
  },

  spectre_cite: {
    id: 'spectre_cite', name: 'Spectre de la Cité',
    desc: "Les anciens habitants. Ils ne savent pas qu'ils sont morts.",
    hp: 45, atk: 9, def: 3, spd: 1.3, sz: 28,
    col: '#60a0c0', xp: 25, gold: [6,18], moraleDrain: -5, vidGain: 0.8,
    atkRange: 30, atkCd: 1500,
    drawFn: 'drawSpectre',
    ai: 'wander_chase',
    // Ces ennemis peuvent être "apaisés" plutôt que tués (si Luma est alliée)
    canBePacified: true,
    pacifyItem: 'codex_liberation',
    lore: "Ils font encore leur routine du matin. Ils ne comprennent pas pourquoi personne ne répond.",
  },

  demon_abysse: {
    id: 'demon_abysse', name: "Démon d'Ombre",
    desc: "Fragment de L'Éveillé en forme autonome. Plus puissant que les Ombres.",
    hp: 80, atk: 18, def: 8, spd: 1.0, sz: 38,
    col: '#e04060', xp: 55, gold: [20,40], moraleDrain: -8, vidGain: 1.2,
    atkRange: 40, atkCd: 1200,
    drawFn: 'drawDemonAbysse',
    ai: 'aggressive_chase',
    specialAtk: { type: 'void_proj', dmgMult: 0.9, range: 220, cd: 2500 },
    lore: "Il n'est pas autonome. Il cherche à rejoindre l'entité principale.",
  },

  eclat_corrompu: {
    id: 'eclat_corrompu', name: 'Éclat Corrompu',
    desc: "Fragment de la Pierre devenu instable. S'approche et explose.",
    hp: 25, atk: 22, def: 0, spd: 2.2, sz: 18,
    col: '#ff2040', xp: 20, gold: [3,8], moraleDrain: -6, vidGain: 1.0,
    atkRange: 20, atkCd: 500,
    drawFn: 'drawEclatCorrompu',
    ai: 'kamikaze',
    lore: "La Pierre fragmentée cherche à se reconstituer. Même un éclat.",
  },

  gardien_abysse: {
    id: 'gardien_abysse', name: 'Gardien du Vide',
    desc: "Ancien Gardien corrompu par le Vide. Il défend encore son poste.",
    hp: 120, atk: 20, def: 15, spd: 0.7, sz: 44,
    col: '#4020a0', xp: 70, gold: [25,50], moraleDrain: -10, vidGain: 1.5,
    atkRange: 44, atkCd: 2500,
    drawFn: 'drawGardienAbysse',
    ai: 'defend_zone',
    specialAtk: { type: 'void_burst', dmgMult: 1.4, range: 160, cd: 5000 },
    lore: "Il a oublié ce qu'il garde. Il sait juste que quelqu'un ne doit pas passer.",
  },
};

// ── BOSS ──────────────────────────────────────────────────
const BOSS_TYPES = {

  vaeltharion: {
    id: 'vaeltharion',
    name: 'Vaeltharion',
    sub: 'Le Veilleur des Âmes',
    zone: 'foret',
    hp: 280, atk: 20, def: 8, sz: 56,
    col: '#7fffee', glow: 'rgba(127,255,238,0.5)',
    xp: 300, gold: [80,140],
    drawFn: 'drawVaeltharion',
    // Peut être évité si parole_vaeltharion est en inventaire
    canAvoid: true, avoidItem: 'parole_vaeltharion',
    phases: [
      {
        threshold: 1.0, pattern: 'orbit', atkMult: 1.0,
        msg: 'Vaeltharion projette des visions du passé…',
        desc: "Il orbite lentement. Lance des orbes de mémoire en cercle.",
      },
      {
        threshold: 0.6, pattern: 'burst', atkMult: 1.5,
        msg: 'Les âmes sacrifiées se déchaînent !',
        desc: "Rafales de 7 projectiles. Plus rapide.",
      },
      {
        threshold: 0.3, pattern: 'charge', atkMult: 2.0,
        msg: '⚠ Vaeltharion révèle sa vraie puissance !',
        desc: "Charges directes. Projectiles en spirale.",
      },
    ],
    preDialogue: [
      { speaker: 'Vaeltharion', text: "Tu entends.", color: '#7fffee' },
      { speaker: 'Vaeltharion', text: "Bien.\n\nAlors tu peux comprendre ce qu'on t'a caché.", color: '#7fffee' },
    ],
    postDialogue: [
      { speaker: 'Vaeltharion', text: "…Tu peux encore choisir.\n\nPas pour moi. Pour eux.", color: '#7fffee' },
    ],
    choices: [
      { text: "Libérer les âmes (+20 morale, Vide -10)", morale: +20, vide: -10, flag: 'vaelt_libere' },
      { text: "Absorber le pouvoir (-15 morale, Vide +20)", morale: -15, vide: +20, flag: 'vaelt_absorbe' },
      { text: "Sceller Vaeltharion (neutre)", morale: 0, vide: 0, flag: 'vaelt_scelle' },
      { text: "Négocier un pacte [nécessite parchemin_elias] (+10 morale, Vide -5)", morale: +10, vide: -5, needs: 'parchemin_elias', flag: 'vaelt_pacte' },
      { text: "Lui remettre les noms [nécessite carnet_aldric] (+25 morale, Vide -20)", morale: +25, vide: -20, needs: 'carnet_aldric', flag: 'vaelt_noms_remis' },
    ],
  },

  gorath: {
    id: 'gorath',
    name: 'Gorath le Brisé',
    sub: 'Golem Gardien',
    zone: 'montagne',
    hp: 420, atk: 26, def: 18, sz: 68,
    col: '#e08040', glow: 'rgba(224,128,64,0.5)',
    xp: 450, gold: [100,180],
    drawFn: 'drawGolem',
    canAvoid: false,
    phases: [
      {
        threshold: 1.0, pattern: 'stomp', atkMult: 1.0,
        msg: 'GORATH… PROTÉGER… FRAGMENT…',
        desc: "Frappe lente. Projections en croix.",
      },
      {
        threshold: 0.5, pattern: 'slam', atkMult: 1.6,
        msg: 'GORATH… COLÈRE…',
        desc: "Charges rapides. Projections radiales à 8 directions.",
      },
      {
        threshold: 0.2, pattern: 'shatter', atkMult: 2.2,
        msg: '⚠ GORATH… SE… BRISER…',
        desc: "Eclats partout. Vitesse maximale. Spawn de golems_petits.",
      },
    ],
    preDialogue: [
      { speaker: 'Gorath', text: "GRRRR… PROTÉGER… FRAGMENT…", color: '#e08040' },
      { speaker: 'Gorath', text: "POURQUOI… VOULOIR… BRISER… ORDRE ?", color: '#e08040' },
    ],
    postDialogue: [
      { speaker: 'Gorath', text: "…VOUS… FORT… FRAGMENT… DANGEREUX…\n…ATTENTION…", color: '#e08040' },
    ],
    choices: [
      { text: "Prendre l'Éclat du Remords (-15 morale, Vide +15)", morale: -15, vide: +15, item: 'eclat_gorath', flag: 'eclat_pris' },
      { text: "Laisser Gorath garder l'éclat (+15 morale, Vide -5)", morale: +15, vide: -5, flag: 'eclat_laisse' },
      { text: "Purifier Gorath [nécessite rune_purif] (+25 morale, Vide -15)", morale: +25, vide: -15, needs: 'rune_purif', flag: 'gorath_purifie', item: 'eclat_gorath' },
    ],
  },

  nyxara: {
    id: 'nyxara',
    name: 'Nyxara',
    sub: 'Sirène Ancienne',
    zone: 'cite',
    hp: 350, atk: 22, def: 10, sz: 58,
    col: '#4aacdf', glow: 'rgba(74,172,223,0.5)',
    xp: 400, gold: [90,160],
    drawFn: 'drawSirene',
    canAvoid: true, avoidItem: 'chanson_archiviste',
    phases: [
      {
        threshold: 1.0, pattern: 'charm', atkMult: 1.0,
        msg: 'Nyxara tente de te charmer…',
        desc: "Projectiles lents mais nombreux. Se téléporte.",
      },
      {
        threshold: 0.55, pattern: 'wave', atkMult: 1.65,
        msg: 'Les profondeurs se déchaînent !',
        desc: "Vagues de 5 projectiles en éventail.",
      },
      {
        threshold: 0.25, pattern: 'vortex', atkMult: 2.1,
        msg: "⚠ Nyxara libère toute l'énergie du fragment !",
        desc: "Spirale de 10 projectiles. Vortex central.",
      },
    ],
    preDialogue: [
      { speaker: 'Nyxara', text: "Tu es venu pour le fragment, petit mortel ?", color: '#4aacdf' },
      { speaker: 'Nyxara', text: "Je peux te l'offrir… pour un prix.", color: '#4aacdf' },
    ],
    postDialogue: [
      { speaker: 'Nyxara', text: "…Les archives de Theon sont dans l'autel.\nSache ce que tu trouveras.", color: '#4aacdf' },
    ],
    choices: [
      { text: "Accepter l'Éclat (-10 morale, Vide +20)", morale: -10, vide: +20, item: 'eclat_nyxara', flag: 'nyxara_absorbe' },
      { text: "Libérer les âmes de la Cité (+25 morale, Vide -15)", morale: +25, vide: -15, flag: 'nyxara_libere' },
      { text: "Chanter la Mélodie [nécessite chanson_archiviste] (+30 morale, Vide -20)", morale: +30, vide: -20, needs: 'chanson_archiviste', flag: 'nyxara_melodie', item: 'eclat_nyxara' },
      { text: "La laisser partir pacifiquement (+15 morale)", morale: +15, flag: 'nyxara_paix' },
    ],
  },

  eveille: {
    id: 'eveille',
    name: "L'Éveillé",
    sub: 'Entité des Dix Mille Âmes',
    zone: 'abysse',
    hp: 600, atk: 36, def: 20, sz: 82,
    col: '#e04060', glow: 'rgba(224,64,96,0.6)',
    xp: 1000, gold: [200,400],
    drawFn: 'drawVaeltharion', // Réutilise le sprite mais plus grand et rouge
    canAvoid: false,
    phases: [
      {
        threshold: 1.0, pattern: 'pulse', atkMult: 1.0,
        msg: "L'Éveillé sonde ton âme…",
        desc: "Orbite lente. 6 projectiles en étoile régulière.",
      },
      {
        threshold: 0.7, pattern: 'spiral', atkMult: 1.6,
        msg: "Les éclats corrompus s'arrachent !",
        desc: "Spirale rotative. 8 projectiles. Spawne des eclats_corrompus.",
      },
      {
        threshold: 0.4, pattern: 'darkness', atkMult: 2.1,
        msg: "L'Éveillé dévore la lumière !",
        desc: "Charge rapide + 3 projectiles perpendiculaires. L'écran s'assombrit.",
      },
      {
        threshold: 0.15, pattern: 'void', atkMult: 2.8,
        msg: '⚠ LE VIDE ABSOLU !',
        desc: "14 projectiles en rotation constante. Immobile. Seule la Lame du Remords est efficace.",
      },
    ],
    preDialogue: [
      { speaker: "L'Éveillé", text: "DIX MILLE ANS…\n\nJ'AI ATTENDU…\n\nDIX MILLE ANS…", color: '#e04060' },
      { speaker: "L'Éveillé", text: "TU ES VENU AVEC TA CULPABILITÉ…\n\nELLE ME NOURRIRA.", color: '#e04060' },
      { speaker: "L'Éveillé", text: "MORDRED M'A LIBÉRÉ…\n\nTU PENSAIS POUVOIR M'ARRÊTER ?", color: '#e04060' },
    ],
    postDialogue: [
      { speaker: "L'Éveillé", text: "…Impossible…\n\nDix mille ans… pour ça…", color: '#e04060' },
    ],
    choices: [
      {
        text: "Vraie Fin — Fusionner et libérer toutes les âmes",
        needs: ['memoire_mordred', 'codex_liberation'],
        needsAll: true,
        end: 'vraie_fin',
        morale: +50, vide: -100,
      },
      {
        text: "Fin Lumière — Restaurer la Pierre de Lueur",
        end: 'lumiere',
        morale: +20, vide: -50,
      },
      {
        text: "Fin Équilibre — Laisser l'équilibre précaire",
        end: 'equilibre',
        morale: 0, vide: -20,
      },
      {
        text: "Fin Ombre — S'unir à L'Éveillé",
        end: 'ombre',
        morale: -50, vide: +50,
      },
    ],
  },
};

function getEnemy(type) { return ENEMY_TYPES[type] || ENEMY_TYPES.ombre; }
function getBoss(id)    { return BOSS_TYPES[id]    || null; }
