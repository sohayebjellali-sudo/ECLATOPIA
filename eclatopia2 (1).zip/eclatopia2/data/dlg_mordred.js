// ÉCLATOPIA 2 — data/dlg_mordred.js — Mordred, Ancien Roi
const DLG_MORDRED = {
  key: 'mordred', name: 'Mordred', title: '???',
  color: '#c04030', portraitFn: 'portraitMordred',
  x: -100, zone: 'abysse',
  nodes: {
    start: {
      speaker: '???',
      text: "*(Une silhouette dans l'ombre. Immobile. Elle te regarde mais ne dit rien.)*",
      choices: [
        { text: "Mordred ?",                        next: 'mordred_nom', effects: { flag: 'mordred_trouve' } },
        { text: "Qui êtes-vous ?",                  next: 'qui_mordred' },
        { text: "Je cherche des réponses.",         next: 'reponses_mordred' },
      ]
    },
    mordred_nom: {
      speaker: '???',
      text: "*(Un long silence. Puis :)*\n\nÇa fait longtemps que personne a prononcé ce nom.",
      choices: [
        { text: "Et vous avez répondu.",            next: 'repondu', effects: { flag: 'mordred_identite_confirm' } },
        { text: "Qu'est-ce que ça fait d'entendre son propre nom ?", next: 'entendre_nom' },
      ]
    },
    repondu: {
      speaker: 'Mordred',
      text: "*(Il s'avance légèrement.)*\n\nOuais.\n\nMême si j'aurais préféré pas.",
      choices: [
        { text: "Pourquoi ?",                       next: 'pourquoi_pas' },
        { text: "Ce nom vous fait peur ?",          next: 'peur_nom' },
      ]
    },
    pourquoi_pas: {
      speaker: 'Mordred',
      text: "Parce qu'entendre mon nom… c'est être rappelé à ce que j'ai fait.\n\nEt il y a des jours où j'aimerais oublier.",
      choices: [
        { text: "Mais vous oubliez pas.",           next: 'oublie_pas', effects: { flag: 'mordred_memoire_vivante' } },
        { text: "C'est ce que vous méritez ?",      next: 'merite', effects: { morale: -3 } },
      ]
    },
    oublie_pas: {
      speaker: 'Mordred',
      text: "*(Un silence court.)*\n\nNon.\n\nJe voudrais. Mais non.",
      choices: [
        { text: "Qu'est-ce que vous avez fait ?",   next: 'quoi_fait', effects: { flag: 'mordred_aveu_demande' } },
        { text: "Pourquoi vous voulez oublier ?",   next: 'vouloir_oublier' },
      ]
    },
    quoi_fait: {
      speaker: 'Mordred',
      text: "*(Il prend une longue inspiration.)*\n\nJ'ai ordonné des sacrifices.\n\nDes gens. Ordinaires. Des centaines.\n\nPour maintenir la Pierre de Lueur.\n\nPour ce que je croyais être le bien commun.",
      choices: [
        { text: "Vous croyiez vraiment que c'était le bien commun ?", next: 'croyait', effects: { flag: 'mordred_conviction' } },
        { text: "Et maintenant ?",                  next: 'maintenant', effects: { flag: 'mordred_maintenant' } },
        { text: "Il y avait d'autres façons.",      next: 'autres_facon', effects: { morale: +3 } },
      ]
    },
    croyait: {
      speaker: 'Mordred',
      text: "Ouais.\n\nC'est la réponse courte.\n\nLa longue… c'est que je voulais y croire. Parce que si c'était pas le bien commun, alors j'étais juste un meurtrier avec un trône.\n\nEt c'est plus difficile à accepter.",
      choices: [
        { text: "Mais c'est plus proche de la vérité.", next: 'verite_mordred', effects: { morale: +3 } },
        { text: "La conviction peut coexister avec l'erreur.", next: 'conviction_erreur', effects: { morale: +2 } },
        { text: "...",                              next: 'maintenant' },
      ]
    },
    verite_mordred: {
      speaker: 'Mordred',
      text: "*(Il te regarde longuement.)*\n\nOuais.\n\nC'est plus proche.\n\nMerci de le dire directement.",
      choices: [
        { text: "Et maintenant ?",                  next: 'maintenant' },
        { text: "Vous pouvez encore réparer quelque chose ?", next: 'reparer', effects: { flag: 'mordred_reparation' } },
      ]
    },
    conviction_erreur: {
      speaker: 'Mordred',
      text: "Ouais. Elles peuvent.\n\nMais ça change pas le résultat.\n\nLes gens sont morts. Convaincus ou pas.",
      choices: [
        { text: "C'est juste.",                     next: 'maintenant', effects: { morale: +2 } },
      ]
    },
    maintenant: {
      speaker: 'Mordred',
      text: "*(Il regarde autour de lui. Les ruines.)*\n\nMaintenant j'attends.\n\nJe sais pas quoi. Peut-être quelqu'un qui porte les vraies questions.\n\n*(Il te regarde.)*\n\nOu peut-être quelqu'un qui porte les réponses.",
      choices: [
        { text: "Je cherche les deux.",             next: 'cherche_deux', effects: { morale: +3, flag: 'mordred_heros_lien' } },
        { text: "Vous pouvez encore réparer quelque chose ?", next: 'reparer' },
        { text: "Pourquoi vous avez pas disparu ?", next: 'disparu' },
      ]
    },
    cherche_deux: {
      speaker: 'Mordred',
      text: "*(Il hoche la tête.)*\n\nAlors tu peux peut-être faire ce que moi j'ai raté.",
      choices: [
        { text: "Quoi exactement ?",                next: 'quoi_mordred_aide', effects: { flag: 'mordred_allie_possible' } },
      ]
    },
    quoi_mordred_aide: {
      speaker: 'Mordred',
      text: "Poser les vraies questions avant d'agir.\n\nEntendre ceux que tu veux « aider » avant de décider pour eux.\n\nEt accepter qu'une bonne intention sans écoute… c'est juste de l'arrogance bien habillée.",
      choices: [
        { text: "Je retiendrai ça.",                next: null, close: true, effects: { morale: +8, flag: 'mordred_confiance', item: 'sagesse_mordred' } },
      ]
    },
    reparer: {
      speaker: 'Mordred',
      text: "*(Il réfléchit.)*\n\nTémoigner. Donner les noms des autres responsables.\n\nNommer les victimes que j'ai effacées.\n\nEt laisser faire la justice — celle des survivants.",
      choices: [
        { text: "Je vous aiderai à témoigner.",     next: null, close: true, effects: { quest: 'quete_mordred_temoignage', flag: 'mordred_temoignage_futur', morale: +8 } },
        { text: "La justice des survivants…",       next: 'justice_surv' },
      ]
    },
    justice_surv: {
      speaker: 'Mordred',
      text: "C'est celle qui compte.\n\nPas la mienne. Pas celle d'un tribunal.\n\nCelle de ceux qui ont subi.",
      choices: [
        { text: "D'accord. Je les réunirai.",       next: null, close: true, effects: { quest: 'quete_mordred_temoignage', flag: 'mordred_allie', morale: +5 } },
      ]
    },
    disparu: {
      speaker: 'Mordred',
      text: "Parce que disparaître… c'est aussi une façon d'esquiver.\n\nSi je disparais, personne peut comprendre. Personne peut apprendre.\n\nEt les mêmes erreurs recommenceront.",
      choices: [
        { text: "Vous voulez que l'histoire serve à quelque chose.", next: 'histoire_sert', effects: { morale: +5, flag: 'mordred_lecon_histoire' } },
      ]
    },
    histoire_sert: {
      speaker: 'Mordred',
      text: "*(Il lève les yeux.)*\n\nOuais.\n\nC'est le minimum que je peux faire.\n\nQue mon erreur serve à quelque chose.",
      choices: [
        { text: "Elle servira.",                    next: null, close: true, effects: { morale: +8, flag: 'mordred_confiance_max', quest: 'quete_mordred_temoignage' } },
      ]
    },
    merite: {
      speaker: 'Mordred',
      text: "Probablement.\n\nMais se mériter ou pas un souvenir… c'est pas la bonne question.\n\nLa question c'est si ce souvenir est utile.",
      choices: [
        { text: "Utile comment ?",                  next: 'utile' },
      ]
    },
    utile: {
      speaker: 'Mordred',
      text: "Pour comprendre comment on arrive à faire des choses terribles en croyant faire le bien.\n\nEt comment empêcher que ça recommence.",
      choices: [
        { text: "C'est pour ça que vous êtes encore là.", next: null, close: true, effects: { morale: +5, flag: 'mordred_lien_heros' } },
      ]
    },
    vouloir_oublier: {
      speaker: 'Mordred',
      text: "Parce que les nuits sont longues ici.\n\nEt que dans le silence… les images reviennent.\n\nToujours les mêmes.\n\nJe suis jamais allé voir de près.\n\n*(Sa voix change.)*\n\nPeut-être que si j'avais regardé en face…",
      choices: [
        { text: "...",                              next: null, close: true, effects: { morale: +3, flag: 'mordred_distance_crime' } },
      ]
    },
    autres_facon: {
      speaker: 'Mordred',
      text: "Oui.\n\nJ'aurais dû chercher des alliés. Partager le problème. Trouver une solution ensemble.\n\nAu lieu de ça, j'ai agi seul, dans la nuit, convaincu de savoir mieux que tout le monde.\n\nC'est ça mon vrai crime.",
      choices: [
        { text: "L'arrogance.",                     next: null, close: true, effects: { morale: +5, flag: 'mordred_lecon_arrogance', item: 'sagesse_mordred' } },
      ]
    },
    peur_nom: {
      speaker: 'Mordred',
      text: "Pas peur. Quelque chose comme… de la honte.\n\nMon nom était un titre. Un symbole.\n\nMaintenant c'est juste le nom de quelqu'un qui a fait du mal.",
      choices: [
        { text: "Et c'est plus honnête.",           next: 'honnete_mordred', effects: { morale: +3 } },
      ]
    },
    honnete_mordred: {
      speaker: 'Mordred',
      text: "Ouais.\n\nLes symboles servent surtout à cacher ce qui est dessous.",
      choices: [
        { text: "Qu'est-ce qu'il y avait sous le symbole ?", next: 'sous_symbole' },
      ]
    },
    sous_symbole: {
      speaker: 'Mordred',
      text: "Un homme qui avait peur du chaos. Qui voulait contrôler. Et qui a confondu contrôle et protection.",
      choices: [
        { text: "Ce n'est pas la même chose.",      next: null, close: true, effects: { morale: +5, flag: 'mordred_lecon_controle' } },
      ]
    },
    entendre_nom: {
      speaker: 'Mordred',
      text: "Comme quand t'entends une vieille chanson.\n\nTu reconnais. Tu sais que c'était toi. Mais t'as du mal à croire que c'était toi.",
      choices: [
        { text: "C'était bien vous ?",              next: 'etait_bien', effects: { flag: 'mordred_identite_question' } },
        { text: "...",                             next: 'quoi_fait' },
      ]
    },
    etait_bien: {
      speaker: 'Mordred',
      text: "Ouais.\n\nC'était moi. J'ai pas changé de personne. J'ai juste… retiré les couches qui me permettaient de pas voir.",
      choices: [
        { text: "C'est du courage.",               next: null, close: true, effects: { morale: +5, flag: 'mordred_confiance' } },
        { text: "Qu'est-ce que vous avez vu ?",    next: 'vu_mordred' },
      ]
    },
    vu_mordred: {
      speaker: 'Mordred',
      text: "Que j'avais décidé pour des gens qui n'avaient pas décidé.\n\nQue leur vie valait moins que mon idée de la paix.\n\nEt que c'est ça le vrai crime. Pas les actes. La hiérarchie des vies.",
      choices: [
        { text: "La hiérarchie des vies.",         next: null, close: true, effects: { morale: +8, flag: 'mordred_lecon_hierarchie', item: 'sagesse_mordred' } },
      ]
    },
    qui_mordred: {
      speaker: '???',
      text: "*(Il ne répond pas.)*",
      choices: [
        { text: "Mordred ?",                       next: 'mordred_nom', effects: { flag: 'mordred_trouve' } },
        { text: "Quelqu'un qui se cache.",         next: 'cache_mordred' },
      ]
    },
    cache_mordred: {
      speaker: '???',
      text: "*(Long silence.)*\n\nOuais.",
      choices: [
        { text: "De quoi ?",                       next: 'de_quoi_mordred' },
      ]
    },
    de_quoi_mordred: {
      speaker: '???',
      text: "*(Il regarde autour de lui.)*\n\nDe moi-même.\n\nEt de vous.",
      choices: [
        { text: "Vous ?",                          next: 'mordred_nom', effects: { flag: 'mordred_trouve' } },
      ]
    },
    reponses_mordred: {
      speaker: '???',
      text: "*(Long silence.)*\n\nSur quoi ?",
      choices: [
        { text: "Sur le sacrifice. Sur la Pierre.", next: 'mordred_nom', effects: { flag: 'mordred_trouve' } },
        { text: "Sur vous.",                       next: 'sur_mordred' },
      ]
    },
    sur_mordred: {
      speaker: '???',
      text: "*(Il te regarde.)*\n\nT'es venu loin pour chercher des réponses sur quelqu'un.",
      choices: [
        { text: "Vous méritez qu'on cherche.",     next: 'mordred_nom', effects: { morale: +2, flag: 'mordred_trouve' } },
      ]
    },
  }
};
