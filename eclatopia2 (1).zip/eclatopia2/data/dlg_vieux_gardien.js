// ÉCLATOPIA 2 — data/dlg_vieux_gardien.js
const DLG_VIEUX_GARDIEN = {
  key: 'vieux_gardien', name: 'Vieux Gardien', title: '???',
  color: '#8a8070', portraitFn: 'portraitVieilHomme',
  x: -680, zone: 'foret',
  nodes: {
    start: {
      speaker: '???',
      text: "Tu t'es perdu.",
      choices: [
        { text: "Je cherche la Forêt des Murmures.",  next: 'foret_vg' },
        { text: "Qui êtes-vous ?",                    next: 'identite_vg' },
        { text: "Je passe juste.",                    next: null, close: true },
      ]
    },
    foret_vg: {
      speaker: '???',
      text: "…\n\nTout le monde la cherche. Personne ne revient pareil.",
      choices: [
        { text: "Qu'est-ce qui s'y passe ?",          next: 'ce_qui_passe' },
        { text: "Vous y êtes déjà allé ?",            next: 'deja_alle_vg' },
        { text: "Je n'ai pas peur.",                  next: 'pas_peur_vg' },
      ]
    },
    ce_qui_passe: {
      speaker: '???',
      text: "Les arbres parlent. Pas comme les gens parlent.\n\nComme si… quelqu'un d'autre utilisait leur bouche.",
      choices: [
        { text: "Quelqu'un d'autre ? Qui ?",          next: 'qui_parle_vg' },
        { text: "C'est une légende.",                 next: 'legende_vg' },
      ]
    },
    qui_parle_vg: {
      speaker: '???',
      text: "Mon fils est entré là-dedans il y a dix ans.\n\nIl est ressorti.\n\nMais c'était plus lui.",
      choices: [
        { text: "Qu'est-il devenu ?",                 next: 'fils_vg' },
        { text: "Votre fils… il s'appelait comment ?", next: 'nom_fils_vg' },
      ]
    },
    fils_vg: {
      speaker: '???',
      text: "Il vit toujours dans le village. Il mange. Il dort. Il dit bonjour.\n\nMais il a oublié nos prénoms.",
      choices: [
        { text: "Je suis désolé.",                    next: 'desole_vg', effects: { morale: +3 } },
        { text: "La forêt lui a pris sa mémoire ?",   next: 'memoire_vg' },
      ]
    },
    memoire_vg: {
      speaker: '???',
      text: "Sa mémoire… ou quelque chose d'autre.\n\n*(Il se tait longtemps.)*\n\nIl a ramené quelque chose en sortant. Un fragment. Il le cache sous son lit.\n\nJe l'ai vu briller la nuit.",
      choices: [
        { text: "Un fragment de quoi ?",              next: 'fragment_quoi_vg' },
        { text: "Vous lui avez demandé ?",            next: 'demande_vg' },
      ]
    },
    fragment_quoi_vg: {
      speaker: '???',
      text: "*(Il hausse les épaules.)*\n\nJe sais pas. Mais depuis qu'il l'a… il ne rêve plus.",
      choices: [
        { text: "Il ne rêve plus ?",                  next: 'reve_vg' },
        { text: "Je dois y aller.",                   next: null, close: true, effects: { flag: 'vieux_gardien_rencontre' } },
      ]
    },
    reve_vg: {
      speaker: '???',
      text: "Il dit que ses rêves ont été… pris. Et que c'est mieux comme ça.\n\n*(Il crache par terre.)*\n\nC'est pas mieux.",
      choices: [
        { text: "Je chercherai ce fragment.",         next: null, close: true, effects: { flag: 'chercher_fragment_fils', quest: 'quete_vieux_gardien', morale: +2 } },
        { text: "Au revoir.",                        next: null, close: true },
      ]
    },
    demande_vg: {
      speaker: '???',
      text: "Il répond toujours la même chose.\n\n« C'est pour mon bien. »\n\nIl a pas l'air malheureux. C'est ça qui m'inquiète le plus.",
      choices: [
        { text: "Quelqu'un l'a convaincu de quelque chose.", next: 'quelquun_vg', effects: { flag: 'fils_convaincu' } },
        { text: "Je garderai ça en tête.",            next: null, close: true },
      ]
    },
    quelquun_vg: {
      speaker: '???',
      text: "*(Il te regarde différemment.)*\n\nOuais. Quelqu'un. Ou quelque chose.\n\nFais attention à toi là-dedans.",
      choices: [
        { text: "Je ferai attention.",               next: null, close: true, effects: { item: 'conseil_prenom' } },
      ]
    },
    identite_vg: {
      speaker: '???',
      text: "Quelqu'un qui attend son fils rentrer.\n\nDepuis dix ans.",
      choices: [
        { text: "Votre fils est dans la forêt ?",     next: 'foret_vg' },
      ]
    },
    deja_alle_vg: {
      speaker: '???',
      text: "Non.\n\n*(Un silence.)*\n\nJ'ai pas eu le courage.",
      choices: [
        { text: "Ce n'est pas de la lâcheté.",        next: 'lachete_vg', effects: { morale: +3 } },
        { text: "Qu'est-ce qui vous a arrêté ?",      next: 'arret_vg' },
      ]
    },
    lachete_vg: {
      speaker: '???',
      text: "*(Il te regarde longuement.)*\n\nT'as l'air d'être quelqu'un de bien.\n\nFais attention à ça là-dedans. Les gens bien… ils ressortent différemment.",
      choices: [
        { text: "Différemment comment ?",             next: 'different_vg' },
        { text: "Merci.",                            next: null, close: true },
      ]
    },
    arret_vg: {
      speaker: '???',
      text: "J'ai entendu mon nom.\n\nDe là-dedans. La voix de mon fils.\n\nEt j'ai rebroussé chemin. Parce que j'ai compris : c'était pas lui.",
      choices: [
        { text: "C'était quoi alors ?",              next: 'quoi_voix_vg' },
        { text: "Votre instinct vous a sauvé.",       next: null, close: true },
      ]
    },
    quoi_voix_vg: {
      speaker: '???',
      text: "*(Il secoue la tête lentement.)*\n\nJe sais pas.\n\nMais toi… t'as besoin de savoir. Je le vois.",
      choices: [
        { text: "Oui. J'ai besoin de comprendre.",    next: 'comprendre_vg', effects: { morale: +2, flag: 'vieux_gardien_confiance' } },
        { text: "Je dois y aller.",                   next: null, close: true },
      ]
    },
    comprendre_vg: {
      speaker: '???',
      text: "Alors entre.\n\nMais souviens-toi de ton prénom. Les choses là-dedans — elles commencent toujours par te faire oublier ton prénom.",
      choices: [
        { text: "Pourquoi le prénom ?",               next: 'prenom_vg' },
        { text: "Je me souviendrai.",                next: null, close: true, effects: { item: 'conseil_prenom' } },
      ]
    },
    prenom_vg: {
      speaker: '???',
      text: "Parce que c'est la première chose qui est à toi. Vraiment à toi. Pas héritée, pas apprise.\n\nSi tu l'oublies… t'es plus toi.",
      choices: [
        { text: "Je m'en souviendrai.",              next: null, close: true, effects: { item: 'conseil_prenom' } },
      ]
    },
    pas_peur_vg: {
      speaker: '???',
      text: "*(Il ne répond pas. Il regarde vers la forêt.)*\n\nMon fils non plus.",
      choices: [
        { text: "...",                               next: 'fils_vg' },
        { text: "Je m'en vais.",                     next: null, close: true },
      ]
    },
    nom_fils_vg: {
      speaker: '???',
      text: "*(Un long silence.)*\n\nIl s'appelait Dorel.",
      choices: [
        { text: "...",                               next: 'fils_vg', effects: { flag: 'fils_dorel' } },
      ]
    },
    desole_vg: {
      speaker: '???',
      text: "*(Il hoche la tête.)*\n\nTout le monde est désolé. Ça change rien.\n\nLui, il dit qu'il est heureux maintenant.\n\nAlors peut-être que c'est moi le problème.",
      choices: [
        { text: "Non. Ce n'est pas vous.",            next: 'pas_vous_vg', effects: { morale: +2 } },
        { text: "Peut-être qu'il l'est vraiment.",    next: 'peut_etre_heureux_vg' },
      ]
    },
    pas_vous_vg: {
      speaker: '???',
      text: "*(Il regarde ses mains.)*\n\nJ'espère que t'as raison.",
      choices: [
        { text: "Je chercherai des réponses.",        next: null, close: true, effects: { flag: 'chercher_dorel', quest: 'quete_vieux_gardien' } },
      ]
    },
    peut_etre_heureux_vg: {
      speaker: '???',
      text: "*(Il te regarde froidement.)*\n\nSi c'est ce que tu penses… entre pas dans cette forêt.",
      choices: [
        { text: "Pourquoi ?",                        next: 'pourquoi_pas_vg' },
        { text: "Tu as raison. J'avais tort.",        next: 'desole_vg', effects: { morale: -2 } },
      ]
    },
    pourquoi_pas_vg: {
      speaker: '???',
      text: "Parce que ce qui est là-dedans… ça te dira exactement ce que t'as envie d'entendre.\n\nEt tu finiras par le croire.",
      choices: [
        { text: "Je garderai ça en tête.",            next: null, close: true, effects: { item: 'conseil_prenom' } },
      ]
    },
    different_vg: {
      speaker: '???',
      text: "*(Il hésite.)*\n\nIls rentrent avec des certitudes.\n\nMon fils avait des doutes avant. Des doutes normaux.\n\nMaintenant il en a plus aucun.",
      choices: [
        { text: "Et ça vous inquiète.",               next: 'inquiet_vg' },
      ]
    },
    inquiet_vg: {
      speaker: '???',
      text: "Un homme sans doutes… c'est un homme qui a arrêté de réfléchir.\n\nEntre là-dedans. Mais garde tes doutes.",
      choices: [
        { text: "Je les garderai.",                  next: null, close: true, effects: { item: 'conseil_prenom', morale: +3 } },
      ]
    },
    legende_vg: {
      speaker: '???',
      text: "*(Il sourit sans joie.)*\n\nOuais. C'est ce que mon fils disait aussi.",
      choices: [
        { text: "...",                               next: 'qui_parle_vg' },
      ]
    },
  }
};
