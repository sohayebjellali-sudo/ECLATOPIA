// ═══════════════════════════════════════════════════════════
// ÉCLATOPIA 2 — data/characters.js
// Personnages jouables — stats, pouvoirs, lore
// ═══════════════════════════════════════════════════════════

const CHARACTERS = {

  aelara: {
    id: 'aelara',
    name: 'Aelara la Radiante',
    faction: 'Luminari',
    color: '#e8c96a',
    glow: 'rgba(232,201,106,0.35)',
    symbol: '☀',
    ideology: "L'Ordre comme Deuil",
    quote: "Si le monde retrouve sa forme, peut-être que les gens qui l'habitaient retrouveront la leur.",
    desc: "Descendante de Solara, Grande Prêtresse des Éclatiens. L'Épée de l'Aube la consume doucement — elle le sait, elle continue.",
    lore: "Sa famille a servi les Gardiens pendant six générations. Elle a grandi dans la lumière. Elle commence à comprendre ce que la lumière coûte.",
    // Stats de base
    hp: 120, mp: 80, atk: 18, def: 10, spd: 3.2,
    atkRange: 65, atkCd: 380,
    powerName: 'Bouclier de Lumière',
    powerDesc: 'Absorbe les 2 prochains coups. Actif 4 secondes.',
    powerCd: 6000,
    powerMpCost: 20,
    // Projectile : non (mêlée uniquement)
    // Sprite
    drawFn: 'drawAelara',
    portraitFn: 'portraitElias',
    // Stats scaling par niveau
    hpPerLevel: 14, mpPerLevel: 6, atkPerLevel: 2, defPerLevel: 2,
    // Affinité
    goodVs: ['ombre', 'eveille'],
    weakVs: ['sirene'],
  },

  kael: {
    id: 'kael',
    name: 'Kael le Caché',
    faction: 'Umbrari',
    color: '#4aacdf',
    glow: 'rgba(74,172,223,0.35)',
    symbol: '🗡',
    ideology: "L'Équité des Invisibles",
    quote: "Ce que tu appelles ordre, moi j'appelle ça une liste de gens autorisés à exister.",
    desc: "Descendant de Kaelith, rebelle Éclatien. Il n'a pas confiance dans les structures — il a grandi sans.",
    lore: "Sa mère lui racontait les Cachés — les Éclatiens qui avaient refusé la Pierre. Il se demande si son ancêtre a dit non ou si on l'a forcé.",
    hp: 90, mp: 100, atk: 25, def: 6, spd: 4.5,
    atkRange: 55, atkCd: 320,
    powerName: 'Téléportation',
    powerDesc: 'Dash de 160px dans la direction regardée + dague à distance.',
    powerCd: 4500,
    powerMpCost: 18,
    drawFn: 'drawKael',
    portraitFn: 'portraitRust',
    hpPerLevel: 10, mpPerLevel: 8, atkPerLevel: 3, defPerLevel: 1,
    goodVs: ['golem', 'gardien'],
    weakVs: ['ombre'],
    // Kael génère un projectile à chaque attaque mêlée (dague)
    rangedOnMelee: true,
    rangedDmgMult: 0.55,
    rangedSpeed: 9,
  },

  theo: {
    id: 'theo',
    name: 'Théo le Cartographe',
    faction: 'Neutre',
    color: '#3acfaa',
    glow: 'rgba(58,207,170,0.35)',
    symbol: '🗺',
    ideology: "La Cartographie de l'Impossible",
    quote: "Si tu ne peux pas dire la vérité, dessine-la. Quelqu'un finira par lire la carte.",
    desc: "Ingénieur. Son père travaillait sur la Pierre. Il porte ça comme un héritage qu'il n'a pas choisi.",
    lore: "Il a relu les notes de son père cent fois. Il comprend les calculs. Il ne comprend pas comment un homme peut séparer les calculs de la conscience.",
    hp: 100, mp: 120, atk: 14, def: 8, spd: 3.5,
    atkRange: 80, atkCd: 420,
    powerName: 'Onde de Révélation',
    powerDesc: 'Émission circulaire : révèle tous les ennemis, ralentit les boss 2 sec.',
    powerCd: 5500,
    powerMpCost: 22,
    drawFn: 'drawTheo',
    portraitFn: 'portraitLuma',
    hpPerLevel: 12, mpPerLevel: 10, atkPerLevel: 2, defPerLevel: 2,
    goodVs: ['illusion', 'sirene'],
    weakVs: ['golem'],
    // Théo n'a pas d'arme principale — il utilise les ondes
    // Ses attaques ont une portée plus grande mais moins de dégâts mêlée
    waveAttack: true,
    waveRange: 90,
  },
};

// PNJ jouables dans certains dialogues (pas contrôlables)
const PNJ_PORTRAITS = {
  elias:         { name: 'Elias',         title: 'Archiviste',        color: '#c8a060', drawFn: 'portraitElias' },
  valeriane:     { name: 'Valériane',     title: 'Guérisseuse',       color: '#80c890', drawFn: 'portraitValeriane' },
  theo_npc:      { name: 'Théo',          title: 'Ingénieur',         color: '#3acfaa', drawFn: 'portraitTheo' },
  aldric:        { name: 'Aldric',        title: '???',               color: '#8090a0', drawFn: 'portraitAldric' },
  mordred:       { name: 'Mordred',       title: 'Ancien Roi',        color: '#c04030', drawFn: 'portraitMordred' },
  vaeltharion:   { name: 'Vaeltharion',   title: 'Le Veilleur',       color: '#7fffee', drawFn: 'portraitVaeltharion' },
  rust:          { name: 'Rust',          title: 'Forgeron',          color: '#e08040', drawFn: 'portraitRust' },
  luma:          { name: 'Luma',          title: 'Bibliothécaire',    color: '#b070ff', drawFn: 'portraitLuma' },
  vieux_gardien: { name: 'Vieux Gardien', title: '???',               color: '#8a8070', drawFn: 'portraitVieilHomme' },
};

function getChar(id) { return CHARACTERS[id] || CHARACTERS.aelara; }
